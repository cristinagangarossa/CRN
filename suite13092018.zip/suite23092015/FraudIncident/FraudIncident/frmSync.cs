﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Data.SqlClient;

namespace FraudIncident
{
    public partial class frmSync : Form
    {
        bool closeConsole = false;
        //viewConsole win;

        public frmSync()
        {
            InitializeComponent();
        }

        private bool midsValid(TextBox tb)
        {
            string text = "";
            string[] lines = tb.Lines;
            for (int i = 0; i < lines.Length; i++)
            {
                string text2 = lines[i];
                int num;
                if (text2.Length != 9 || !int.TryParse(text2, out num))
                {
                    text = text + "Invalid MID: " + text2 + "\r\n";
                }
            }
            bool result;
            if (text != "")
            {
                MyMessage.showMessage(text, MessageBoxIcon.Hand);
                result = false;
            }
            else
            {
                result = true;
            }
            return result;
        }
        private void removeBlankLines(TextBox tb)
        {
            tb.Lines = (
                from line in tb.Lines
                where !line.Equals(string.Empty)
                select line).ToArray<string>();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.myprogressbar.Value = 0;
            this.removeBlankLines(this.tbMidslist);
            if (MyControl.checkControl(this) && this.midsValid(this.tbMidslist))
            {
                base.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                MyLogger.WriteLog(this.Text + ": start import");
                this.myworker.RunWorkerAsync();
                
               /* win = (Application.OpenForms["viewConsole"] != null) ? ((viewConsole)Application.OpenForms["viewConsole"]) : null;
                if (win == null)
                {
                    win = new viewConsole();
                    win.Show();
                    closeConsole = true;
                }*/

                if (!MyConsole.mostraCONSOLE.Visible)
                {
                    closeConsole = true;
                    MyConsole.mostraCONSOLE.Show();
                }

            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud);
            try
            {
                MyLogger.WriteLog(this.Text + ": get from database");
                base.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                SqlCommand sqlCommand = new SqlCommand("SELECT DISTINCT EXTERNAL_MERCHANT_NO FROM T_FRAUD_INCIDENT ORDER BY EXTERNAL_MERCHANT_NO");
                sqlCommand.Connection = sqlConnection;
                sqlConnection.Open();
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                while (sqlDataReader.Read())
                {
                    if (this.tbMidslist.Text.EndsWith("\n") || this.tbMidslist.Text.Length == 0)
                    {
                        this.tbMidslist.AppendText(sqlDataReader[0].ToString());
                    }
                    else
                    {
                        this.tbMidslist.AppendText("\r\n" + sqlDataReader[0].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.WriteLog(this.Text + ": " + ex.Message);
                MyMessage.showMessage("ERROR\n" + ex.Message, MessageBoxIcon.Hand);
                MyConsole.enqueue("ERROR\n" + ex.Message);
                sqlConnection.Close();
            }
            finally
            {
                base.Enabled = true;
                Cursor.Current = Cursors.Arrow;
            }
        }
        private void tbMidslist_Click(object sender, EventArgs e)
        {
            if (!this.button1.Enabled)
            {
                this.button1.Enabled = true;
            }
        }
        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                removeBlankLines(tbMidslist);
                if (midsValid(tbMidslist))
                {
                    Omnipay myOmnipay = new Omnipay();

                    if (myOmnipay.Login(MyConnection.ram_parameter.username, MyConnection.ram_parameter.pwd))
                    {

                        RootClass myIncident;
                        int count;
                        foreach (string line in tbMidslist.Lines)
                        {
                            Cursor.Current = Cursors.WaitCursor;
                            if (line != string.Empty)
                            {
                                myIncident = myOmnipay.getRamData(line);
                                if (myIncident.response == "OK")
                                {
                                    SqlConnection connessione = new SqlConnection(MyConnection.con_string_db_fraud);
                                    SqlCommand command = new SqlCommand("DELETE FROM T_FRAUD_INCIDENT WHERE EXTERNAL_MERCHANT_NO='" + line + "'");
                                    command.Connection = connessione;
                                    connessione.Open();
                                    count = command.ExecuteNonQuery();

                                    switch (count)
                                    {
                                        case 0:
                                            MyConsole.enqueue("no previous entries to delete");
                                            break;
                                        default:
                                            MyConsole.enqueue("delete " + count + " previous entries");
                                            break;
                                    }

                                    command.CommandText = "INSERT INTO [T_FRAUD_INCIDENT] VALUES (@TRANS_DATE,@CASE_ID,@STATUS,@EXTERNAL_MERCHANT_NO,@CLIENT,@CENTRAL_PROCESSING_DATE,@KIND,@NTWK,@CARD_NO,@ARN,@RC,@REASON_CODE,@CASE_PRIORITY,@NETWK_SETT_AMT,@NETWK_SETT_CURR,@LOCAL_AMT,@LOCAL_CURR,@WORK_BY_DATE,@C,@DUE_DATE,@POSTING_DATE,@CCN,@ASSIGNED_TO,@MERCHANT_NAME,@CAPTURE_METHOD,@LAST_MERCHANT_ACTION,@USER_MERCHANT_ACTION,@CUSTOM_DATA,@TRANSACTION_DATE,@MERCH_TRAN_REF,@MERCHANT_FUNDING_CURRENCY,@MERCH_FUNDING_AMT_GR)";

                                    foreach (Data d in myIncident.data)
                                    {
                                        command.Parameters.Clear();
                                        command.Parameters.AddWithValue("@TRANS_DATE", d.transactionDate); //DB ORACLE ?
                                        command.Parameters.AddWithValue("@CASE_ID", d.id);
                                        command.Parameters.AddWithValue("@STATUS", d.status);
                                        command.Parameters.AddWithValue("@EXTERNAL_MERCHANT_NO", d.ourReference);
                                        command.Parameters.AddWithValue("@CLIENT", d.clientNumber);
                                        command.Parameters.AddWithValue("@CENTRAL_PROCESSING_DATE", d.recordDate);
                                        command.Parameters.AddWithValue("@KIND", d.transactionKind);
                                        command.Parameters.AddWithValue("@NTWK", d.cardNetwork);
                                        command.Parameters.AddWithValue("@CARD_NO", d.cardNumber);
                                        command.Parameters.AddWithValue("@ARN", d.arn);
                                        command.Parameters.AddWithValue("@RC", d.reasonCodeNum);
                                        command.Parameters.AddWithValue("@REASON_CODE", d.reasonCodeDesc);
                                        command.Parameters.AddWithValue("@CASE_PRIORITY", d.priority);
                                        command.Parameters.AddWithValue("@NETWK_SETT_AMT", d.settleAmount);
                                        command.Parameters.AddWithValue("@NETWK_SETT_CURR", d.settleCurrency);
                                        command.Parameters.AddWithValue("@LOCAL_AMT", d.localAmount);
                                        command.Parameters.AddWithValue("@LOCAL_CURR", d.localCurrency);
                                        command.Parameters.AddWithValue("@WORK_BY_DATE", (d.workByDate == string.Empty) ? (object)DBNull.Value : d.workByDate);
                                        command.Parameters.AddWithValue("@C", d.countdown);
                                        command.Parameters.AddWithValue("@DUE_DATE", d.dueDate);
                                        command.Parameters.AddWithValue("@POSTING_DATE", d.netwkProcDate);
                                        command.Parameters.AddWithValue("@CCN", d.ccn);
                                        command.Parameters.AddWithValue("@ASSIGNED_TO", d.assignedTo);
                                        command.Parameters.AddWithValue("@MERCHANT_NAME", d.merchDbaName);
                                        command.Parameters.AddWithValue("@CAPTURE_METHOD", d.captureMethod);
                                        command.Parameters.AddWithValue("@LAST_MERCHANT_ACTION", d.merchantAction);
                                        command.Parameters.AddWithValue("@USER_MERCHANT_ACTION", d.merchantUserAction);
                                        command.Parameters.AddWithValue("@CUSTOM_DATA", d.customData);
                                        command.Parameters.AddWithValue("@TRANSACTION_DATE", d.transactionDate);
                                        command.Parameters.AddWithValue("@MERCH_TRAN_REF", d.origMerchantRef);
                                        command.Parameters.AddWithValue("@MERCHANT_FUNDING_CURRENCY", d.merchFundingCurrency);
                                        command.Parameters.AddWithValue("@MERCH_FUNDING_AMT_GR", d.merchFundingAmtGross);

                                        if (command.ExecuteNonQuery() > 0)
                                        {
                                            MyConsole.enqueue(d.id + " inserted");
                                        }
                                        else
                                        {
                                            MyConsole.enqueue(d.id + " not inserted");
                                        }
                                    }
                                    connessione.Close();
                                }
                                else
                                {
                                    MyConsole.enqueue(line + " Json Response: " + myIncident.response);
                                }
                            }
                        }
                        MyConsole.enqueue((myOmnipay.Logout()) ? "Logout OK" : "Logout KO");
                        Cursor.Current = Cursors.Default;
                    }
                    else
                    {
                        MessageBox.Show("Invalid login", "Fraud incident", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                }
            }
            catch (Exception ee)
            {
                Cursor.Current = Cursors.Default;
                MessageBox.Show("ERROR\r\n" + ee.Message, "Fraud incident", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
        private void myworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.myprogressbar.Value = e.ProgressPercentage;
        }
        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            Cursor.Current = Cursors.Arrow;
            if (closeConsole)
            {
                //win.Close();
                //win = null;
                MyConsole.mostraCONSOLE.Hide();
            }
        }
    }
}