﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Collections;
using System.Globalization;
using System.Data.SqlClient;

namespace FraudIncident
{
    public partial class frmBrowse : Form
    {
        private string current_mid = "";
        public frmBrowse()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                this.dataGridView1.DataSource = this.bindingSource1;
                string selectCommand = "SELECT * FROM T_FRAUD_INCIDENT WHERE EXTERNAL_MERCHANT_NO ='" + this.cbMID.Text + "'";
                this.GetData(selectCommand);
                this.current_mid = this.cbMID.Text;
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("ERROR:\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog("ERROR: " + ex.Message);
            }
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                this.fraudDelete();
            }
        }

        private void fraudDelete()
        {
            if (MyMessage.askMessage(this.dataGridView1.SelectedRows.Count + " RECORDS WILL BE DELETED\r\nCONFIRM ?"))
            {
                Cursor.Current = Cursors.WaitCursor;
                SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud);
                sqlConnection.Open();
                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.Connection = sqlConnection;
                try
                {
                    foreach (DataGridViewRow dataGridViewRow in this.dataGridView1.SelectedRows)
                    {
                        sqlCommand.CommandText = "DELETE FROM T_FRAUD_INCIDENT WHERE ID_FRAUD_INCIDENT=" + this.dataGridView1.Rows[dataGridViewRow.Index].Cells[0].Value.ToString();
                        sqlCommand.ExecuteNonQuery();
                        this.dataGridView1.Rows.Remove(dataGridViewRow);
                    }
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("UNABLE TO DELETE FRAUD INCIDENT:\n" + ex.Message, MessageBoxIcon.Hand);
                    MyLogger.WriteLog("UNABLE TO DELETE FRAUD INCIDENT: " + ex.Message);
                    MyConsole.enqueue("UNABLE TO DELETE FRAUD INCIDENT: " + ex.Message);
                }
                sqlConnection.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        private void frmBrowse_Load(object sender, EventArgs e)
        {
            utilities.fillDropDownList("SELECT DISTINCT EXTERNAL_MERCHANT_NO FROM T_FRAUD_INCIDENT ORDER BY EXTERNAL_MERCHANT_NO", this.cbMID, "EXTERNAL_MERCHANT_NO", "EXTERNAL_MERCHANT_NO", false);
        }

        public void GetData(string selectCommand)
        {
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommand, MyConnection.con_string_db_fraud);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
                DataTable dataTable = new DataTable();
                dataTable.Locale = CultureInfo.InvariantCulture;
                sqlDataAdapter.Fill(dataTable);
                this.bindingSource1.DataSource = dataTable;
                this.dataGridView1.Columns[0].Visible = false;
                this.dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.DisplayedCells);
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("ERROR\r\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog("ERROR: " + ex.Message);
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (this.panel1.Visible)
            {
                this.panel1.Visible = false;
                this.dataGridView1.Location = new Point(11, 37);
                this.dataGridView1.Size = new Size(this.dataGridView1.Size.Width, this.dataGridView1.Size.Height + 66);
            }
            else
            {
                this.panel1.Visible = true;
                this.dataGridView1.Location = new Point(11, 103);
                this.dataGridView1.Size = new Size(this.dataGridView1.Size.Width, this.dataGridView1.Size.Height - 66);
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            try
            {
                ArrayList arrayList = new ArrayList();
                arrayList.Add(14);
                arrayList.Add(16);
                arrayList.Add(32);
                utilities.exportToExcel(this.dataGridView1, arrayList, "Fraud incident " + this.current_mid);
                MyMessage.showMessage("File created", MessageBoxIcon.Asterisk);
                MyLogger.WriteLog(this.Text + ": CSV created");
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("ERROR:\r\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog("ERROR: " + ex.Message);
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            this.fraudDelete();
        }

    }
}
