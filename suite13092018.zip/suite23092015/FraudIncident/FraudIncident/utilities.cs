﻿using Credit_risk_lib;
using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace FraudIncident
{
    class utilities
    {
        public static void exportToExcel(DataGridView myDGV, ArrayList floatColumns, string proposedFilename)
        {
            try
            {
                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                saveFileDialog1.Filter = "Excel File|*.xls";
                saveFileDialog1.FileName = proposedFilename;
                saveFileDialog1.Title = "Export fraud file";
                DialogResult dialogResult = saveFileDialog1.ShowDialog();

                // If the file name is not an empty string open it for saving.
                if (saveFileDialog1.FileName != "" && dialogResult == DialogResult.OK)
                {
                    Cursor.Current = Cursors.WaitCursor;
                    Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

                    Excel.Workbook xlWorkBook = xlApp.Workbooks.Add();
                    Excel.Worksheet xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];
                    xlApp.DisplayAlerts = false;
                    xlApp.Visible = false;

                    int i;
                    int j;
                    DateTime dt;

                    for (i = 1; i < myDGV.Columns.Count; i++)// i=1 avoid ID column export
                    {
                        xlWorkSheet.Cells[1, i] = myDGV.Columns[i].Name;
                    }

                    for (i = 0; i <= myDGV.RowCount - 1; i++)
                    {
                        for (j = 1; j <= myDGV.ColumnCount - 1; j++)
                        {
                            DataGridViewCell cell = myDGV[j, i];
                            if (floatColumns.Contains(j))
                            {
                                xlWorkSheet.Cells[i + 2, j] = cell.Value;
                            }
                            else if (cell.Value.ToString().EndsWith(" 00:00:00") || cell.Value.ToString().EndsWith(" 0.00.00"))
                            {
                                dt = Convert.ToDateTime(cell.Value.ToString().Substring(0, 10));
                                xlWorkSheet.Cells[i + 2, j] = dt;
                            }
                            else
                            {
                                xlWorkSheet.Cells[i + 2, j] = "'" + cell.Value;
                            }
                        }
                    }

                    xlWorkBook.SaveAs(saveFileDialog1.FileName, Excel.XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing, false, false, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges);
                    xlWorkBook.Close(true);
                    xlApp.Quit();
                    Cursor.Current = Cursors.Default;
                    MessageBox.Show("File created.", "Fraud Incident", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                Cursor.Current = Cursors.Default;
                throw;
            }
        }

        public static void fillDropDownList(string Query, System.Windows.Forms.ComboBox DropDownName, string valueMember, string displayMember, bool emptyRow = false)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            SqlDataReader dr;
            using (var sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud))
            {
                sqlConnection.Open();

                try
                {
                    SqlCommand cmd = new SqlCommand(Query, sqlConnection);
                    dr = cmd.ExecuteReader();
                    dt.Load(dr);
                }
                catch (Exception ee)
                {
                    MessageBox.Show("ERROR\r\n" + ee.Message, "Fraud Manager", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }

            if (emptyRow)
            {
                DataRow row = dt.NewRow();
                row[displayMember] = "";
                row[valueMember] = "";
                dt.Rows.InsertAt(row, 0);
            }

            DropDownName.DataSource = dt;
            DropDownName.ValueMember = valueMember;
            DropDownName.DisplayMember = displayMember;
        }

        public static void resetAllControls(Control form)
        {
            foreach (Control control in form.Controls)
            {
                if (control is TextBox)
                {
                    TextBox textBox = (TextBox)control;
                    textBox.Text = null;
                }

                if (control is ComboBox)
                {
                    ComboBox comboBox = (ComboBox)control;
                    if (comboBox.Items.Count > 0)
                        comboBox.SelectedIndex = 0;
                }

                if (control is CheckBox)
                {
                    CheckBox checkBox = (CheckBox)control;
                    checkBox.Checked = false;
                }

                if (control is ListBox)
                {
                    ListBox listBox = (ListBox)control;
                    listBox.ClearSelected();
                }
            }
        }
    }
}
