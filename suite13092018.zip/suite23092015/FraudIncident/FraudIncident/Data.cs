﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FraudIncident
{
    // Type created for JSON at <<root>>
    [System.Runtime.Serialization.DataContractAttribute()]
    public partial class RootClass
    {

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string response;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public Data[] data;
    }

    // Type created for JSON at <<root>> --> data
    [System.Runtime.Serialization.DataContractAttribute(Name = "data")]
    public partial class Data
    {

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string id;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string institution;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string status;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string priority;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string ourReference;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string clientNumber;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string transactionKind;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string cardNetwork;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string cardNumber;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string arn;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string reasonCodeNum;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string reasonCodeDesc;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string localAmount;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string localCurrency;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string settleAmount;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string settleCurrency;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string countdown;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string dueDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string recordDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string ccn;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string assignedTo;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string merchDbaName;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string netwkProcDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string transactionKindDesc;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string acqMember;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string issMember;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string retrievalReqId;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string docIndCode;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string docIndText;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string fxProtected;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string captureMethod;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string expiryDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string cardBrand;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string xferAmount;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string xferCurrency;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string category;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string closeDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string refundStatus;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string hiddenUntil;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string caseInstName;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string tcn;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string docReceivedDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string visaCaseNumber;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string ticketNumber;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string passengerName;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string merchantAction;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string merchantUserAction;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string issuerCountry;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string issuerName;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string feeType;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string feeReason;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string feeCurrency;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string feeAmount;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string feeMessageText;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string feeCardSchemeId;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string workByDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string backgroundColourHex;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string customData;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string rowsLimit;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string rowsTotal;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string attachCategory;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string transactionDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string dtransactionDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string origMerchantRef;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string merchFundingAmtGross;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string merchFundingCurrency;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string eWalletType;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string ddueDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string drecordDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string dworkByDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string dnetwkProcDate;

        [System.Runtime.Serialization.DataMemberAttribute()]
        public string ddocReceivedDate;
    }
}
