﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;

namespace FraudIncident
{
    public class Omnipay
    {
        public string bls;
        CookieContainer myCook;

        public bool Login(string username, string password)
        {
            try
            {
                myCook = new CookieContainer();
                string url = "https://www.omnipaygroup.com/ramtool";

                string data = "prevpage=LOGIN&cmd=login&nextpage=WELCOME&69=" + username + "&76=" + password;
                byte[] buffer = Encoding.UTF8.GetBytes(data);

                ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "POST";
                req.ContentType = "application/x-www-form-urlencoded";
                req.ContentLength = buffer.Length;

                req.Proxy = WebProxy.GetDefaultProxy();
                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                req.CookieContainer = myCook; // enable cookies

                Stream reqst = req.GetRequestStream(); // add form data to request stream
                reqst.Write(buffer, 0, buffer.Length);
                reqst.Flush();
                reqst.Close();

                HttpWebResponse res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                StreamReader srResponse = new StreamReader(res.GetResponseStream());

                string myHtml = srResponse.ReadToEnd();
                if (myHtml.Contains("Invalid Login"))
                {
                    return false;
                }
                else
                {
                    bls = myHtml.Substring(myHtml.IndexOf("37bls=") + 6, 128);
                    return true;
                }
            }
            catch (Exception e)
            {
                throw new Exception("Login error: " + e.Message);
            }
        }

        public RootClass getRamData(string merchant_id)
        {
            try
            {
                DateTime dateValue = DateTime.Now;

                string dateTo = dateValue.ToString("dd/MM/yyyy");
                string dateFrom = dateValue.ToString("dd/MM/2006");

                string url = "https://www.omnipaygroup.com/ramtool/ajax?cmd=ajaxs&nextpage=OMCBK_CASE_LIST&48FRS67=searchCases&72xcr=000&52e=" + dateFrom + "&52d=" + dateTo + "&23h=&165wd=&53e=YES&67d=-1&17b=-1&49a2f1=&16b=&12=&18e=&40u=" + merchant_id + "&69=-1&36ef=999999999&54B=008&18abbd=&18d=-1&23fcpd=&128a=-1&128b=-1&18d3bi=-1&36aa4=&37bls=" + bls + "&subset=000";

                ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "GET";
                req.ContentType = "text/html";

                req.Proxy = WebProxy.GetDefaultProxy();
                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                req.CookieContainer = myCook; // enable cookies

                HttpWebResponse res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                Stream strResponse = res.GetResponseStream();

                var serializer = new DataContractJsonSerializer(typeof(RootClass));
                return (RootClass)serializer.ReadObject(strResponse);
            }
            catch
            {
                throw new Exception("getRamData error");
            }
        }

        public bool Logout()
        {
            try
            {
                string url = "https://www.omnipaygroup.com/ramtool?cmd=logout&nextpage=LOGOUT&37bls=" + bls;

                ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "GET";
                req.ContentType = "text/html";

                req.Proxy = WebProxy.GetDefaultProxy();
                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                req.CookieContainer = myCook; // enable cookies

                HttpWebResponse res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                StreamReader srResponse = new StreamReader(res.GetResponseStream());
                if (srResponse.ReadToEnd().Contains("User Logged Out"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                throw new Exception("Logout error");
            }
        }
    }
}
