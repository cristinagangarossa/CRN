﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace WriteOff
{
    partial class changeAmountGlobal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private Button btnCancel;
        private Button btnSave;
        private TextBox txtamount;
        private Label lbl;
        private DataGridView dataGridView1;
        private Button button1;
        private Label label1;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
            this.btnCancel = new Button();
            this.btnSave = new Button();
            this.txtamount = new TextBox();
            this.lbl = new Label();
            this.dataGridView1 = new DataGridView();
            this.Column1 = new DataGridViewTextBoxColumn();
            this.Column2 = new DataGridViewTextBoxColumn();
            this.button1 = new Button();
            this.label1 = new Label();
            ((ISupportInitialize)this.dataGridView1).BeginInit();
            base.SuspendLayout();
            this.btnCancel.AutoSize = true;
            this.btnCancel.Location = new Point(157, 232);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Padding = new Padding(3, 0, 3, 0);
            this.btnCancel.Size = new Size(60, 25);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);
            this.btnSave.AutoSize = true;
            this.btnSave.Location = new Point(17, 232);
            this.btnSave.Name = "btnSave";
            this.btnSave.Padding = new Padding(3, 0, 3, 0);
            this.btnSave.Size = new Size(48, 25);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new EventHandler(this.btnSave_Click);
            this.txtamount.Location = new Point(17, 31);
            this.txtamount.MaxLength = 12;
            this.txtamount.Name = "txtamount";
            this.txtamount.Size = new Size(116, 23);
            this.txtamount.TabIndex = 1;
            this.lbl.AutoSize = true;
            this.lbl.Location = new Point(20, 13);
            this.lbl.Margin = new Padding(0);
            this.lbl.Name = "lbl";
            this.lbl.Size = new Size(49, 15);
            this.lbl.TabIndex = 3;
            this.lbl.Text = "Amount";
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new DataGridViewColumn[]
			{
				this.Column1,
				this.Column2
			});
            this.dataGridView1.Location = new Point(17, 86);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new Size(200, 140);
            this.dataGridView1.TabIndex = 4;
            this.Column1.HeaderText = "BUCKET";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            dataGridViewCellStyle.Format = "C2";
            this.Column2.DefaultCellStyle = dataGridViewCellStyle;
            this.Column2.HeaderText = "AMOUNT";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.button1.AutoSize = true;
            this.button1.Location = new Point(151, 31);
            this.button1.Name = "button1";
            this.button1.Padding = new Padding(3, 0, 3, 0);
            this.button1.Size = new Size(66, 25);
            this.button1.TabIndex = 2;
            this.button1.Text = "Preview";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(14, 68);
            this.label1.Name = "label1";
            this.label1.Size = new Size(179, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "Data will be changed as follow:";
            base.AutoScaleDimensions = new SizeF(7f, 15f);
            base.ClientSize = new Size(233, 268);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.button1);
            base.Controls.Add(this.dataGridView1);
            base.Controls.Add(this.lbl);
            base.Controls.Add(this.txtamount);
            base.Controls.Add(this.btnSave);
            base.Controls.Add(this.btnCancel);
            this.Font = new Font("Calibri", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "changeAmountGlobal";
            base.ShowIcon = false;
            base.ShowInTaskbar = false;
            this.Text = "Change total amount";
            ((ISupportInitialize)this.dataGridView1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        #endregion
    }
}