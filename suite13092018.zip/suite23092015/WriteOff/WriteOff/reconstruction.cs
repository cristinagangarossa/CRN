﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;

namespace WriteOff
{
    public partial class reconstruction : Form
    {
        private object misValue = Missing.Value;
        private List<string> Columns = new List<string>(new string[] { "OPN_1_30", "OPN_31_60", "OPN_61_90", "OPN_91_120", "OPN_121_150", "OPN_151_180", "OPN_181_210", "OPN_211_240", "OPN_241_270", "OPN_271_300", "OPN_301_330", "OPN_331_360", "OPN_360" });
        private string parteOUT = "";
        private string parteDEBT = "";
        private SqlDataReader outDeb;
        private SqlCommand query_outDeb = new SqlCommand();
        private string newFilePath = string.Empty;

        public reconstruction()
        {
            InitializeComponent();
            this.monthChoose.SelectedIndex = 0;
            this.comboyear.Value = DateTime.Now.AddYears(-1);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btnpercorso_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                this.txtpercorso.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.mybar.Value = 0;
            if (MyControl.checkControl(this))
            {
                base.Enabled = false;
                this.parteDEBT = "";
                this.parteOUT = "";
                MyLogger.WriteLog(string.Concat(this.Text, ": start"));
                for (int i = 0; i < this.Columns.Count; i++)
                {
                    if (i >= generalData.valueMonth(this.monthChoose.Text.Trim()))
                    {
                        parteOUT = string.Concat(parteOUT, this.Columns[i], "+");
                    }
                    else
                    {
                        parteDEBT = string.Concat(parteDEBT, this.Columns[i], "+");
                    }
                }
                this.parteOUT = this.parteOUT.Substring(0, this.parteOUT.Length - 1);
                this.parteDEBT = this.parteDEBT.Substring(0, this.parteDEBT.Length - 1);
                BackgroundWorker backgroundWorker = this.mywork;
                object[] text = new object[] { this.comboyear.Text, this.yearChoose.Text.Trim().Remove(0, 2), generalData.valueMonth(this.monthChoose.Text.Trim()) };
                backgroundWorker.RunWorkerAsync(text);
            }
        }

        private void mywork_DoWork(object sender, DoWorkEventArgs e)
        {
            SqlConnection _con = generalData.get_con();
            SqlConnection sqlConnection = generalData.get_con();
            SqlConnection _con1 = generalData.get_con();
            Excel.Application variable = new Excel.Application();
            try
            {
                object[] argument = (object[])e.Argument;

                variable.DisplayAlerts = false;
                string text = this.txtpercorso.Text;
                DateTime now = DateTime.Now;
                this.newFilePath = string.Concat(text, "\\debt-recostruction", now.ToString("ddMMyyyy"), ".xlsx");
                Excel.Workbook variable1 = variable.Workbooks.Add(Missing.Value);
                Excel.Worksheet item = (Excel.Worksheet)((dynamic)variable1.Worksheets[1]);
                item.PageSetup.Orientation = Excel.XlPageOrientation.xlLandscape;
                item.PageSetup.PaperSize = Excel.XlPaperSize.xlPaperA4;
                item.PageSetup.Zoom = false;
                item.PageSetup.FitToPagesWide = 1;
                item.PageSetup.FitToPagesTall = 1;
                int num = 2;
                _con.Open();
                sqlConnection.Open();
                _con1.Open();
                this.query_outDeb.Connection = _con1;
                int num1 = (int)(new SqlCommand(string.Concat("SELECT COUNT(*) FROM T_CSR_3112 WHERE COLLECTOR_USER <> 'Fraud' AND PERIOD = ", argument[0]), _con)).ExecuteScalar();
                int num2 = 0;
                //unica modifica a calcolo writeoff 30122015 >= al posto di > query sopra
                SqlCommand sqlCommand = new SqlCommand("SELECT SUM(BUCKET_VALUE) FROM T_CSR_DETAIL WHERE IS_CANCEL = 0 AND GLACCOUNT = @account AND BUCKET_NAME >= @bucket AND  ID_CSR_MONTHLY = (SELECT TOP 1 ID_CSR_MONTHLY FROM T_CSR_MONTHLY WHERE MERCHANT_NUM = @mid AND YEAR= @year AND MONTH = @month)", sqlConnection);
                sqlCommand.Parameters.Add("@account", SqlDbType.VarChar);
                sqlCommand.Parameters.Add("@bucket", SqlDbType.SmallInt);
                sqlCommand.Parameters.Add("@mid", SqlDbType.VarChar);
                sqlCommand.Parameters.Add("@year", SqlDbType.SmallInt).Value = argument[1];
                sqlCommand.Parameters.Add("@month", SqlDbType.SmallInt);
                SqlCommand sqlCommand1 = new SqlCommand("SELECT TOP 1 TOT_BAL FROM T_CSR_REPORT WHERE MERCHANT_NUM = @mid AND YEAR= @year AND MONTH = @month", sqlConnection);
                sqlCommand1.Parameters.Add("@mid", SqlDbType.VarChar);
                sqlCommand1.Parameters.Add("@year", SqlDbType.SmallInt).Value = argument[1];
                sqlCommand1.Parameters.Add("@month", SqlDbType.SmallInt).Value = argument[2];
                SqlDataReader sqlDataReader = (new SqlCommand(string.Concat("SELECT * FROM T_CSR_3112 WHERE COLLECTOR_USER <> 'Fraud' AND PERIOD = ", argument[0]), _con)).ExecuteReader();
                while (sqlDataReader.Read())
                {
                    item.Cells[num, 1] = sqlDataReader["MERCHANT_NUM"].ToString();
                    item.Cells[num, 2] = string.Concat("'", sqlDataReader["MERCHANT_NAME"]);
                    item.Cells[num, 3] = string.Concat("'", generalData.cercaBucket(sqlDataReader));
                    item.Cells[num, 4] = double.Parse(sqlDataReader["TOT_BAL"].ToString());


                    // debug 28/12 - fin qui ok!
                    sqlCommand.Parameters["@mid"].Value = sqlDataReader["MERCHANT_NUM"]; 
                    double num3 = 0;
                    double num4 = 0;
                    double num5 = 0;
                    for (int i = 1; i <= int.Parse(argument[2].ToString()); i++)
                    {
                        sqlCommand.Parameters["@bucket"].Value = i;
                        sqlCommand.Parameters["@month"].Value = i;
                        sqlCommand.Parameters["@account"].Value = "51101";
                        try
                        {
                            num3 = num3 + double.Parse(sqlCommand.ExecuteScalar().ToString());
                        }
                        catch (Exception)
                        {
                            num3 = num3 + 0;
                        }
                        sqlCommand.Parameters["@account"].Value = "54008";
                        try
                        {
                            num4 = num4 + double.Parse(sqlCommand.ExecuteScalar().ToString());
                        }
                        catch (Exception)
                        {
                            num4 = num4 + 0;
                        }
                        sqlCommand.Parameters["@account"].Value = "53202";
                        try
                        {
                            num5 = num5 + double.Parse(sqlCommand.ExecuteScalar().ToString());
                        }
                        catch (Exception)
                        {
                            num5 = num5 + 0;
                        }
                    }
                    item.Cells[num, 5] = num3;
                    item.Cells[num, 6] = num4;
                    item.Cells[num, 7] = num5;
                    Excel.Range cells = item.Cells;
                    
                    /*object[] objArray = new object[] { "=D", num, " - (E", num, " + F", num, " + G", num, ") - I", num, " " };
                    cells[obj, obj1] = string.Concat(objArray);*/
                     double[] numArray = this.calcola_Outstanding_NewDebt(sqlDataReader["MERCHANT_NUM"].ToString(), int.Parse(argument[1].ToString()), int.Parse(argument[2].ToString()));

                     if (double.Parse(sqlDataReader["TOT_BAL"].ToString()) - (num3 + num4 + num5) - numArray[0] >= 0)
                         cells[num, 8] = "=D" + num + " - (E" + num + " + F" + num + " + G" + num + ") - I" + num;
                     else
                         cells[num, 8] = 0;
                                      
                    item.Cells[num, 9] = numArray[0];
                    item.Cells[num, 10] = numArray[1];
                    sqlCommand1.Parameters["@mid"].Value = sqlDataReader["MERCHANT_NUM"];
                    try
                    {
                        item.Cells[num, 11] = double.Parse(sqlCommand1.ExecuteScalar().ToString());
                    }
                    catch (Exception)
                    {
                        item.Cells[num, 11] = 0;
                    }
                    num++;
                    num2++;
                    this.mywork.ReportProgress(num2 * 100 / num1);
                }
                _con.Close();
                sqlConnection.Close();
                _con1.Close();
                generalData.setColumnNameRecostruction(ref item);
                try
                {
                    variable1.SaveAs(this.newFilePath, Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
                }
                catch (Exception exception4)
                {
                    variable1.SaveAs(this.newFilePath.Replace(".xlxs", "_1.xlxs"), Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
                }
                variable1.Close(true, this.misValue, this.misValue);
                variable.Quit();
                this.releaseObject(item);
                this.releaseObject(variable1);
                this.releaseObject(variable);
            }
            catch (Exception exception6)
            {
                Exception exception5 = exception6;
                MyMessage.showMessage(string.Concat("Error:\n", exception5.Message), MessageBoxIcon.Hand);
                MyLogger.WriteLog(string.Concat(this.Text, ": ", exception5.Message));
                variable.Quit();
                _con.Close();
                sqlConnection.Close();
                _con1.Close();
                e.Cancel = true;
                return;
            }
        }

        private void mywork_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.mybar.Value = e.ProgressPercentage;
        }

        private void mywork_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            if (this.mybar.Value != 100)
            {
                MyMessage.showMessage("Export has been stopped", MessageBoxIcon.Hand);
            }
            else
            {
                MyMessage.showMessage(string.Concat(this.newFilePath, " EXPORTED"), MessageBoxIcon.Asterisk);
            }
        }

        private void releaseObject(object obj)
        {
            try
            {
                try
                {
                    Marshal.ReleaseComObject(obj);
                    obj = null;
                }
                catch (Exception exception1)
                {
                    Exception exception = exception1;
                    obj = null;
                    MessageBox.Show(string.Concat("Exception Occured while releasing object ", exception.ToString()));
                }
            }
            finally
            {
                GC.Collect();
            }
        }

        private double[] calcola_Outstanding_NewDebt(string id_m, int anno, int mese)
        {
            double[] numArray = new double[2];
            SqlCommand queryOutDeb = this.query_outDeb;
            object[] idM = new object[] { "SELECT (", this.parteOUT, ") as outstading, (", this.parteDEBT, ") as deb FROM T_CSR_REPORT WHERE MERCHANT_NUM = '", id_m, "' AND MONTH = ", mese, "  AND YEAR = ", anno };
            queryOutDeb.CommandText = string.Concat(idM);
            this.outDeb = this.query_outDeb.ExecuteReader();
            this.outDeb.Read();
            try
            {
                try
                {
                    numArray[0] = double.Parse(this.outDeb["outstading"].ToString());
                    numArray[1] = double.Parse(this.outDeb["deb"].ToString());
                }
                catch (Exception)
                {
                    numArray[0] = 0;
                    numArray[1] = 0;
                }
            }
            finally
            {
                this.outDeb.Close();
            }
            return numArray;
        }
    }
}
