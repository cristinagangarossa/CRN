﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;

namespace WriteOff
{
    public partial class changeAmount : Form
    {
        private SqlConnection mycon = generalData.get_con();
        private double new_amount = 0.0;
        public bool hasSave = false;
        private string type;
        private DataGridViewRow r;

        public changeAmount(DataGridViewRow row, string t = "DETAIL")
        {
            InitializeComponent();
            this.type = t;
            this.r = row;
            this.txtamount.Text = row.Cells["AMOUNT"].Value.ToString();
            this.txtamount.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (double.TryParse(this.txtamount.Text.Replace(".", ","), out this.new_amount) && this.new_amount > 0.0)
            {
                if (MyMessage.askMessage("Confirm amount change?"))
                {
                    MyLogger.WriteLog(this.Text + ": change amount");
                    if (this.type == "DETAIL")
                    {
                        try
                        {
                            this.mycon.Open();
                            SqlCommand sqlCommand = new SqlCommand("UPDATE T_CSR_DETAIL SET BUCKET_VALUE = @a1 WHERE ID_CSR_DETAIL = @a2", this.mycon);
                            sqlCommand.Parameters.Add("@a1", SqlDbType.Float).Value = this.new_amount;
                            sqlCommand.Parameters.Add("@a2", SqlDbType.Int).Value = this.r.Cells["ID_DETAIL"].Value.ToString();
                            sqlCommand.ExecuteNonQuery();
                            this.mycon.Close();
                            this.hasSave = true;
                            base.Close();
                        }
                        catch (Exception ex)
                        {
                            MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                            MyLogger.WriteLog(this.Text + ": " + ex.Message);
                            if (this.mycon.State == ConnectionState.Open)
                            {
                                this.mycon.Close();
                            }
                        }
                    }
                }
            }
            else
            {
                MyMessage.showMessage("Invalid amount", MessageBoxIcon.Hand);
            }
        }
    }
}
