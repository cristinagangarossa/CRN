﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Credit_risk_lib;
using System.Data.OleDb;
using System.Data;
using Excel = Microsoft.Office.Interop.Excel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace WriteOff
{
    public static class generalData
    {

        private static SqlConnection con;
        private static SqlCommand queryInsertFromCSR = new SqlCommand("INSERT INTO T_CSR_MONTHLY (MERCHANT_NUM, MERCHANT_NAME, COLLECTOR_USER, MONTH, YEAR)  OUTPUT INSERTED.ID_CSR_MONTHLY VALUES (@num, @name, @collector, @month, @year)", generalData.con);
        private static SqlCommand queryInsertFromCSRDetail = new SqlCommand("INSERT INTO T_CSR_DETAIL (ID_CSR_MONTHLY, BUCKET_NAME, BUCKET_VALUE, GLACCOUNT) VALUES (@mid, @name, @value, @glaccount)", generalData.con);
        private static SqlCommand queryInsertFromCSRreport = new SqlCommand("INSERT INTO T_CSR_REPORT (MERCHANT_NUM, TOT_BAL, MERCHANT_NAME, OPN_1_30, OPN_31_60, OPN_61_90, OPN_91_120, OPN_121_150, OPN_151_180, OPN_181_210, OPN_211_240, OPN_241_270, OPN_271_300, OPN_301_330, OPN_331_360, OPN_360, COLLECTOR_USER, MONTH, YEAR) VALUES (@a1, @a2, @a3, @a4, @a5, @a6, @a7, @a8, @a9, @a10, @a11, @a12, @a13, @a14, @a15, @a16, @a17, @a18, @a19)", generalData.con);
        private static SqlCommand queryInsertFromCSR3112 = new SqlCommand("INSERT INTO T_CSR_3112 (MERCHANT_NUM, TOT_BAL, MERCHANT_NAME, OPN_1_30, OPN_31_60, OPN_61_90, OPN_91_120, OPN_121_150, OPN_151_180, OPN_181_210, OPN_211_240, OPN_241_270, OPN_271_300, OPN_301_330, OPN_331_360, OPN_360, COLLECTOR_USER, PERIOD) VALUES (@a1, @a2, @a3, @a4, @a5, @a6, @a7, @a8, @a9, @a10, @a11, @a12, @a13, @a14, @a15, @a16, @a17, @a18)", generalData.con);
        public static SqlConnection get_con()
        {
            return new SqlConnection(MyConnection.con_string_db_writeoff);
        }
        public static int valueMonth(string m)
        {
            int result;
            switch (m)
            {
                case "January":
                    result = 1;
                    return result;
                case "February":
                    result = 2;
                    return result;
                case "March":
                    result = 3;
                    return result;
                case "April":
                    result = 4;
                    return result;
                case "May":
                    result = 5;
                    return result;
                case "June":
                    result = 6;
                    return result;
                case "July":
                    result = 7;
                    return result;
                case "August":
                    result = 8;
                    return result;
                case "September":
                    result = 9;
                    return result;
                case "October":
                    result = 10;
                    return result;
                case "November":
                    result = 11;
                    return result;
                case "December":
                    result = 12;
                    return result;
            }
            result = 0;
            return result;
        }
        public static void readXLS(ref OleDbDataReader dr, ref SqlConnection con, int anno, int mese)
        {
            if (generalData.queryInsertFromCSR.Parameters.Count == 0)
            {
                generalData.queryInsertFromCSR.Parameters.Add("@num", SqlDbType.VarChar);
                generalData.queryInsertFromCSR.Parameters.Add("@name", SqlDbType.VarChar);
                generalData.queryInsertFromCSR.Parameters.Add("@collector", SqlDbType.VarChar);
                generalData.queryInsertFromCSR.Parameters.Add("@month", SqlDbType.SmallInt);
                generalData.queryInsertFromCSR.Parameters.Add("@year", SqlDbType.SmallInt);
            }
            if (generalData.queryInsertFromCSRDetail.Parameters.Count == 0)
            {
                generalData.queryInsertFromCSRDetail.Parameters.Add("@mid", SqlDbType.Int);
                generalData.queryInsertFromCSRDetail.Parameters.Add("@name", SqlDbType.Int);
                generalData.queryInsertFromCSRDetail.Parameters.Add("@value", SqlDbType.Float);
                generalData.queryInsertFromCSRDetail.Parameters.Add("@glaccount", SqlDbType.VarChar);
            }
            generalData.queryInsertFromCSR.Connection = con;
            generalData.queryInsertFromCSRDetail.Connection = con;
            generalData.queryInsertFromCSR.Parameters["@num"].Value = dr[0];
            generalData.queryInsertFromCSR.Parameters["@name"].Value = dr[2];
            generalData.queryInsertFromCSR.Parameters["@collector"].Value = dr[7];
            generalData.queryInsertFromCSR.Parameters["@month"].Value = mese;
            generalData.queryInsertFromCSR.Parameters["@year"].Value = anno;
            string value = generalData.queryInsertFromCSR.ExecuteScalar().ToString();
            string value2 = generalData.get_GLACCOUNT(dr[7].ToString(), (double)dr[1]);
            int num = 1;
            for (int i = 31; i <= 43; i++)
            {
                if (double.Parse(dr[i].ToString()) > 0.0)
                {
                    generalData.queryInsertFromCSRDetail.Parameters["@mid"].Value = value;
                    generalData.queryInsertFromCSRDetail.Parameters["@name"].Value = num;
                    generalData.queryInsertFromCSRDetail.Parameters["@value"].Value = double.Parse(dr[i].ToString());
                    generalData.queryInsertFromCSRDetail.Parameters["@glaccount"].Value = value2;
                    generalData.queryInsertFromCSRDetail.ExecuteNonQuery();
                }
                num++;
            }
        }
        public static void readXLS_REPORT(ref OleDbDataReader dr, ref SqlConnection con, int anno, int mese)
        {
            if (generalData.queryInsertFromCSRreport.Parameters.Count == 0)
            {
                generalData.queryInsertFromCSRreport.Parameters.Add("@a1", SqlDbType.VarChar);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a2", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a3", SqlDbType.VarChar);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a4", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a5", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a6", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a7", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a8", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a9", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a10", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a11", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a12", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a13", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a14", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a15", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a16", SqlDbType.Float);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a17", SqlDbType.VarChar);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a18", SqlDbType.SmallInt);
                generalData.queryInsertFromCSRreport.Parameters.Add("@a19", SqlDbType.SmallInt);
            }
            generalData.queryInsertFromCSRreport.Connection = con;
            generalData.queryInsertFromCSRreport.Parameters["@a1"].Value = dr[0];
            generalData.queryInsertFromCSRreport.Parameters["@a2"].Value = dr[1];
            generalData.queryInsertFromCSRreport.Parameters["@a3"].Value = dr[2];
            generalData.queryInsertFromCSRreport.Parameters["@a4"].Value = dr[31];
            generalData.queryInsertFromCSRreport.Parameters["@a5"].Value = dr[32];
            generalData.queryInsertFromCSRreport.Parameters["@a6"].Value = dr[33];
            generalData.queryInsertFromCSRreport.Parameters["@a7"].Value = dr[34];
            generalData.queryInsertFromCSRreport.Parameters["@a8"].Value = dr[35];
            generalData.queryInsertFromCSRreport.Parameters["@a9"].Value = dr[36];
            generalData.queryInsertFromCSRreport.Parameters["@a10"].Value = dr[37];
            generalData.queryInsertFromCSRreport.Parameters["@a11"].Value = dr[38];
            generalData.queryInsertFromCSRreport.Parameters["@a12"].Value = dr[39];
            generalData.queryInsertFromCSRreport.Parameters["@a13"].Value = dr[40];
            generalData.queryInsertFromCSRreport.Parameters["@a14"].Value = dr[41];
            generalData.queryInsertFromCSRreport.Parameters["@a15"].Value = dr[42];
            generalData.queryInsertFromCSRreport.Parameters["@a16"].Value = dr[43];
            generalData.queryInsertFromCSRreport.Parameters["@a17"].Value = dr[7];
            generalData.queryInsertFromCSRreport.Parameters["@a18"].Value = mese;
            generalData.queryInsertFromCSRreport.Parameters["@a19"].Value = anno;
            generalData.queryInsertFromCSRreport.ExecuteNonQuery();
        }
        public static void readXLS3112(ref OleDbDataReader dr, ref SqlConnection con, string anno)
        {
            if (generalData.queryInsertFromCSR3112.Parameters.Count == 0)
            {
                generalData.queryInsertFromCSR3112.Parameters.Add("@a1", SqlDbType.VarChar);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a2", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a3", SqlDbType.VarChar);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a4", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a5", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a6", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a7", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a8", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a9", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a10", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a11", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a12", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a13", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a14", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a15", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a16", SqlDbType.Float);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a17", SqlDbType.VarChar);
                generalData.queryInsertFromCSR3112.Parameters.Add("@a18", SqlDbType.SmallInt);
            }
            generalData.queryInsertFromCSR3112.Connection = con;
            generalData.queryInsertFromCSR3112.Parameters["@a1"].Value = dr[0];
            generalData.queryInsertFromCSR3112.Parameters["@a2"].Value = dr[1];
            generalData.queryInsertFromCSR3112.Parameters["@a3"].Value = dr[2];
            generalData.queryInsertFromCSR3112.Parameters["@a4"].Value = dr[31];
            generalData.queryInsertFromCSR3112.Parameters["@a5"].Value = dr[32];
            generalData.queryInsertFromCSR3112.Parameters["@a6"].Value = dr[33];
            generalData.queryInsertFromCSR3112.Parameters["@a7"].Value = dr[34];
            generalData.queryInsertFromCSR3112.Parameters["@a8"].Value = dr[35];
            generalData.queryInsertFromCSR3112.Parameters["@a9"].Value = dr[36];
            generalData.queryInsertFromCSR3112.Parameters["@a10"].Value = dr[37];
            generalData.queryInsertFromCSR3112.Parameters["@a11"].Value = dr[38];
            generalData.queryInsertFromCSR3112.Parameters["@a12"].Value = dr[39];
            generalData.queryInsertFromCSR3112.Parameters["@a13"].Value = dr[40];
            generalData.queryInsertFromCSR3112.Parameters["@a14"].Value = dr[41];
            generalData.queryInsertFromCSR3112.Parameters["@a15"].Value = dr[42];
            generalData.queryInsertFromCSR3112.Parameters["@a16"].Value = dr[43];
            generalData.queryInsertFromCSR3112.Parameters["@a17"].Value = dr[7];
            generalData.queryInsertFromCSR3112.Parameters["@a18"].Value = anno;
            generalData.queryInsertFromCSR3112.ExecuteNonQuery();
        }
        public static DataTable get_DataTable()
        {
            return new DataTable
            {
                Columns = 
				{
					
					{
						"ID_M",
						typeof(int)
					},
					
					{
						"MERCHANT_ID",
						typeof(string)
					},
					
					{
						"MERCHANT_NAME",
						typeof(string)
					},
					
					{
						"TRANSACTION_TYPE",
						typeof(string)
					},
					
					{
						"GL_ACCOUNT",
						typeof(string)
					},
					
					{
						"AMOUNT",
						typeof(double)
					},
					
					{
						"BUCKET",
						typeof(string)
					},
					
					{
						"WRITE-OFF_REASON",
						typeof(string)
					},
					
					{
						"COLLECTOR_USER",
						typeof(string)
					}
				}
            };
        }
        public static DataTable get_DataTable_detail()
        {
            return new DataTable
            {
                Columns = 
				{
					
					{
						"ID_DETAIL",
						typeof(int)
					},
					
					{
						"ID_MID",
						typeof(int)
					},
					
					{
						"MERCHANT_ID",
						typeof(string)
					},
					
					{
						"MERCHANT_NAME",
						typeof(string)
					},
					
					{
						"GL_ACCOUNT",
						typeof(string)
					},
					
					{
						"AMOUNT",
						typeof(double)
					},
					
					{
						"BUCKET",
						typeof(string)
					},
					
					{
						"IS_ERROR",
						typeof(bool)
					},
					
					{
						"IS_CANCEL",
						typeof(bool)
					},
					
					{
						"COLLECTOR_USER",
						typeof(string)
					}
				}
            };
        }
        public static DataTable get_DataTable_report()
        {
            return new DataTable
            {
                Columns = 
				{
					
					{
						"ID_M",
						typeof(int)
					},
					
					{
						"COLLECTOR_USER",
						typeof(string)
					},
					
					{
						"MID",
						typeof(string)
					},
					
					{
						"MERCHANT NAME",
						typeof(string)
					},
					
					{
						"TRANSACTION TYPE",
						typeof(string)
					},
					
					{
						"AMOUNT",
						typeof(double)
					},
					
					{
						"BUCKET",
						typeof(string)
					}
				}
            };
        }
        public static void setTotal(ref Microsoft.Office.Interop.Excel.Worksheet sheet, int row)
        {
            Excel.Range range = sheet.get_Range("E" + row, "E" + row);
            range.Interior.Color = ColorTranslator.ToOle(Color.Wheat);
            int num = 6;
            if (row > 6)
            {
                num = row - 1;
            }
            range = sheet.get_Range("E6:E" + row, Type.Missing);
            range.Style = "Valuta";
            range = sheet.get_Range("A6", "H" + num);
            range.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            int num2 = (row > 7) ? row : 8;
            range = sheet.get_Range("E" + num2, "E" + num2);
            sheet.Cells[num2, 5] = string.Concat(new object[]
			{
				"=SUM(E",
				6,
				":E",
				num,
				")"
			});
            range.Font.Size = 14;
            range.Font.Bold = true;
            range.RowHeight = 30;
            range.VerticalAlignment = 2;
            range.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            range.Borders.Weight = 3.0;
        }
        public static void setColumnName(ref Microsoft.Office.Interop.Excel.Worksheet sheet, bool col = false)
        {
            sheet.Cells[5, 1] = "Merchant Name";
            sheet.Cells[5, 2] = "MID";
            sheet.Cells[5, 3] = "Transaction\nType";
            sheet.Cells[5, 4] = "Account\n Number";
            sheet.Cells[5, 5] = "Amount";
            sheet.Cells[5, 6] = "Bucket";
            sheet.Cells[5, 7] = "Write-off Reason";
            if (col)
            {
                sheet.Cells[5, 8] = "Dep.";
            }
            Excel.Range range = sheet.get_Range("A5:H5", Type.Missing);
            range.VerticalAlignment = 2;
            range.Interior.Color = ColorTranslator.ToOle(Color.Wheat);
            range.Font.Bold = true;
        }
        public static void setColumnNameRecostruction(ref Microsoft.Office.Interop.Excel.Worksheet sheet)
        {
            sheet.Cells[1, 1] = "Merchant Num";
            sheet.Cells[1, 2] = "BDA Name";
            sheet.Cells[1, 3] = "Bucket 31/12";
            sheet.Cells[1, 4] = "Saldo 31/12";
            sheet.Cells[1, 5] = "WO 51101";
            sheet.Cells[1, 6] = "WO 54008";
            sheet.Cells[1, 7] = "WO 53202";
            sheet.Cells[1, 8] = "Recuperato";
            sheet.Cells[1, 9] = "Outstanding";
            sheet.Cells[1, 10] = "New Debt";
            sheet.Cells[1, 11] = "Saldo del mese";
            Excel.Range range = sheet.get_Range("A1:K1", Type.Missing);
            range.VerticalAlignment = 2;
            range.Interior.Color = ColorTranslator.ToOle(Color.Wheat);
            range.Font.Bold = true;
            Excel.Range range2 = sheet.get_Range("E:K", Type.Missing);
            range2.NumberFormat = "0.0";
            Excel.Range range3 = sheet.get_Range("A:K", Type.Missing);
            range3.EntireColumn.AutoFit();
        }
        public static void setHeader(ref Microsoft.Office.Interop.Excel.Worksheet sheet, string txt)
        {
            Excel.Range range = sheet.get_Range("A1", "H1");
            range.Merge(false);
            range.set_Value(Missing.Value, txt);
            range.HorizontalAlignment = 3;
            range.VerticalAlignment = 2;
            range.Borders.LineStyle = Excel.XlLineStyle.xlDouble;
            range.RowHeight = 60;
            range.Font.Bold = true;
            range.Font.Size = 20;
            range.Interior.Color = ColorTranslator.ToOle(Color.LightGray);
            range.Interior.Pattern = Excel.XlPattern.xlPatternSolid;
            sheet.get_Range("A:A", Type.Missing).ColumnWidth = 24.5;
            sheet.get_Range("B:B", Type.Missing).ColumnWidth = 20;
            sheet.get_Range("C:C", Type.Missing).ColumnWidth = 13;
            sheet.get_Range("D:D", Type.Missing).ColumnWidth = 9.5;
            sheet.get_Range("E:E", Type.Missing).ColumnWidth = 17;
            sheet.get_Range("F:F", Type.Missing).ColumnWidth = 15;
            sheet.get_Range("G:G", Type.Missing).ColumnWidth = 68.5;
            sheet.get_Range("H:H", Type.Missing).ColumnWidth = 5;
            sheet.Cells[3, 1] = "From:";
            range = sheet.get_Range("B3", "B3");
            sheet.Cells[3, 2] = "Credit & Risk Dept.";
            range.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
            sheet.Cells[3, 5] = "To:";
            range = sheet.get_Range("G3", "G3");
            range.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
            range = sheet.get_Range("B:H", Type.Missing);
            range.HorizontalAlignment = 3;
        }
        public static string cercaBucket(string d)
        {
            string result;
            MyConsole.enqueue(" d " + d);
            switch (d)
            {
                case "1":
                    result = "1 - 30";
                    return result;
                case "2":
                    result = "31 - 60";
                    return result;
                case "3":
                    result = "61 - 90";
                    return result;
                case "4":
                    result = "91 - 120";
                    return result;
                case "5":
                    result = "121 - 150";
                    return result;
                case "6":
                    result = "151 - 180";
                    return result;
                case "7":
                    result = "181 - 210";
                    return result;
                case "8":
                    result = "211 - 240";
                    return result;
                case "9":
                    result = "241 - 270";
                    return result;
                case "10":
                    result = "271 - 300";
                    return result;
                case "11":
                    result = "301 - 330";
                    return result;
                case "12":
                    result = "331 - 360";
                    return result;
                case "13":
                    result = "360";
                    return result;
            }
            result = d;
            return result;
        }
        public static string creaBucket(string d)
        {
            d = d.Replace(" ", string.Empty );
            string result;
            switch (d)
            {
                case "1-30":
                    result = "1";
                    return result;
                case "31-60":
                    result = "2";
                    return result;
                case "61-90":
                    result = "3";
                    return result;
                case "91-120":
                    result = "4";
                    return result;
                case "121-150":
                    result = "5";
                    return result;
                case "151-180":
                    result = "6";
                    return result;
                case "181-210":
                    result = "7";
                    return result;
                case "211-240":
                    result = "8";
                    return result;
                case "241-270":
                    result = "9";
                    return result;
                case "271-300":
                    result = "10";
                    return result;
                case "301-330":
                    result = "11";
                    return result;
                case "331-360":
                    result = "12";
                    return result;
                case "360":
                    result = "13";
                    return result;
            }
            result = "0";
            return result;
        }
        public static string cercaBucket(SqlDataReader d)
        {
            
            string result = string.Empty;
            for (int i = 16; i >= 4; i--)
            {
                if (Convert.ToDouble(d[i]) > 0.0)
                {
                    result = d.GetName(i).Remove(0, 4).Replace("_", " - ");
                    break;
                }
            }
            return result;
        }
        public static void setFooter(ref Microsoft.Office.Interop.Excel.Worksheet sheet, int row)
        {
            row++;
            Excel.Range range = sheet.get_Range("G" + row, "G" + row);
            range.Font.Italic = true;
            range.RowHeight = 50;
            range.set_Value(Missing.Value, "Sign-off for the approval");
            range.VerticalAlignment = 1;
            range.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;
        }
        public static bool checkExistCSR(string table, string month, string year)
        {
            year = year.Remove(0, 2);
            SqlConnection sqlConnection = generalData.get_con();
            sqlConnection.Open();
            string a = new SqlCommand(string.Concat(new string[]
			{
				"SELECT COUNT(*) FROM ",
				table,
				" WHERE YEAR = ",
				year,
				" AND MONTH = ",
				month
			}), sqlConnection).ExecuteScalar().ToString();
            sqlConnection.Close();
            return a == "0";
        }
        public static bool checkExistCSR(string year)
        {
            SqlConnection sqlConnection = generalData.get_con();
            sqlConnection.Open();
            string a = new SqlCommand("SELECT COUNT(*) FROM T_CSR_3112 WHERE PERIOD = " + year, sqlConnection).ExecuteScalar().ToString();
            sqlConnection.Close();
            return a == "0";
        }
        public static void OverwrittenCSR(string month, string year)
        {
            year = year.Remove(0, 2);
            SqlConnection sqlConnection = generalData.get_con();
            sqlConnection.Open();
            new SqlCommand(string.Concat(new string[]
			{
				"DELETE FROM T_CSR_DETAIL WHERE ID_CSR_MONTHLY IN (SELECT ID_CSR_MONTHLY FROM T_CSR_MONTHLY WHERE YEAR = ",
				year,
				" AND MONTH = ",
				month,
				")"
			}), sqlConnection).ExecuteNonQuery();
            new SqlCommand("DELETE FROM T_CSR_MONTHLY WHERE YEAR = " + year + " AND MONTH = " + month, sqlConnection).ExecuteNonQuery();
            sqlConnection.Close();
        }
        public static void OverwrittenCSR(string year)
        {
            SqlConnection sqlConnection = generalData.get_con();
            sqlConnection.Open();
            new SqlCommand("DELETE FROM T_CSR_3112 WHERE PERIOD = " + year, sqlConnection).ExecuteNonQuery();
            sqlConnection.Close();
        }
        public static void OverwrittenCSR_Report(string month, string year)
        {
            year = year.Remove(0, 2);
            SqlConnection sqlConnection = generalData.get_con();
            sqlConnection.Open();
            new SqlCommand("DELETE FROM T_CSR_REPORT WHERE YEAR = " + year + " AND MONTH = " + month, sqlConnection).ExecuteNonQuery();
            sqlConnection.Close();
        }
        public static string get_GLACCOUNT(string p1, double p2)
        {
            string result;
            if (p1.Trim().ToLower() == "fraud")
            {
                result = "54002";
            }
            else
            {
                if (p2 > 10.0)
                {
                    result = "53202";
                }
                else
                {
                    result = "54008";
                }
            }
            return result;
        }
    }

    public class RowSelezionata
    {
        public int row_scroll
        {
            get;
            set;
        }
        public int mid_visualizzato
        {
            get;
            set;
        }
    }
}
