﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace WriteOff
{
    partial class csrReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private Label lblyear;
        private Label lblsheet;
        private ComboBox tbSheet;
        private Button btncancel;
        private Button btnimport;
        private TextBox tbXslPath;
        private Button btnbrowser;
        private ComboBox combomonth;
        private Label label1;
        private BackgroundWorker myworker;
        private DateTimePicker comboyear;
        private StatusStrip statusStrip1;
        private ToolStripProgressBar myprogressbar;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.lblyear = new Label();
            this.lblsheet = new Label();
            this.tbSheet = new ComboBox();
            this.btncancel = new Button();
            this.btnimport = new Button();
            this.tbXslPath = new TextBox();
            this.btnbrowser = new Button();
            this.combomonth = new ComboBox();
            this.label1 = new Label();
            this.myworker = new BackgroundWorker();
            this.comboyear = new DateTimePicker();
            this.statusStrip1 = new StatusStrip();
            this.myprogressbar = new ToolStripProgressBar();
            this.statusStrip1.SuspendLayout();
            base.SuspendLayout();
            this.lblyear.AutoSize = true;
            this.lblyear.Location = new Point(54, 126);
            this.lblyear.Name = "lblyear";
            this.lblyear.Size = new Size(30, 15);
            this.lblyear.TabIndex = 16;
            this.lblyear.Text = "Year";
            this.lblsheet.AutoSize = true;
            this.lblsheet.Location = new Point(48, 57);
            this.lblsheet.Name = "lblsheet";
            this.lblsheet.Size = new Size(36, 15);
            this.lblsheet.TabIndex = 15;
            this.lblsheet.Text = "Sheet";
            this.tbSheet.DropDownStyle = ComboBoxStyle.DropDownList;
            this.tbSheet.FormattingEnabled = true;
            this.tbSheet.Location = new Point(93, 54);
            this.tbSheet.Name = "tbSheet";
            this.tbSheet.Size = new Size(263, 23);
            this.tbSheet.TabIndex = 2;
            this.btncancel.AutoSize = true;
            this.btncancel.Location = new Point(201, 158);
            this.btncancel.Name = "btncancel";
            this.btncancel.Padding = new Padding(3, 0, 3, 0);
            this.btncancel.Size = new Size(60, 25);
            this.btncancel.TabIndex = 6;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new EventHandler(this.btncancel_Click);
            this.btnimport.AutoSize = true;
            this.btnimport.Location = new Point(89, 158);
            this.btnimport.Name = "btnimport";
            this.btnimport.Padding = new Padding(3, 0, 3, 0);
            this.btnimport.Size = new Size(89, 25);
            this.btnimport.TabIndex = 5;
            this.btnimport.Text = "Start import";
            this.btnimport.UseVisualStyleBackColor = true;
            this.btnimport.Click += new EventHandler(this.btnimport_Click);
            this.tbXslPath.Location = new Point(93, 21);
            this.tbXslPath.Name = "tbXslPath";
            this.tbXslPath.ReadOnly = true;
            this.tbXslPath.Size = new Size(263, 23);
            this.tbXslPath.TabIndex = 10;
            this.tbXslPath.Tag = "File Excel";
            this.btnbrowser.AutoSize = true;
            this.btnbrowser.Location = new Point(15, 19);
            this.btnbrowser.Name = "btnbrowser";
            this.btnbrowser.Padding = new Padding(3, 0, 3, 0);
            this.btnbrowser.Size = new Size(69, 25);
            this.btnbrowser.TabIndex = 1;
            this.btnbrowser.Text = "Browse..";
            this.btnbrowser.UseVisualStyleBackColor = true;
            this.btnbrowser.Click += new EventHandler(this.btnbrowser_Click);
            this.combomonth.DropDownStyle = ComboBoxStyle.DropDownList;
            this.combomonth.FormattingEnabled = true;
            this.combomonth.Items.AddRange(new object[]
			{
				"January ",
				"February ",
				"March ",
				"April ",
				"May ",
				"June ",
				"July ",
				"August",
				"September",
				"October",
				"November",
				"December"
			});
            this.combomonth.Location = new Point(93, 87);
            this.combomonth.Name = "combomonth";
            this.combomonth.Size = new Size(109, 23);
            this.combomonth.TabIndex = 3;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(41, 90);
            this.label1.Name = "label1";
            this.label1.Size = new Size(43, 15);
            this.label1.TabIndex = 18;
            this.label1.Text = "Month";
            this.myworker.WorkerReportsProgress = true;
            this.myworker.DoWork += new DoWorkEventHandler(this.myworker_DoWork);
            this.myworker.ProgressChanged += new ProgressChangedEventHandler(this.myworker_ProgressChanged);
            this.myworker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(this.myworker_RunWorkerCompleted);
            this.comboyear.CustomFormat = "yyyy";
            this.comboyear.Format = DateTimePickerFormat.Custom;
            this.comboyear.Location = new Point(92, 120);
            this.comboyear.Name = "comboyear";
            this.comboyear.ShowUpDown = true;
            this.comboyear.Size = new Size(110, 23);
            this.comboyear.TabIndex = 4;
            this.statusStrip1.Items.AddRange(new ToolStripItem[]
			{
				this.myprogressbar
			});
            this.statusStrip1.Location = new Point(0, 203);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(374, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 28;
            this.statusStrip1.Text = "statusStrip1";
            this.myprogressbar.Name = "myprogressbar";
            this.myprogressbar.Size = new Size(370, 16);
            base.AutoScaleDimensions = new SizeF(7f, 15f);
            this.AutoSize = true;
            base.ClientSize = new Size(374, 225);
            base.Controls.Add(this.statusStrip1);
            base.Controls.Add(this.comboyear);
            base.Controls.Add(this.combomonth);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.lblyear);
            base.Controls.Add(this.lblsheet);
            base.Controls.Add(this.tbSheet);
            base.Controls.Add(this.btncancel);
            base.Controls.Add(this.btnimport);
            base.Controls.Add(this.tbXslPath);
            base.Controls.Add(this.btnbrowser);
            this.Font = new Font("Calibri", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "csrReport";
            base.ShowIcon = false;
            base.ShowInTaskbar = false;
            this.Text = "Writeoff - Import CSR Report";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        #endregion
    }
}