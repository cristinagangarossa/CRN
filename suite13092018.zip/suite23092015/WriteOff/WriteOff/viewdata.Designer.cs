﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace WriteOff
{
    partial class viewdata
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private DataGridView dataview;
        private GroupBox groupSelect;
        private Button btnSearch;
        private ComboBox comboMonth;
        private GroupBox groupBox1;
        private Button btnCancelResearch;
        private TextBox txtsearch;
        private ContextMenuStrip menuRowMerchant;
        private GroupBox groupBox2;
        private Label lblNormal;
        private Label lblerror;
        private Label lblmountlow;
        private Label lblfreud;
        private Button btnsearchmid;
        private DateTimePicker comboYear;
        private ToolStripMenuItem changeAmountToolStripMenuItem;
        private ToolStripMenuItem excludeToolStripMenuItem;
        private DataGridView datadetail;
        private SplitContainer splitContainer1;
        private ContextMenuStrip menuRowAccount_2;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem restoreToolStripMenuItem1;
        private ToolStrip toolStrip1;
        private ToolStripButton toolStripButton1;
        private ToolStripButton toolStripButton2;
        private ContextMenuStrip menuRowMerchant_2;
        private ToolStripMenuItem toolStripMenuItem4;
        private ToolStripMenuItem toolStripMenuItem6;
        private ContextMenuStrip menuRowAccount;
        private ToolStripMenuItem toolStripMenuItem7;
        private ToolStripMenuItem toolStripMenuItem8;
        private ToolStripMenuItem toolStripMenuItem9;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem1;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataview = new System.Windows.Forms.DataGridView();
            this.menuRowMerchant = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.changeAmountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excludeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupSelect = new System.Windows.Forms.GroupBox();
            this.comboYear = new System.Windows.Forms.DateTimePicker();
            this.btnSearch = new System.Windows.Forms.Button();
            this.comboMonth = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnsearchmid = new System.Windows.Forms.Button();
            this.btnCancelResearch = new System.Windows.Forms.Button();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblNormal = new System.Windows.Forms.Label();
            this.lblerror = new System.Windows.Forms.Label();
            this.lblmountlow = new System.Windows.Forms.Label();
            this.lblfreud = new System.Windows.Forms.Label();
            this.datadetail = new System.Windows.Forms.DataGridView();
            this.menuRowAccount_2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.restoreToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.menuRowMerchant_2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRowAccount = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataview)).BeginInit();
            this.menuRowMerchant.SuspendLayout();
            this.groupSelect.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datadetail)).BeginInit();
            this.menuRowAccount_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.menuRowMerchant_2.SuspendLayout();
            this.menuRowAccount.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataview
            // 
            this.dataview.AllowUserToAddRows = false;
            this.dataview.AllowUserToDeleteRows = false;
            this.dataview.AllowUserToResizeRows = false;
            this.dataview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataview.Location = new System.Drawing.Point(0, 0);
            this.dataview.Name = "dataview";
            this.dataview.ReadOnly = true;
            this.dataview.RowHeadersVisible = false;
            this.dataview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataview.Size = new System.Drawing.Size(1009, 194);
            this.dataview.TabIndex = 0;
            this.dataview.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataview_CellMouseDown);
            this.dataview.SelectionChanged += new System.EventHandler(this.dataview_SelectionChanged);
            this.dataview.Sorted += new System.EventHandler(this.dataview_Sorted);
            // 
            // menuRowMerchant
            // 
            this.menuRowMerchant.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeAmountToolStripMenuItem,
            this.excludeToolStripMenuItem});
            this.menuRowMerchant.Name = "menuRow";
            this.menuRowMerchant.Size = new System.Drawing.Size(163, 48);
            // 
            // changeAmountToolStripMenuItem
            // 
            this.changeAmountToolStripMenuItem.Name = "changeAmountToolStripMenuItem";
            this.changeAmountToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.changeAmountToolStripMenuItem.Text = "Change Amount";
            this.changeAmountToolStripMenuItem.Click += new System.EventHandler(this.changeAmountToolStripMenuItem_Click);
            // 
            // excludeToolStripMenuItem
            // 
            this.excludeToolStripMenuItem.Name = "excludeToolStripMenuItem";
            this.excludeToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.excludeToolStripMenuItem.Text = "Exclude";
            this.excludeToolStripMenuItem.Click += new System.EventHandler(this.excludeToolStripMenuItem_Click);
            // 
            // groupSelect
            // 
            this.groupSelect.Controls.Add(this.comboYear);
            this.groupSelect.Controls.Add(this.btnSearch);
            this.groupSelect.Controls.Add(this.comboMonth);
            this.groupSelect.Location = new System.Drawing.Point(14, 30);
            this.groupSelect.Name = "groupSelect";
            this.groupSelect.Size = new System.Drawing.Size(326, 63);
            this.groupSelect.TabIndex = 1;
            this.groupSelect.TabStop = false;
            this.groupSelect.Text = "Select parameters";
            // 
            // comboYear
            // 
            this.comboYear.CustomFormat = "yyyy";
            this.comboYear.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.comboYear.Location = new System.Drawing.Point(164, 25);
            this.comboYear.Name = "comboYear";
            this.comboYear.ShowUpDown = true;
            this.comboYear.Size = new System.Drawing.Size(81, 23);
            this.comboYear.TabIndex = 1;
            // 
            // btnSearch
            // 
            this.btnSearch.AutoSize = true;
            this.btnSearch.Location = new System.Drawing.Point(253, 24);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnSearch.Size = new System.Drawing.Size(64, 25);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Explore";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // comboMonth
            // 
            this.comboMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboMonth.FormattingEnabled = true;
            this.comboMonth.Items.AddRange(new object[] {
            "January ",
            "February ",
            "March ",
            "April ",
            "May ",
            "June ",
            "July ",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.comboMonth.Location = new System.Drawing.Point(13, 24);
            this.comboMonth.Name = "comboMonth";
            this.comboMonth.Size = new System.Drawing.Size(140, 23);
            this.comboMonth.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.btnsearchmid);
            this.groupBox1.Controls.Add(this.btnCancelResearch);
            this.groupBox1.Controls.Add(this.txtsearch);
            this.groupBox1.Location = new System.Drawing.Point(721, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(302, 63);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search MID";
            // 
            // btnsearchmid
            // 
            this.btnsearchmid.AutoSize = true;
            this.btnsearchmid.Location = new System.Drawing.Point(164, 24);
            this.btnsearchmid.Name = "btnsearchmid";
            this.btnsearchmid.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnsearchmid.Size = new System.Drawing.Size(60, 25);
            this.btnsearchmid.TabIndex = 4;
            this.btnsearchmid.Text = "Search";
            this.btnsearchmid.UseVisualStyleBackColor = true;
            this.btnsearchmid.Click += new System.EventHandler(this.btnsearchmid_Click_1);
            // 
            // btnCancelResearch
            // 
            this.btnCancelResearch.AutoSize = true;
            this.btnCancelResearch.Location = new System.Drawing.Point(230, 24);
            this.btnCancelResearch.Name = "btnCancelResearch";
            this.btnCancelResearch.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnCancelResearch.Size = new System.Drawing.Size(60, 25);
            this.btnCancelResearch.TabIndex = 5;
            this.btnCancelResearch.Text = "Cancel";
            this.btnCancelResearch.UseVisualStyleBackColor = true;
            this.btnCancelResearch.Click += new System.EventHandler(this.btnCancelResearch_Click);
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(7, 25);
            this.txtsearch.MaxLength = 11;
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(151, 23);
            this.txtsearch.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.lblNormal);
            this.groupBox2.Controls.Add(this.lblerror);
            this.groupBox2.Controls.Add(this.lblmountlow);
            this.groupBox2.Controls.Add(this.lblfreud);
            this.groupBox2.Location = new System.Drawing.Point(14, 490);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(749, 54);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Legend";
            // 
            // lblNormal
            // 
            this.lblNormal.AutoSize = true;
            this.lblNormal.BackColor = System.Drawing.Color.White;
            this.lblNormal.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNormal.ForeColor = System.Drawing.Color.Black;
            this.lblNormal.Location = new System.Drawing.Point(565, 20);
            this.lblNormal.Name = "lblNormal";
            this.lblNormal.Padding = new System.Windows.Forms.Padding(12, 6, 12, 6);
            this.lblNormal.Size = new System.Drawing.Size(108, 27);
            this.lblNormal.TabIndex = 3;
            this.lblNormal.Text = "AMOUNT > 10";
            // 
            // lblerror
            // 
            this.lblerror.AutoSize = true;
            this.lblerror.BackColor = System.Drawing.Color.LightBlue;
            this.lblerror.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblerror.ForeColor = System.Drawing.Color.Black;
            this.lblerror.Location = new System.Drawing.Point(401, 20);
            this.lblerror.Name = "lblerror";
            this.lblerror.Padding = new System.Windows.Forms.Padding(12, 6, 12, 6);
            this.lblerror.Size = new System.Drawing.Size(67, 27);
            this.lblerror.TabIndex = 2;
            this.lblerror.Text = "ERROR";
            // 
            // lblmountlow
            // 
            this.lblmountlow.AutoSize = true;
            this.lblmountlow.BackColor = System.Drawing.Color.LightCyan;
            this.lblmountlow.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmountlow.ForeColor = System.Drawing.Color.Black;
            this.lblmountlow.Location = new System.Drawing.Point(194, 20);
            this.lblmountlow.Name = "lblmountlow";
            this.lblmountlow.Padding = new System.Windows.Forms.Padding(12, 6, 12, 6);
            this.lblmountlow.Size = new System.Drawing.Size(108, 27);
            this.lblmountlow.TabIndex = 1;
            this.lblmountlow.Text = "AMOUNT < 10";
            // 
            // lblfreud
            // 
            this.lblfreud.AutoSize = true;
            this.lblfreud.BackColor = System.Drawing.Color.LightCoral;
            this.lblfreud.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfreud.ForeColor = System.Drawing.Color.Black;
            this.lblfreud.Location = new System.Drawing.Point(33, 20);
            this.lblfreud.Name = "lblfreud";
            this.lblfreud.Padding = new System.Windows.Forms.Padding(12, 6, 12, 6);
            this.lblfreud.Size = new System.Drawing.Size(68, 27);
            this.lblfreud.TabIndex = 0;
            this.lblfreud.Text = "FRAUD";
            // 
            // datadetail
            // 
            this.datadetail.AllowUserToAddRows = false;
            this.datadetail.AllowUserToDeleteRows = false;
            this.datadetail.AllowUserToResizeRows = false;
            this.datadetail.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.datadetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datadetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datadetail.Location = new System.Drawing.Point(0, 0);
            this.datadetail.Name = "datadetail";
            this.datadetail.ReadOnly = true;
            this.datadetail.RowHeadersVisible = false;
            this.datadetail.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datadetail.Size = new System.Drawing.Size(1009, 186);
            this.datadetail.TabIndex = 6;
            // 
            // menuRowAccount_2
            // 
            this.menuRowAccount_2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.restoreToolStripMenuItem1,
            this.deleteToolStripMenuItem});
            this.menuRowAccount_2.Name = "menuRow";
            this.menuRowAccount_2.Size = new System.Drawing.Size(172, 92);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(171, 22);
            this.toolStripMenuItem1.Text = "Change state Error";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(171, 22);
            this.toolStripMenuItem2.Text = "Change Amount";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // restoreToolStripMenuItem1
            // 
            this.restoreToolStripMenuItem1.Name = "restoreToolStripMenuItem1";
            this.restoreToolStripMenuItem1.Size = new System.Drawing.Size(171, 22);
            this.restoreToolStripMenuItem1.Text = "Restore";
            this.restoreToolStripMenuItem1.Click += new System.EventHandler(this.restoreToolStripMenuItem1_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(14, 99);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dataview);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.datadetail);
            this.splitContainer1.Size = new System.Drawing.Size(1009, 385);
            this.splitContainer1.SplitterDistance = 194;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 7;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Enabled = false;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1037, 25);
            this.toolStrip1.TabIndex = 9;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = global::WriteOff.Properties.Resources.toolStripButton2;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Black;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(66, 22);
            this.toolStripButton2.Text = "Restore";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // menuRowMerchant_2
            // 
            this.menuRowMerchant_2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem4,
            this.toolStripMenuItem6,
            this.deleteToolStripMenuItem1});
            this.menuRowMerchant_2.Name = "menuRow";
            this.menuRowMerchant_2.Size = new System.Drawing.Size(163, 70);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(162, 22);
            this.toolStripMenuItem4.Text = "Change Amount";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.changeAmountToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(162, 22);
            this.toolStripMenuItem6.Text = "Restore";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.restoreToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem1
            // 
            this.deleteToolStripMenuItem1.Name = "deleteToolStripMenuItem1";
            this.deleteToolStripMenuItem1.Size = new System.Drawing.Size(162, 22);
            this.deleteToolStripMenuItem1.Text = "Delete";
            this.deleteToolStripMenuItem1.Click += new System.EventHandler(this.deleteToolStripMenuItem1_Click);
            // 
            // menuRowAccount
            // 
            this.menuRowAccount.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9});
            this.menuRowAccount.Name = "menuRow";
            this.menuRowAccount.Size = new System.Drawing.Size(172, 70);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(171, 22);
            this.toolStripMenuItem7.Text = "Change state Error";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(171, 22);
            this.toolStripMenuItem8.Text = "Change Amount";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(171, 22);
            this.toolStripMenuItem9.Text = "Exclude";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = global::WriteOff.Properties.Resources.toolStripButton3;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Black;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(67, 22);
            this.toolStripButton1.Text = "Exclude";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // viewdata
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 556);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupSelect);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "viewdata";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Explore monthly data";
            ((System.ComponentModel.ISupportInitialize)(this.dataview)).EndInit();
            this.menuRowMerchant.ResumeLayout(false);
            this.groupSelect.ResumeLayout(false);
            this.groupSelect.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datadetail)).EndInit();
            this.menuRowAccount_2.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.menuRowMerchant_2.ResumeLayout(false);
            this.menuRowAccount.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}