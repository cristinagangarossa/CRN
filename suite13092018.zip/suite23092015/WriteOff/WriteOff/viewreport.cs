﻿using Credit_risk_lib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WriteOff
{
    public partial class viewreport : Form
    {

        private SqlConnection mycon = generalData.get_con();
        private DataTable dt;
        public viewreport()
        {
            InitializeComponent();
            this.comboMonth.SelectedIndex = 0;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.InterrogaReport();
        }
        private void InterrogaReport()
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                this.dt = generalData.get_DataTable_report();
                this.mycon.Open();
                SqlDataReader sqlDataReader;
                if (string.IsNullOrWhiteSpace(this.txtsearch.Text))
                {
                    sqlDataReader = new SqlCommand(string.Concat(new object[]
					{
						"SELECT * FROM T_CSR_REPORT WHERE MONTH = ",
						generalData.valueMonth(this.comboMonth.Text.Trim()),
						" AND YEAR = ",
						this.comboYear.Text.Remove(0, 2)
					}), this.mycon).ExecuteReader();
                }
                else
                {
                    sqlDataReader = new SqlCommand(string.Concat(new object[]
					{
						"SELECT * FROM T_CSR_REPORT WHERE MERCHANT_NUM LIKE '",
						this.txtsearch.Text.Trim(),
						"%' AND MONTH = ",
						generalData.valueMonth(this.comboMonth.Text.Trim()),
						" AND YEAR = ",
						this.comboYear.Text.Remove(0, 2)
					}), this.mycon).ExecuteReader();
                }
                this.riempiDT_unPacked(ref sqlDataReader);
                this.mycon.Close();
                this.dataview.DataSource = this.dt;
                this.dataview.Columns["ID_M"].Visible = false;
                this.dataview.Columns["COLLECTOR_USER"].Visible = false;
                this.dataview.Columns["AMOUNT"].DefaultCellStyle.Format = "C2";
                Cursor.Current = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                Cursor.Current = Cursors.Default;
                if (this.mycon.State == ConnectionState.Open)
                {
                    this.mycon.Close();
                }
            }
        }
        private void riempiDT_unPacked(ref SqlDataReader d)
        {
            while (d.Read())
            {
                for (int i = 16; i >= 4; i--)
                {
                    if (Convert.ToDouble(d[i]) > 0.0)
                    {
                        DataRow dataRow = this.dt.NewRow();
                        dataRow["ID_M"] = d["ID_CSR_REPORT"].ToString();
                        dataRow["COLLECTOR_USER"] = d["COLLECTOR_USER"].ToString();
                        dataRow["MID"] = d["MERCHANT_NUM"].ToString();
                        dataRow["MERCHANT NAME"] = d["MERCHANT_NAME"].ToString();
                        dataRow["TRANSACTION TYPE"] = "MSI SCR";
                        dataRow["AMOUNT"] = double.Parse(d[i].ToString());
                        dataRow["BUCKET"] = d.GetName(i).Remove(0, 4).Replace("_", " - ");
                        this.dt.Rows.Add(dataRow);
                    }
                }
            }
        }
        private void btnCancelResearch_Click(object sender, EventArgs e)
        {
            this.txtsearch.Text = string.Empty;
            this.InterrogaReport();
        }
        public DataGridViewRowCollection get_datagrid()
        {
            return this.dataview.Rows;
        }
        private void btnsearchmid_Click_1(object sender, EventArgs e)
        {
            this.InterrogaReport();
        }
    }
}
