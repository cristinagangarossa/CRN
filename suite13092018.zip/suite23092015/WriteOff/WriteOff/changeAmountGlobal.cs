﻿using Credit_risk_lib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WriteOff
{
    public partial class changeAmountGlobal : Form
    {
        private SqlConnection mycon = generalData.get_con();
        private double new_amount = 0.0;
        public bool hasSave = false;
        private DataGridViewRow r;
       
        public changeAmountGlobal(DataGridViewRow row)
        {
            this.InitializeComponent();
            this.r = row;
            this.txtamount.Text = row.Cells["AMOUNT"].Value.ToString();
            this.txtamount.Focus();
            this.mycon.Open();
            SqlDataReader sqlDataReader = new SqlCommand("SELECT * FROM T_CSR_DETAIL WHERE ID_CSR_MONTHLY = " + this.r.Cells["ID_CSR_MONTHLY"].Value.ToString() + " ORDER BY BUCKET_NAME ASC", this.mycon).ExecuteReader();
            while (sqlDataReader.Read())
            {
                this.dataGridView1.Rows.Add(new object[]
				{
					generalData.cercaBucket(sqlDataReader["BUCKET_NAME"].ToString()), double.Parse(sqlDataReader["BUCKET_VALUE"].ToString())
				});
            }
            this.mycon.Close();
            dataGridView1.Sort( dataGridView1.Columns[0] , ListSortDirection.Ascending);
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (double.TryParse(this.txtamount.Text.Replace(".", ","), out this.new_amount) && this.new_amount > 0.0)
            {
                if (MyMessage.askMessage("Confirm amount change?"))
                {
                    MyLogger.WriteLog(this.Text + ": change amount");
                    SqlConnection con = generalData.get_con();
                    try
                    {
                        SqlCommand sqlCommand = new SqlCommand("UPDATE T_CSR_DETAIL SET BUCKET_VALUE = @a1 WHERE ID_CSR_DETAIL = @a2", con);
                        sqlCommand.Parameters.Add("@a1", SqlDbType.Float);
                        sqlCommand.Parameters.Add("@a2", SqlDbType.Int);
                        SqlCommand sqlCommand2 = new SqlCommand("DELETE FROM T_CSR_DETAIL WHERE ID_CSR_DETAIL = @a1", con);
                        sqlCommand2.Parameters.Add("@a1", SqlDbType.Int);
                        this.mycon.Open();
                        con.Open();
                        SqlDataReader sqlDataReader = new SqlCommand("SELECT * FROM T_CSR_DETAIL WHERE ID_CSR_MONTHLY = " + this.r.Cells["ID_CSR_MONTHLY"].Value.ToString() + " ORDER BY BUCKET_NAME ASC", this.mycon).ExecuteReader();
                        while (sqlDataReader.Read())
                        {
                            double num = double.Parse(sqlDataReader["BUCKET_VALUE"].ToString());
                            if (this.new_amount == 0.0)
                            {
                                sqlCommand2.Parameters["@a1"].Value = sqlDataReader["ID_CSR_DETAIL"].ToString();
                                sqlCommand2.ExecuteNonQuery();
                            }
                            else
                            {
                                if (this.new_amount >= num)
                                {
                                    this.new_amount -= num;
                                }
                                else
                                {
                                    sqlCommand.Parameters["@a1"].Value = this.new_amount;
                                    sqlCommand.Parameters["@a2"].Value = sqlDataReader["ID_CSR_DETAIL"].ToString();
                                    sqlCommand.ExecuteNonQuery();
                                    this.new_amount = 0.0;
                                }
                            }
                        }
                        con.Close();
                        this.mycon.Close();
                        this.hasSave = true;
                        base.Close();
                    }
                    catch (Exception ex)
                    {
                        MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                        MyLogger.WriteLog(this.Text + ": " + ex.Message);
                        if (this.mycon.State == ConnectionState.Open)
                        {
                            this.mycon.Close();
                        }
                        if (con.State == ConnectionState.Open)
                        {
                            con.Close();
                        }
                    }
                }
            }
            else
            {
                MyMessage.showMessage("Invalid amount", MessageBoxIcon.Hand);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(this.txtamount.Text.Replace(".", ","), out this.new_amount))
            {
                this.dataGridView1.Rows.Clear();
                this.mycon.Open();
                SqlDataReader sqlDataReader = new SqlCommand("SELECT * FROM T_CSR_DETAIL WHERE ID_CSR_MONTHLY = " + this.r.Cells["ID_CSR_MONTHLY"].Value.ToString() + " ORDER BY BUCKET_NAME ASC", this.mycon).ExecuteReader();
                while (sqlDataReader.Read())
                {
                    double num = double.Parse(sqlDataReader["BUCKET_VALUE"].ToString());
                    if (this.new_amount > 0.0)
                    {
                        if (this.new_amount >= num)
                        {
                            this.new_amount -= num;
                            this.dataGridView1.Rows.Add(new object[] { generalData.cercaBucket(sqlDataReader["BUCKET_NAME"].ToString()),num });
                        }
                        else
                        {
                            this.dataGridView1.Rows.Add(new object[] { generalData.cercaBucket(sqlDataReader["BUCKET_NAME"].ToString()), this.new_amount });
                            this.new_amount = 0.0;
                        }
                    }
                }
                this.mycon.Close();
                dataGridView1.Sort(dataGridView1.Columns[0], ListSortDirection.Ascending);
            }
        }
    }
}
