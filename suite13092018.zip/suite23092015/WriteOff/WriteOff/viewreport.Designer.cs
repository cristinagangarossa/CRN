﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace WriteOff
{
    partial class viewreport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private DataGridView dataview;
        private GroupBox groupSelect;
        private Button btnSearch;
        private ComboBox comboMonth;
        private GroupBox groupBox1;
        private Button btnCancelResearch;
        private TextBox txtsearch;
        private Button btnsearchmid;
        private DateTimePicker comboYear;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(viewreport));
            this.dataview = new DataGridView();
            this.groupSelect = new GroupBox();
            this.comboYear = new DateTimePicker();
            this.btnSearch = new Button();
            this.comboMonth = new ComboBox();
            this.groupBox1 = new GroupBox();
            this.btnsearchmid = new Button();
            this.btnCancelResearch = new Button();
            this.txtsearch = new TextBox();
            ((ISupportInitialize)this.dataview).BeginInit();
            this.groupSelect.SuspendLayout();
            this.groupBox1.SuspendLayout();
            base.SuspendLayout();
            this.dataview.AllowUserToAddRows = false;
            this.dataview.AllowUserToDeleteRows = false;
            this.dataview.AllowUserToResizeRows = false;
            this.dataview.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
            this.dataview.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dataview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataview.Location = new Point(14, 84);
            this.dataview.Name = "dataview";
            this.dataview.ReadOnly = true;
            this.dataview.RowHeadersVisible = false;
            this.dataview.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataview.Size = new Size(992, 430);
            this.dataview.TabIndex = 0;
            this.groupSelect.Controls.Add(this.comboYear);
            this.groupSelect.Controls.Add(this.btnSearch);
            this.groupSelect.Controls.Add(this.comboMonth);
            this.groupSelect.Location = new Point(14, 14);
            this.groupSelect.Name = "groupSelect";
            this.groupSelect.Size = new Size(326, 63);
            this.groupSelect.TabIndex = 1;
            this.groupSelect.TabStop = false;
            this.groupSelect.Text = "Select parameters";
            this.comboYear.CustomFormat = "yyyy";
            this.comboYear.Format = DateTimePickerFormat.Custom;
            this.comboYear.Location = new Point(159, 24);
            this.comboYear.Name = "comboYear";
            this.comboYear.ShowUpDown = true;
            this.comboYear.Size = new Size(81, 23);
            this.comboYear.TabIndex = 1;
            this.btnSearch.AutoSize = true;
            this.btnSearch.Location = new Point(246, 24);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Padding = new Padding(3, 0, 3, 0);
            this.btnSearch.Size = new Size(64, 25);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Explore";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new EventHandler(this.btnSearch_Click);
            this.comboMonth.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboMonth.FormattingEnabled = true;
            this.comboMonth.Items.AddRange(new object[]
			{
				"January",
				"February",
				"March",
				"April",
				"May",
				"June",
				"July",
				"August",
				"September",
				"October",
				"November",
				"December"
			});
            this.comboMonth.Location = new Point(13, 24);
            this.comboMonth.Name = "comboMonth";
            this.comboMonth.Size = new Size(140, 23);
            this.comboMonth.TabIndex = 0;
            this.groupBox1.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
            this.groupBox1.Controls.Add(this.btnsearchmid);
            this.groupBox1.Controls.Add(this.btnCancelResearch);
            this.groupBox1.Controls.Add(this.txtsearch);
            this.groupBox1.Location = new Point(707, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new Size(299, 63);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search MID";
            this.btnsearchmid.AutoSize = true;
            this.btnsearchmid.Location = new Point(163, 23);
            this.btnsearchmid.Name = "btnsearchmid";
            this.btnsearchmid.Padding = new Padding(3, 0, 3, 0);
            this.btnsearchmid.Size = new Size(60, 25);
            this.btnsearchmid.TabIndex = 4;
            this.btnsearchmid.Text = "Search";
            this.btnsearchmid.UseVisualStyleBackColor = true;
            this.btnsearchmid.Click += new EventHandler(this.btnsearchmid_Click_1);
            this.btnCancelResearch.AutoSize = true;
            this.btnCancelResearch.Location = new Point(229, 23);
            this.btnCancelResearch.Name = "btnCancelResearch";
            this.btnCancelResearch.Padding = new Padding(3, 0, 3, 0);
            this.btnCancelResearch.Size = new Size(60, 25);
            this.btnCancelResearch.TabIndex = 1;
            this.btnCancelResearch.Text = "Cancel";
            this.btnCancelResearch.UseVisualStyleBackColor = true;
            this.btnCancelResearch.Click += new EventHandler(this.btnCancelResearch_Click);
            this.txtsearch.Location = new Point(6, 24);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new Size(151, 23);
            this.txtsearch.TabIndex = 3;
            base.AutoScaleDimensions = new SizeF(7f, 15f);
            base.ClientSize = new Size(1020, 528);
            base.Controls.Add(this.groupBox1);
            base.Controls.Add(this.groupSelect);
            base.Controls.Add(this.dataview);
            this.Font = new Font("Calibri", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            base.Name = "viewreport";
            base.ShowInTaskbar = false;
            base.StartPosition = FormStartPosition.CenterParent;
            this.Text = "Explore report data";
            ((ISupportInitialize)this.dataview).EndInit();
            this.groupSelect.ResumeLayout(false);
            this.groupSelect.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            base.ResumeLayout(false);
        }

        #endregion
    }
}