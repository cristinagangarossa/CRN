﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;

namespace WriteOff
{
    public partial class WriteOff : Form
    {
        private string typeofWriteoff;
        private object misValue = Missing.Value;
        private string type;
        private SqlConnection mycon = generalData.get_con();
        private string mese;
        private string anno;
        private string newFilePath = string.Empty;

        public WriteOff(string writeoff, string type_write)
        {
            InitializeComponent();
            this.typeofWriteoff = writeoff;
            string text = this.Text;
            this.Text = string.Concat(new string[]
			{
				text,
				" ",
				type_write,
				" ",
				writeoff
			});
            this.type = type_write;
            this.combomonth.SelectedIndex = 0;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void btnpercorso_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                this.txtpercorso.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.mybar.Value = 0;
            if (MyControl.checkControl(this))
            {
                base.Enabled = false;
                int num = generalData.valueMonth(this.combomonth.Text.Trim());
                this.mese = num.ToString();
                this.anno = this.comboyear.Text.Remove(0, 2);
                MyLogger.WriteLog(string.Concat(this.Text, ": start"));
                this.mywork.RunWorkerAsync(this.typeofWriteoff);
            }
        }

        private void creaXLS_packed(string file)
        {
            Excel.Application variable = new Excel.Application();
            variable.DisplayAlerts = false;
            string[] text = new string[] { this.txtpercorso.Text, "\\", file, "_", null, null };
            text[4] = DateTime.Now.ToString("ddMMyyyy");
            text[5] = ".xls";
            this.newFilePath = string.Concat(text);
            Excel.Workbook variable1 = variable.Workbooks.Add(Missing.Value);
            Excel.Worksheet item = (Excel.Worksheet)((dynamic)variable1.Worksheets[1]);
            item.PageSetup.Orientation = Excel.XlPageOrientation.xlLandscape;
            item.PageSetup.PaperSize = Excel.XlPaperSize.xlPaperA4;
            item.PageSetup.Zoom = false;
            item.PageSetup.FitToPagesWide = 1;
            item.PageSetup.FitToPagesTall = 1;
            this.mycon.Open();
            int num = 6;
            text = new string[] { "SELECT COUNT(DISTINCT C.MERCHANT_NUM) FROM T_CSR_MONTHLY as C INNER JOIN T_CSR_DETAIL D ON D.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY WHERE C.IS_CANCEL <> 1 AND D.GLACCOUNT = '", file, "' and  C.MONTH = ", this.mese, " AND C.YEAR = ", this.anno };
            int num1 = int.Parse((new SqlCommand(string.Concat(text), this.mycon)).ExecuteScalar().ToString());
            int num2 = 0;
            SqlDataReader sqlDataReader = (new SqlCommand(string.Concat("SELECT C.MERCHANT_NUM, C.MERCHANT_NAME, LEFT( (SELECT DISTINCT D.GLACCOUNT + ', ' FROM T_CSR_DETAIL D WHERE D.IS_CANCEL <> 1 AND D.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY FOR XML PATH('')), LEN((SELECT DISTINCT D.GLACCOUNT + ', ' FROM T_CSR_DETAIL D WHERE D.IS_CANCEL <> 1 AND D.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY FOR XML PATH(''))) -1) AS GL_ACCOUNT, (SELECT SUM(BUCKET_VALUE) FROM T_CSR_DETAIL WHERE T_CSR_DETAIL.IS_CANCEL <> 1 AND T_CSR_DETAIL.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY) AS AMOUNT, CAST((SELECT MAX(BUCKET_NAME) FROM T_CSR_DETAIL WHERE T_CSR_DETAIL.IS_CANCEL <> 1 AND T_CSR_DETAIL.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY) AS VARCHAR(10)) AS BUCKET, C.COLLECTOR_USER  FROM T_CSR_MONTHLY as C   WHERE C.IS_CANCEL <> 1 AND MONTH = ", this.mese, " AND YEAR = ", this.anno), this.mycon)).ExecuteReader();
            while (sqlDataReader.Read())
            {
                if (sqlDataReader["GL_ACCOUNT"].ToString().Contains(file))
                {
                    item.Cells[num, 1] = sqlDataReader["MERCHANT_NAME"].ToString();
                    item.Cells[num, 2] = sqlDataReader["MERCHANT_NUM"].ToString();
                    item.Cells[num, 3] = "MSI SCR";
                    item.Cells[num, 4] = sqlDataReader["GL_ACCOUNT"].ToString();
                    item.Cells[num, 5] = double.Parse(sqlDataReader["AMOUNT"].ToString());
                    item.Cells[num, 6] = string.Concat("'", generalData.cercaBucket(sqlDataReader["BUCKET"].ToString()));
                    if (file == "51101")
                    {
                        item.Cells[num, 8] = "OPS";
                    }
                    num++;
                    num2++;
                    this.mywork.ReportProgress(num2 * 100 / num1);
                }
            }
            this.mycon.Close();
            if (!(file == "53202" ? false : !(file == "54008")))
            {
                generalData.setHeader(ref item, "Bad Debt write-off to be authorized");
            }
            else if (!(file == "54002"))
            {
                generalData.setHeader(ref item, "Fee wo 51101");
            }
            else
            {
                generalData.setHeader(ref item, "Fraud wo 54002");
            }
            generalData.setColumnName(ref item, (file == "51101" ? true : false));
            generalData.setTotal(ref item, num);
            generalData.setFooter(ref item, num);
            variable1.SaveAs(this.newFilePath, Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
            variable1.Close(true, this.misValue, this.misValue);
            variable.Quit();
            this.releaseObject(item);
            this.releaseObject(variable1);
            this.releaseObject(variable);
        }

        private void creaXLS_unpacked(string file)
        {
            Excel.Application variable = new Excel.Application();
            variable.DisplayAlerts = false;
            string[] text = new string[] { this.txtpercorso.Text, "\\", file, "_", null, null };
            text[4] = DateTime.Now.ToString("ddMMyyyy");
            text[5] = ".xls";
            this.newFilePath = string.Concat(text);
            Excel.Workbook variable1 = variable.Workbooks.Add(Missing.Value);
            Excel.Worksheet item = (Excel.Worksheet)((dynamic)variable1.Worksheets[1]);
            item.PageSetup.Orientation = Excel.XlPageOrientation.xlLandscape;
            item.PageSetup.PaperSize = Excel.XlPaperSize.xlPaperA4;
            item.PageSetup.Zoom = false;
            item.PageSetup.FitToPagesWide = 1;
            item.PageSetup.FitToPagesTall = 1;
            this.mycon.Open();
            int num = 6;
            text = new string[] { "SELECT COUNT(D.BUCKET_NAME) FROM T_CSR_DETAIL D INNER JOIN T_CSR_MONTHLY M ON M.ID_CSR_MONTHLY = D.ID_CSR_MONTHLY WHERE D.IS_CANCEL <> 1 AND D.GLACCOUNT = '", file, "' AND M.YEAR = ", this.anno, " AND M.MONTH = ", this.mese };
            int num1 = int.Parse((new SqlCommand(string.Concat(text), this.mycon)).ExecuteScalar().ToString());
            int num2 = 0;
            text = new string[] { "SELECT D.BUCKET_NAME, D.BUCKET_VALUE, D.GLACCOUNT, M.MERCHANT_NUM, M.MERCHANT_NAME FROM T_CSR_DETAIL D INNER JOIN T_CSR_MONTHLY M ON M.ID_CSR_MONTHLY = D.ID_CSR_MONTHLY WHERE D.IS_CANCEL <> 1 AND D.GLACCOUNT = '", file, "' AND M.YEAR = ", this.anno, " AND M.MONTH = ", this.mese };
            SqlDataReader sqlDataReader = (new SqlCommand(string.Concat(text), this.mycon)).ExecuteReader();
            while (sqlDataReader.Read())
            {
                item.Cells[num, 1] = sqlDataReader["MERCHANT_NAME"].ToString();
                item.Cells[num, 2] = sqlDataReader["MERCHANT_NUM"].ToString();
                item.Cells[num, 3] = "MSI SCR";
                item.Cells[num, 4] = sqlDataReader["GLACCOUNT"].ToString();
                item.Cells[num, 5] = double.Parse(sqlDataReader["BUCKET_VALUE"].ToString());
                item.Cells[num, 6] = string.Concat("'", generalData.cercaBucket(sqlDataReader["BUCKET_NAME"].ToString()));
                if (file == "51101")
                {
                    item.Cells[num, 8] = "OPS";
                }
                num++;
                num2++;
                this.mywork.ReportProgress(num2 * 100 / num1);
            }
            this.mycon.Close();
            if (!(file == "53202" ? false : !(file == "54008")))
            {
                generalData.setHeader(ref item, "Bad Debt write-off to be authorized");
            }
            else if (!(file == "54002"))
            {
                generalData.setHeader(ref item, "Fee wo 51101");
            }
            else
            {
                generalData.setHeader(ref item, "Fraud wo 54002");
            }
            generalData.setColumnName(ref item, (file == "51101" ? true : false));
            generalData.setTotal(ref item, num);
            generalData.setFooter(ref item, num);
            variable1.SaveAs(this.newFilePath, Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
            variable1.Close(true, this.misValue, this.misValue);
            variable.Quit();
            this.releaseObject(item);
            this.releaseObject(variable1);
            this.releaseObject(variable);
        }


        private void mywork_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                if (e.Argument.ToString() != "All")
                {
                    if (!(this.type == "PACKED"))
                    {
                        this.creaXLS_unpacked(this.typeofWriteoff);
                    }
                    else
                    {
                        this.creaXLS_packed(this.typeofWriteoff);
                    }
                }
                else if (!(this.type == "PACKED"))
                {
                    this.creaXLS_unpacked("54002");
                    this.creaXLS_unpacked("54008");
                    this.creaXLS_unpacked("51101");
                    this.creaXLS_unpacked("53202");
                }
                else
                {
                    this.creaXLS_packed("54002");
                    this.creaXLS_packed("54008");
                    this.creaXLS_packed("51101");
                    this.creaXLS_packed("53202");
                }
            }
            catch (Exception exception1)
            {
                Exception exception = exception1;
                MyMessage.showMessage(string.Concat("Error:\n", exception.Message), MessageBoxIcon.Hand);
                MyLogger.WriteLog(string.Concat(this.Text, ": ", exception.Message));
                if (this.mycon.State == ConnectionState.Open)
                {
                    this.mycon.Close();
                }
                e.Cancel = true;
                return;
            }
        }

        private void mywork_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.mybar.Value = e.ProgressPercentage;
        }

        private void mywork_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            if (this.mybar.Value != 100)
            {
                MyMessage.showMessage("Export has been stopped", MessageBoxIcon.Hand);
            }
            else
            {
                MyMessage.showMessage(string.Concat(this.newFilePath, " EXPORTED"), MessageBoxIcon.Asterisk);
            }
        }

        private void releaseObject(object obj)
        {
            try
            {
                try
                {
                    Marshal.ReleaseComObject(obj);
                    obj = null;
                }
                catch (Exception exception1)
                {
                    Exception exception = exception1;
                    obj = null;
                    MessageBox.Show(string.Concat("Exception Occured while releasing object ", exception.ToString()));
                }
            }
            finally
            {
                GC.Collect();
            }
        }

    }
}
