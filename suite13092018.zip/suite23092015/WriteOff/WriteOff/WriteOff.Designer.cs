﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace WriteOff
{
    partial class WriteOff
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private Button btnpercorso;
        private TextBox txtpercorso;
        private BackgroundWorker mywork;
        private Button btnSave;
        private Button btnCancel;
        private BackgroundWorker backgroundWorker1;
        private BackgroundWorker backgroundWorker2;
        private BackgroundWorker backgroundWorker3;
        private BackgroundWorker backgroundWorker4;
        private DateTimePicker comboyear;
        private ComboBox combomonth;
        private Label label1;
        private Label lblyear;
        private StatusStrip statusStrip1;
        private ToolStripProgressBar mybar;
        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnpercorso = new System.Windows.Forms.Button();
            this.txtpercorso = new System.Windows.Forms.TextBox();
            this.mywork = new System.ComponentModel.BackgroundWorker();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker3 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker4 = new System.ComponentModel.BackgroundWorker();
            this.comboyear = new System.Windows.Forms.DateTimePicker();
            this.combomonth = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblyear = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.mybar = new System.Windows.Forms.ToolStripProgressBar();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnpercorso
            // 
            this.btnpercorso.AutoSize = true;
            this.btnpercorso.Location = new System.Drawing.Point(18, 19);
            this.btnpercorso.Margin = new System.Windows.Forms.Padding(4);
            this.btnpercorso.Name = "btnpercorso";
            this.btnpercorso.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnpercorso.Size = new System.Drawing.Size(69, 25);
            this.btnpercorso.TabIndex = 1;
            this.btnpercorso.Text = "Browse..";
            this.btnpercorso.UseVisualStyleBackColor = true;
            this.btnpercorso.Click += new System.EventHandler(this.btnpercorso_Click);
            // 
            // txtpercorso
            // 
            this.txtpercorso.Location = new System.Drawing.Point(93, 21);
            this.txtpercorso.Name = "txtpercorso";
            this.txtpercorso.ReadOnly = true;
            this.txtpercorso.Size = new System.Drawing.Size(263, 23);
            this.txtpercorso.TabIndex = 10;
            this.txtpercorso.Tag = "File Excel";
            // 
            // mywork
            // 
            this.mywork.WorkerReportsProgress = true;
            this.mywork.DoWork += new System.ComponentModel.DoWorkEventHandler(this.mywork_DoWork);
            this.mywork.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.mywork_ProgressChanged);
            this.mywork.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.mywork_RunWorkerCompleted);
            // 
            // btnSave
            // 
            this.btnSave.AutoSize = true;
            this.btnSave.Location = new System.Drawing.Point(93, 125);
            this.btnSave.Name = "btnSave";
            this.btnSave.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnSave.Size = new System.Drawing.Size(48, 25);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.AutoSize = true;
            this.btnCancel.Location = new System.Drawing.Point(164, 125);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnCancel.Size = new System.Drawing.Size(60, 25);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.WorkerReportsProgress = true;
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.mywork_DoWork);
            this.backgroundWorker1.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.mywork_ProgressChanged);
            this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.mywork_RunWorkerCompleted);
            // 
            // backgroundWorker2
            // 
            this.backgroundWorker2.WorkerReportsProgress = true;
            this.backgroundWorker2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.mywork_DoWork);
            this.backgroundWorker2.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.mywork_ProgressChanged);
            this.backgroundWorker2.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.mywork_RunWorkerCompleted);
            // 
            // backgroundWorker3
            // 
            this.backgroundWorker3.WorkerReportsProgress = true;
            this.backgroundWorker3.DoWork += new System.ComponentModel.DoWorkEventHandler(this.mywork_DoWork);
            this.backgroundWorker3.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.mywork_ProgressChanged);
            this.backgroundWorker3.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.mywork_RunWorkerCompleted);
            // 
            // backgroundWorker4
            // 
            this.backgroundWorker4.WorkerReportsProgress = true;
            this.backgroundWorker4.DoWork += new System.ComponentModel.DoWorkEventHandler(this.mywork_DoWork);
            this.backgroundWorker4.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.mywork_ProgressChanged);
            this.backgroundWorker4.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.mywork_RunWorkerCompleted);
            // 
            // comboyear
            // 
            this.comboyear.CustomFormat = "yyyy";
            this.comboyear.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.comboyear.Location = new System.Drawing.Point(93, 87);
            this.comboyear.Name = "comboyear";
            this.comboyear.ShowUpDown = true;
            this.comboyear.Size = new System.Drawing.Size(110, 23);
            this.comboyear.TabIndex = 3;
            // 
            // combomonth
            // 
            this.combomonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combomonth.FormattingEnabled = true;
            this.combomonth.Items.AddRange(new object[] {
            "January ",
            "February ",
            "March ",
            "April ",
            "May ",
            "June ",
            "July ",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.combomonth.Location = new System.Drawing.Point(93, 54);
            this.combomonth.Name = "combomonth";
            this.combomonth.Size = new System.Drawing.Size(109, 23);
            this.combomonth.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 28;
            this.label1.Text = "Month";
            // 
            // lblyear
            // 
            this.lblyear.AutoSize = true;
            this.lblyear.Location = new System.Drawing.Point(57, 88);
            this.lblyear.Name = "lblyear";
            this.lblyear.Size = new System.Drawing.Size(30, 15);
            this.lblyear.TabIndex = 27;
            this.lblyear.Text = "Year";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mybar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 172);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(374, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 31;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // mybar
            // 
            this.mybar.Name = "mybar";
            this.mybar.Size = new System.Drawing.Size(370, 16);
            // 
            // WriteOff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 194);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.comboyear);
            this.Controls.Add(this.combomonth);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblyear);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtpercorso);
            this.Controls.Add(this.btnpercorso);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "WriteOff";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Writeoff - Export";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}

