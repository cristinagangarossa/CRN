﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Collections;

namespace WriteOff
{
    public partial class viewdata : Form
    {
        private SqlConnection mycon = generalData.get_con();
        private DataTable dt;
        private DataTable dt_detail;
        private RowSelezionata rowselected = new RowSelezionata();

        public viewdata()
        {
            InitializeComponent();
            this.comboMonth.SelectedIndex = 0;
            this.dt = new DataTable();
            this.dataview.DataSource = this.dt;
        }

        private void riempiDT_packed()
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                this.dt.Clear();
                SqlDataAdapter sqlDataAdapter;
                if (string.IsNullOrWhiteSpace(this.txtsearch.Text))
                {
                    sqlDataAdapter = new SqlDataAdapter(string.Concat(new object[]
					{
						"SELECT C.ID_CSR_MONTHLY, C.MERCHANT_NUM AS MERCHANT_ID, C.MERCHANT_NAME,  \r\n                                                LEFT( (SELECT DISTINCT D.GLACCOUNT + ', ' FROM T_CSR_DETAIL D WHERE D.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY FOR XML PATH('')), LEN((SELECT DISTINCT D.GLACCOUNT + ', ' FROM T_CSR_DETAIL D WHERE D.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY FOR XML PATH(''))) -1) AS GL_ACCOUNT,\r\n                                                (SELECT SUM(BUCKET_VALUE) FROM T_CSR_DETAIL WHERE T_CSR_DETAIL.IS_CANCEL = 0 AND T_CSR_DETAIL.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY) AS AMOUNT,\r\n                                                CAST((SELECT MAX(BUCKET_NAME) FROM T_CSR_DETAIL WHERE T_CSR_DETAIL.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY) AS VARCHAR(10)) AS BUCKET, C.COLLECTOR_USER, C.IS_CANCEL  FROM T_CSR_MONTHLY as C WHERE MONTH = ",
						generalData.valueMonth(this.comboMonth.Text.Trim()),
						" AND YEAR = ",
						this.comboYear.Text.Remove(0, 2),
						" ORDER BY C.MERCHANT_NUM"
					}), this.mycon);
                }
                else
                {
                    sqlDataAdapter = new SqlDataAdapter(string.Concat(new object[]
					{
						"SELECT C.ID_CSR_MONTHLY, C.MERCHANT_NUM AS MERCHANT_ID, C.MERCHANT_NAME,\r\n                                                LEFT( (SELECT DISTINCT D.GLACCOUNT + ', ' FROM T_CSR_DETAIL D WHERE D.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY FOR XML PATH('')), LEN((SELECT DISTINCT D.GLACCOUNT + ', ' FROM T_CSR_DETAIL D WHERE D.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY FOR XML PATH(''))) -1) AS GL_ACCOUNT,\r\n                                                (SELECT SUM(BUCKET_VALUE) FROM T_CSR_DETAIL WHERE T_CSR_DETAIL.IS_CANCEL = 0 AND T_CSR_DETAIL.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY) AS AMOUNT,\r\n                                                CAST((SELECT MAX(BUCKET_NAME) FROM T_CSR_DETAIL WHERE T_CSR_DETAIL.ID_CSR_MONTHLY = C.ID_CSR_MONTHLY) AS VARCHAR(10)) AS BUCKET, C.COLLECTOR_USER, C.IS_CANCEL  FROM T_CSR_MONTHLY as C WHERE MONTH = ",
						generalData.valueMonth(this.comboMonth.Text.Trim()),
						" AND YEAR = ",
						this.comboYear.Text.Remove(0, 2),
						" AND C.MERCHANT_NUM LIKE '",
						this.txtsearch.Text,
						"%' ORDER BY MERCHANT_ID"
					}), this.mycon);
                }
                sqlDataAdapter.Fill(this.dt);
                this.dataview.Columns["ID_CSR_MONTHLY"].Visible = false;
                this.dataview.Columns["COLLECTOR_USER"].Visible = false;
                this.dataview.Columns["IS_CANCEL"].Visible = false;
                this.dataview.Columns["AMOUNT"].DefaultCellStyle.Format = "C2";
                this.dataview.Columns["MERCHANT_NAME"].Width = 300;
                this.recolor_row();
                Cursor.Current = Cursors.Arrow;
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog(this.Text + ": " + ex.Message);
            }
        }
        private void recolor_row()
        {
            int num = 0;
            int num2 = 0;
            int num3 = 0;
            int num4 = 0;
            foreach (DataGridViewRow dataGridViewRow in (IEnumerable)this.dataview.Rows)
            {
                dataGridViewRow.Cells["BUCKET"].Value = generalData.cercaBucket(dataGridViewRow.Cells["BUCKET"].Value.ToString());
                if (dataGridViewRow.Cells["GL_ACCOUNT"].Value.ToString() == "54002")
                {
                    dataGridViewRow.DefaultCellStyle.BackColor = Color.LightCoral;
                    if (!bool.Parse(dataGridViewRow.Cells["IS_CANCEL"].Value.ToString()))
                    {
                        num2++;
                    }
                }
                else
                {
                    if (dataGridViewRow.Cells["GL_ACCOUNT"].Value.ToString() == "54008")
                    {
                        dataGridViewRow.DefaultCellStyle.BackColor = Color.LightCyan;
                        if (!bool.Parse(dataGridViewRow.Cells["IS_CANCEL"].Value.ToString()))
                        {
                            num3++;
                        }
                    }
                    else
                    {
                        if (dataGridViewRow.Cells["GL_ACCOUNT"].Value.ToString().Contains("51101"))
                        {
                            dataGridViewRow.DefaultCellStyle.BackColor = Color.LightBlue;
                            if (!bool.Parse(dataGridViewRow.Cells["IS_CANCEL"].Value.ToString()))
                            {
                                num++;
                            }
                        }
                        else
                        {
                            dataGridViewRow.DefaultCellStyle.BackColor = Color.White;
                            if (!bool.Parse(dataGridViewRow.Cells["IS_CANCEL"].Value.ToString()))
                            {
                                num4++;
                            }
                        }
                    }
                }
                if (bool.Parse(dataGridViewRow.Cells["IS_CANCEL"].Value.ToString()))
                {
                    dataGridViewRow.DefaultCellStyle.Font = new Font(this.Font, FontStyle.Strikeout);
                    dataGridViewRow.ContextMenuStrip = this.menuRowMerchant_2;
                }
                else
                {
                    dataGridViewRow.ContextMenuStrip = this.menuRowMerchant;
                }
            }
            this.lblerror.Text = "ERROR (" + num + ")";
            this.lblfreud.Text = "FRAUD (" + num2 + ")";
            this.lblmountlow.Text = "AMOUNT < 10 (" + num3 + ")";
            this.lblNormal.Text = "AMOUNT > 10 (" + num4 + ")";
            if (this.rowselected.mid_visualizzato > 0)
            {
                this.dataview.CurrentRow.Selected = false;
                this.dataview.FirstDisplayedScrollingRowIndex = this.rowselected.row_scroll;
                this.dataview.Rows[this.rowselected.mid_visualizzato].Selected = true;
            }
            if (this.dataview.Rows.Count == 0 && this.dt_detail != null)
            {
                this.dt_detail.Clear();
            }
        }
        private void riempi_DETAIL()
        {
            SqlConnection con = generalData.get_con();
            try
            {
                int index = this.dataview.SelectedRows[0].Index;
                if (this.dataview.Rows.Count >= 1)
                {
                    if (this.dt_detail == null)
                    {
                        this.dt_detail = generalData.get_DataTable_detail();
                        this.datadetail.DataSource = this.dt_detail;
                        this.datadetail.Columns["ID_DETAIL"].Visible = false;
                        this.datadetail.Columns["ID_MID"].Visible = false;
                        this.datadetail.Columns["IS_CANCEL"].Visible = false;
                        this.datadetail.Columns["COLLECTOR_USER"].Visible = false;
                        this.datadetail.Columns["AMOUNT"].DefaultCellStyle.Format = "C2";
                    }
                    Cursor.Current = Cursors.WaitCursor;
                    this.dt_detail.Clear();
                    con.Open();
                    SqlDataReader sqlDataReader = new SqlCommand("SELECT * FROM T_CSR_DETAIL  WHERE ID_CSR_MONTHLY = " + this.dataview.Rows[index].Cells["ID_CSR_MONTHLY"].Value.ToString(), con).ExecuteReader();
                    while (sqlDataReader.Read())
                    {
                        DataRow dataRow = this.dt_detail.NewRow();
                        dataRow["ID_DETAIL"] = sqlDataReader["ID_CSR_DETAIL"].ToString();
                        dataRow["ID_MID"] = sqlDataReader["ID_CSR_MONTHLY"].ToString();
                        dataRow["MERCHANT_ID"] = this.dataview.Rows[index].Cells["MERCHANT_ID"].Value.ToString();
                        dataRow["MERCHANT_NAME"] = this.dataview.Rows[index].Cells["MERCHANT_NAME"].Value.ToString();
                        dataRow["GL_ACCOUNT"] = sqlDataReader["GLACCOUNT"].ToString().Trim();
                        dataRow["AMOUNT"] = sqlDataReader["BUCKET_VALUE"].ToString();
                        dataRow["COLLECTOR_USER"] = this.dataview.Rows[index].Cells["COLLECTOR_USER"].Value.ToString();
                        dataRow["BUCKET"] = generalData.cercaBucket(sqlDataReader["BUCKET_NAME"].ToString());
                        dataRow["IS_ERROR"] = (dataRow["GL_ACCOUNT"].ToString() == "51101");
                        dataRow["IS_CANCEL"] = sqlDataReader["IS_CANCEL"].ToString();
                        this.dt_detail.Rows.Add(dataRow);
                    }
                    con.Close();
                    foreach (DataGridViewRow dataGridViewRow in (IEnumerable)this.datadetail.Rows)
                    {
                        if (bool.Parse(dataGridViewRow.Cells["IS_CANCEL"].Value.ToString()))
                        {
                            dataGridViewRow.DefaultCellStyle.Font = new Font(this.Font, FontStyle.Strikeout);
                            dataGridViewRow.ContextMenuStrip = this.menuRowAccount_2;
                        }
                        else
                        {
                            dataGridViewRow.ContextMenuStrip = this.menuRowAccount;
                        }
                    }
                    Cursor.Current = Cursors.Default;
                }
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog(this.Text + ": " + ex.Message);
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        private void dataview_Sorted(object sender, EventArgs e)
        {
            this.recolor_row();
        }
        private void btnsearchmid_Click_1(object sender, EventArgs e)
        {
            if (this.dt_detail != null)
            {
                this.dt_detail.Rows.Clear();
            }
            this.riempiDT_packed();
            this.recolor_row();
        }
        private void btnCancelResearch_Click(object sender, EventArgs e)
        {
            if (this.dt_detail != null)
            {
                this.dt_detail.Rows.Clear();
            }
            this.txtsearch.Text = string.Empty;
            this.riempiDT_packed();
            this.recolor_row();
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                this.toolStrip1.Enabled = true;
                this.riempiDT_packed();
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog(this.Text + ": " + ex.Message);
                Cursor.Current = Cursors.Default;
                if (this.mycon.State == ConnectionState.Open)
                {
                    this.mycon.Close();
                }
            }
        }
        private void restoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.restore_credit();
        }
        private void restoreToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.restore_detail_credit();
        }
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow dataGridViewRow in this.datadetail.SelectedRows)
                {
                    DataGridViewCell dataGridViewCell = dataGridViewRow.Cells["IS_ERROR"];
                    string str;
                    if (!bool.Parse(dataGridViewCell.Value.ToString()))
                    {
                        str = "51101";
                    }
                    else
                    {
                        if (dataGridViewRow.Cells["COLLECTOR_USER"].Value.ToString().ToLower().Trim() == "fraud")
                        {
                            str = "54002";
                        }
                        else
                        {
                            if (Convert.ToDouble(dataGridViewRow.Cells["AMOUNT"].Value) < 10.0)
                            {
                                str = "54008";
                            }
                            else
                            {
                                str = "53202";
                            }
                        }
                    }
                    this.mycon.Open();
                    new SqlCommand("UPDATE T_CSR_DETAIL SET GLACCOUNT = '" + str + "' WHERE ID_CSR_DETAIL = " + dataGridViewRow.Cells["ID_DETAIL"].Value.ToString(), this.mycon).ExecuteNonQuery();
                    this.mycon.Close();
                    this.rowselected.mid_visualizzato = this.dataview.SelectedRows[0].Index;
                }
                this.riempiDT_packed();
                this.rowselected = new RowSelezionata();
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog(this.Text + ": " + ex.Message);
                if (this.mycon.State == ConnectionState.Open)
                {
                    this.mycon.Close();
                }
            }
        }
        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            this.cancel_detail_credit();
        }
        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (this.datadetail.SelectedRows.Count == 1)
            {
                changeAmount changeAmount = new changeAmount(this.datadetail.SelectedRows[0], "DETAIL");
                changeAmount.ShowDialog();
                if (changeAmount.hasSave)
                {
                    this.rowselected.mid_visualizzato = this.dataview.SelectedRows[0].Index;
                    this.dt_detail.Rows.Clear();
                    this.riempiDT_packed();
                    this.rowselected = new RowSelezionata();
                }
            }
            else
            {
                MyMessage.showMessage("Too many merchant selected", MessageBoxIcon.Hand);
            }
        }
        private void excludeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.cancel_credit();
        }
        private void changeAmountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.datadetail.SelectedRows.Count == 1)
            {
                changeAmountGlobal changeAmountGlobal = new changeAmountGlobal(this.dataview.SelectedRows[0]);
                changeAmountGlobal.ShowDialog();
                if (changeAmountGlobal.hasSave)
                {
                    this.rowselected.mid_visualizzato = this.dataview.SelectedRows[0].Index;
                    this.dt_detail.Rows.Clear();
                    this.riempiDT_packed();
                    this.rowselected = new RowSelezionata();
                }
            }
            else
            {
                MyMessage.showMessage("Too many merchant selected", MessageBoxIcon.Hand);
            }
        }
        private void dataview_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.dataview.ClearSelection();
                this.dataview[e.ColumnIndex, e.RowIndex].Selected = true;
            }
        }
        private void dataview_SelectionChanged(object sender, EventArgs e)
        {
            if (this.dataview.SelectedRows.Count > 0)
            {
                this.riempi_DETAIL();
            }
        }
        private void cancel_credit()
        {
            if (MyMessage.askMessage("Are you sure to exclude selected credit?"))
            {
                try
                {
                    MyLogger.WriteLog(string.Concat(new object[]
					{
						this.Text,
						": exclude ",
						this.dataview.SelectedRows.Count,
						" row"
					}));
                    this.mycon.Open();
                    SqlCommand sqlCommand = new SqlCommand("UPDATE T_CSR_MONTHLY SET IS_CANCEL = 1 WHERE ID_CSR_MONTHLY = @idcsrmonthly", this.mycon);
                    sqlCommand.Parameters.Add("@idcsrmonthly", SqlDbType.Int);
                    SqlCommand sqlCommand2 = new SqlCommand("UPDATE T_CSR_DETAIL SET IS_CANCEL = 1 WHERE ID_CSR_MONTHLY = @idcsrmonthly", this.mycon);
                    sqlCommand2.Parameters.Add("@idcsrmonthly", SqlDbType.Int);
                    foreach (DataGridViewRow dataGridViewRow in this.dataview.SelectedRows)
                    {
                        sqlCommand.Parameters["@idcsrmonthly"].Value = dataGridViewRow.Cells["ID_CSR_MONTHLY"].Value.ToString();
                        sqlCommand2.Parameters["@idcsrmonthly"].Value = dataGridViewRow.Cells["ID_CSR_MONTHLY"].Value.ToString();
                        sqlCommand.ExecuteNonQuery();
                        sqlCommand2.ExecuteNonQuery();
                        this.rowselected.mid_visualizzato = dataGridViewRow.Index;
                    }
                    this.rowselected.row_scroll = this.dataview.FirstDisplayedScrollingRowIndex;
                    this.mycon.Close();
                    this.dt_detail.Rows.Clear();
                    this.riempiDT_packed();
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                    MyLogger.WriteLog(this.Text + ": " + ex.Message);
                    if (this.mycon.State == ConnectionState.Open)
                    {
                        this.mycon.Close();
                    }
                }
            }
        }
        private void cancel_detail_credit()
        {
            if (MyMessage.askMessage("Are you sure to exclude selected detail?"))
            {
                try
                {
                    MyLogger.WriteLog(string.Concat(new object[]
					{
						this.Text,
						": exclude ",
						this.dataview.SelectedRows.Count,
						" detail"
					}));
                    this.mycon.Open();
                    SqlCommand sqlCommand = new SqlCommand("UPDATE T_CSR_DETAIL SET IS_CANCEL = 1 WHERE ID_CSR_DETAIL = @idcsrdetail", this.mycon);
                    sqlCommand.Parameters.Add("@idcsrdetail", SqlDbType.Int);
                    foreach (DataGridViewRow dataGridViewRow in this.datadetail.SelectedRows)
                    {
                        sqlCommand.Parameters["@idcsrdetail"].Value = dataGridViewRow.Cells["ID_DETAIL"].Value.ToString();
                        sqlCommand.ExecuteNonQuery();
                        dataGridViewRow.Cells["IS_CANCEL"].Value = 1;
                    }
                    int num = 0;
                    foreach (DataGridViewRow dataGridViewRow in (IEnumerable)this.datadetail.Rows)
                    {
                        if (dataGridViewRow.Cells["IS_CANCEL"].Value.ToString() == "True")
                        {
                            num++;
                        }
                    }
                    if (num == this.datadetail.RowCount)
                    {
                        new SqlCommand("UPDATE T_CSR_MONTHLY SET IS_CANCEL = 1 WHERE ID_CSR_MONTHLY = " + this.dataview.SelectedRows[0].Cells["ID_CSR_MONTHLY"].Value.ToString(), this.mycon).ExecuteNonQuery();
                        this.mycon.Close();
                        this.rowselected.mid_visualizzato = this.dataview.SelectedRows[0].Index;
                        this.rowselected.row_scroll = this.dataview.FirstDisplayedScrollingRowIndex;
                        this.riempiDT_packed();
                    }
                    else
                    {
                        this.mycon.Close();
                        this.rowselected.mid_visualizzato = this.dataview.SelectedRows[0].Index;
                        this.rowselected.row_scroll = this.dataview.FirstDisplayedScrollingRowIndex;
                        this.riempiDT_packed();
                    }
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                    MyLogger.WriteLog(this.Text + ": " + ex.Message);
                    if (this.mycon.State == ConnectionState.Open)
                    {
                        this.mycon.Close();
                    }
                }
            }
        }
        private void delete_detail_credit()
        {
            if (MyMessage.askMessage("Are you sure to delete selected detail?"))
            {
                try
                {
                    MyLogger.WriteLog(string.Concat(new object[]
					{
						this.Text,
						": delete ",
						this.dataview.SelectedRows.Count,
						" row"
					}));
                    this.mycon.Open();
                    SqlCommand sqlCommand = new SqlCommand("DELETE T_CSR_DETAIL WHERE ID_CSR_DETAIL = @idcsrdetail", this.mycon);
                    sqlCommand.Parameters.Add("@idcsrdetail", SqlDbType.Int);
                    foreach (DataGridViewRow dataGridViewRow in this.datadetail.SelectedRows)
                    {
                        sqlCommand.Parameters["@idcsrdetail"].Value = dataGridViewRow.Cells["ID_DETAIL"].Value.ToString();
                        sqlCommand.ExecuteNonQuery();
                        this.datadetail.Rows.Remove(dataGridViewRow);
                    }
                    if (this.datadetail.Rows.Count == 0)
                    {
                        new SqlCommand("DELETE T_CSR_MONTHLY WHERE ID_CSR_MONTHLY = " + this.dataview.SelectedRows[0].Cells["ID_CSR_MONTHLY"].Value.ToString(), this.mycon).ExecuteNonQuery();
                        this.mycon.Close();
                        this.rowselected.mid_visualizzato = this.dataview.SelectedRows[0].Index;
                        this.rowselected.row_scroll = this.dataview.FirstDisplayedScrollingRowIndex;
                        this.riempiDT_packed();
                    }
                    else
                    {
                        this.mycon.Close();
                        this.riempiDT_packed();
                    }
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                    MyLogger.WriteLog(this.Text + ": " + ex.Message);
                    if (this.mycon.State == ConnectionState.Open)
                    {
                        this.mycon.Close();
                    }
                }
            }
        }
        private void delete_credit()
        {
            if (MyMessage.askMessage("Are you sure to delete selected credit?"))
            {
                try
                {
                    MyLogger.WriteLog(string.Concat(new object[]
					{
						this.Text,
						": delete ",
						this.dataview.SelectedRows.Count,
						" row"
					}));
                    this.mycon.Open();
                    SqlCommand sqlCommand = new SqlCommand("DELETE FROM T_CSR_MONTHLY WHERE ID_CSR_MONTHLY = @idcsrmonthly", this.mycon);
                    sqlCommand.Parameters.Add("@idcsrmonthly", SqlDbType.Int);
                    SqlCommand sqlCommand2 = new SqlCommand("DELETE FROM T_CSR_MONTHLY WHERE ID_CSR_MONTHLY = @idcsrmonthly", this.mycon);
                    sqlCommand2.Parameters.Add("@idcsrmonthly", SqlDbType.Int);
                    foreach (DataGridViewRow dataGridViewRow in this.dataview.SelectedRows)
                    {
                        sqlCommand.Parameters["@idcsrmonthly"].Value = dataGridViewRow.Cells["ID_CSR_MONTHLY"].Value.ToString();
                        sqlCommand2.Parameters["@idcsrmonthly"].Value = dataGridViewRow.Cells["ID_CSR_MONTHLY"].Value.ToString();
                        sqlCommand.ExecuteNonQuery();
                        sqlCommand2.ExecuteNonQuery();
                        this.rowselected.mid_visualizzato = dataGridViewRow.Index;
                    }
                    this.rowselected.row_scroll = this.dataview.FirstDisplayedScrollingRowIndex;
                    this.mycon.Close();
                    this.dt_detail.Rows.Clear();
                    this.riempiDT_packed();
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                    MyLogger.WriteLog(this.Text + ": " + ex.Message);
                    if (this.mycon.State == ConnectionState.Open)
                    {
                        this.mycon.Close();
                    }
                }
            }
        }
        private void restore_detail_credit()
        {
            if (MyMessage.askMessage("Are you sure to restore selected detail?"))
            {
                try
                {
                    MyLogger.WriteLog(string.Concat(new object[]
					{
						this.Text,
						": restore ",
						this.dataview.SelectedRows.Count,
						" detail"
					}));
                    this.mycon.Open();
                    SqlCommand sqlCommand = new SqlCommand("UPDATE T_CSR_DETAIL SET IS_CANCEL = 0 WHERE ID_CSR_DETAIL = @idcsrdetail", this.mycon);
                    sqlCommand.Parameters.Add("@idcsrdetail", SqlDbType.Int);
                    foreach (DataGridViewRow dataGridViewRow in this.datadetail.SelectedRows)
                    {
                        sqlCommand.Parameters["@idcsrdetail"].Value = dataGridViewRow.Cells["ID_DETAIL"].Value.ToString();
                        sqlCommand.ExecuteNonQuery();
                        dataGridViewRow.Cells["IS_CANCEL"].Value = 0;
                    }
                    int num = 0;
                    foreach (DataGridViewRow dataGridViewRow in (IEnumerable)this.datadetail.Rows)
                    {
                        if (dataGridViewRow.Cells["IS_CANCEL"].Value.ToString() == "False")
                        {
                            num++;
                        }
                    }
                    if (num > 0)
                    {
                        new SqlCommand("UPDATE T_CSR_MONTHLY SET IS_CANCEL = 0 WHERE ID_CSR_MONTHLY = " + this.dataview.SelectedRows[0].Cells["ID_CSR_MONTHLY"].Value.ToString(), this.mycon).ExecuteNonQuery();
                        this.mycon.Close();
                        this.rowselected.mid_visualizzato = this.dataview.SelectedRows[0].Index;
                        this.rowselected.row_scroll = this.dataview.FirstDisplayedScrollingRowIndex;
                        this.riempiDT_packed();
                    }
                    else
                    {
                        this.mycon.Close();
                        this.riempi_DETAIL();
                    }
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                    MyLogger.WriteLog(this.Text + ": " + ex.Message);
                    if (this.mycon.State == ConnectionState.Open)
                    {
                        this.mycon.Close();
                    }
                }
            }
        }
        private void restore_credit()
        {
            if (MyMessage.askMessage("Are you sure to restore selected credit?"))
            {
                try
                {
                    MyLogger.WriteLog(string.Concat(new object[]
					{
						this.Text,
						": restore ",
						this.dataview.SelectedRows.Count,
						" row"
					}));
                    this.mycon.Open();
                    SqlCommand sqlCommand = new SqlCommand("UPDATE T_CSR_MONTHLY SET IS_CANCEL = 0 WHERE ID_CSR_MONTHLY = @idcsrmonthly", this.mycon);
                    sqlCommand.Parameters.Add("@idcsrmonthly", SqlDbType.Int);
                    SqlCommand sqlCommand2 = new SqlCommand("UPDATE T_CSR_DETAIL SET IS_CANCEL = 0 WHERE ID_CSR_MONTHLY = @idcsrmonthly", this.mycon);
                    sqlCommand2.Parameters.Add("@idcsrmonthly", SqlDbType.Int);
                    foreach (DataGridViewRow dataGridViewRow in this.dataview.SelectedRows)
                    {
                        sqlCommand.Parameters["@idcsrmonthly"].Value = dataGridViewRow.Cells["ID_CSR_MONTHLY"].Value.ToString();
                        sqlCommand2.Parameters["@idcsrmonthly"].Value = dataGridViewRow.Cells["ID_CSR_MONTHLY"].Value.ToString();
                        sqlCommand.ExecuteNonQuery();
                        sqlCommand2.ExecuteNonQuery();
                        this.rowselected.mid_visualizzato = dataGridViewRow.Index;
                    }
                    this.rowselected.row_scroll = this.dataview.FirstDisplayedScrollingRowIndex;
                    this.mycon.Close();
                    this.dt_detail.Rows.Clear();
                    this.riempiDT_packed();
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                    MyLogger.WriteLog(this.Text + ": " + ex.Message);
                    if (this.mycon.State == ConnectionState.Open)
                    {
                        this.mycon.Close();
                    }
                }
            }
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (this.dataview.SelectedRows.Count > 1)
            {
                this.cancel_credit();
            }
            else
            {
                this.cancel_detail_credit();
            }
        }
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (this.dataview.SelectedRows.Count > 1)
            {
                this.restore_credit();
            }
            else
            {
                this.restore_detail_credit();
            }
        }
        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.delete_detail_credit();
        }
        private void deleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.delete_credit();
        }
    }
}
