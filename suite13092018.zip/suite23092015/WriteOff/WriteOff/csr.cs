﻿using Credit_risk_lib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WriteOff
{
    public partial class csr : Form
    {
        public csr()
        {
            InitializeComponent();
            this.combomonth.SelectedIndex = 0;
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }
        private void btnbrowser_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "File Excel (*.xls, *.xlsx)|*.xls; *.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tbXslPath.Text = openFileDialog.FileName;
                MyExcel.FilledCombobox(ref this.tbSheet, this.tbXslPath.Text);
                Cursor.Current = Cursors.Arrow;
            }
        }
        private void btnimport_Click(object sender, EventArgs e)
        {
            this.myprogressbar.Value = 0;
            if (MyControl.checkControl(this))
            {
                try
                {
                    if (generalData.checkExistCSR("T_CSR_MONTHLY", generalData.valueMonth(this.combomonth.Text.Trim()).ToString(), this.comboyear.Text))
                    {
                        base.Enabled = false;
                        MyLogger.WriteLog(string.Concat(new string[] { this.Text, ": ", generalData.valueMonth(this.combomonth.Text.Trim()).ToString(), "/", this.comboyear.Text }));
                        this.myworker.RunWorkerAsync(new object[]
						{
							this.tbXslPath.Text,
							this.tbSheet.Text,
							generalData.valueMonth(this.combomonth.Text.Trim()),
							this.comboyear.Text.Remove(0, 2)
						});
                    }
                    else
                    {
                        if (MyMessage.askMessage("CSR exists. It will be overwritten.\nCONTINUE?"))
                        {
                            base.Enabled = false;
                            MyLogger.WriteLog(string.Concat(new string[] { this.Text," ", generalData.valueMonth(this.combomonth.Text.Trim()).ToString(), "/", this.comboyear.Text, ": overwriting the existing one" }));
                            generalData.OverwrittenCSR(generalData.valueMonth(this.combomonth.Text.Trim()).ToString(), this.comboyear.Text);
                            this.myworker.RunWorkerAsync(new object[]
							{
								this.tbXslPath.Text,
								this.tbSheet.Text,
								generalData.valueMonth(this.combomonth.Text.Trim()),
								this.comboyear.Text.Remove(0, 2)
							});
                        }
                    }
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                    MyLogger.WriteLog(string.Concat(new string[]
					{
						this.Text,
						" ",
						generalData.valueMonth(this.combomonth.Text.Trim()).ToString(),
						"/",
						this.comboyear.Text,
						": ",
						ex.Message
					}));
                }
            }
        }
        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {
            object[] array = (object[])e.Argument;
            OleDbConnection oleDbConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + array[0].ToString() + ";Extended Properties='Excel 12.0;HDR=Yes;'");
            oleDbConnection.Open();
            int num;
            OleDbDataReader oleDbDataReader;
            try
            {
                num = int.Parse(new OleDbCommand("select COUNT(*) from [" + array[1] + "$] WHERE [Merchant Num] <> null ", oleDbConnection).ExecuteScalar().ToString());
                oleDbDataReader = new OleDbCommand("select * from [" + array[1] + "$] WHERE [Merchant Num] <> null ", oleDbConnection).ExecuteReader();
            }
            catch (Exception)
            {
                MyMessage.showMessage("CSR Monthly format is invalid", MessageBoxIcon.Hand);
                MyLogger.WriteLog(string.Concat(new string[] { this.Text, " ",generalData.valueMonth(this.combomonth.Text.Trim()).ToString(), "/", this.comboyear.Text, ": format is invalid" }));
                oleDbConnection.Close();
                e.Cancel = true;
                return;
            }
            int num2 = 1;
            SqlConnection con = generalData.get_con();
            con.Open();
            try
            {
                while (oleDbDataReader.Read())
                {
                    if (oleDbDataReader[0] != DBNull.Value)
                    {
                        generalData.readXLS(ref oleDbDataReader, ref con, int.Parse(array[3].ToString()), int.Parse(array[2].ToString()));
                        this.myworker.ReportProgress(num2 * 100 / num);
                        num2++;
                    }
                }
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog(string.Concat(new string[]
				{
					this.Text,
					" ",
					generalData.valueMonth(this.combomonth.Text.Trim()).ToString(),
					"/",
					this.comboyear.Text,
					": ",
					ex.Message
				}));
                con.Close();
                oleDbConnection.Close();
                e.Cancel = true;
                return;
            }
            oleDbConnection.Close();
        }
        private void myworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.myprogressbar.Value = e.ProgressPercentage;
        }
        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            if (this.myprogressbar.Value == 100)
            {
                MyMessage.showMessage(this.tbXslPath.Text + " IMPORTED", MessageBoxIcon.Asterisk);
            }
            else
            {
                MyMessage.showMessage("Import has been stopped", MessageBoxIcon.Hand);
            }
        }
    }
}
