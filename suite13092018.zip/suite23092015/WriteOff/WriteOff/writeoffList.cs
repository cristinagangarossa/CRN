﻿using Credit_risk_lib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WriteOff
{
    public partial class writeoffList : Form
    {
        private string tbSheet = string.Empty;
        public writeoffList()
        {
            InitializeComponent();
            this.combomonth.SelectedIndex = 0;
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }
        private void btnbrowser_Click(object sender, EventArgs e)
        {
            this.tbSheet = string.Empty;
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "File Excel (*.xls, *.xlsx)|*.xls; *.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tbXslPath.Text = openFileDialog.FileName;
                MyExcel.FilledString(ref this.tbSheet, this.tbXslPath.Text);
                Cursor.Current = Cursors.Arrow;
            }
        }
        private void btnimport_Click(object sender, EventArgs e)
        {
            this.myprogressbar.Value = 0;
            if (MyControl.checkControl(this))
            {
                try
                {
                    if (generalData.checkExistCSR("T_CSR_MONTHLY", generalData.valueMonth(this.combomonth.Text.Trim()).ToString(), this.comboyear.Text))
                    {
                        base.Enabled = false;
                        MyLogger.WriteLog(this.Text + ": " + this.combomonth.Text + "/" + this.comboyear.Text);
                        this.myworker.RunWorkerAsync(new object[]
						{
							this.tbXslPath.Text,
							this.tbSheet,
							this.combomonth.Text.Trim(),
							this.comboyear.Text.Trim(),
							"new"
						});
                    }
                    else
                    {
                        if (MyMessage.askMessage("CSR exists. It will be overwritten.\nCONTINUE?"))
                        {
                            base.Enabled = false;
                            MyLogger.WriteLog( this.Text + " " + this.combomonth.Text + "/" + this.comboyear.Text + ": overwriting the existing one" );
                            this.myworker.RunWorkerAsync(new object[]
							{
								this.tbXslPath.Text,
								this.tbSheet,
								this.combomonth.Text.Trim(),
								this.comboyear.Text.Trim(),
								"update"
							});
                        }
                    }
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                    MyLogger.WriteLog(this.Text + " " + this.combomonth.Text + "/" + this.comboyear.Text + ": " + ex.Message);
                }
            }
        }
        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {
            object[] args = (object[])e.Argument;
            string[] myParameters = args[1].ToString().Split(';'); // sheet 
            SqlConnection conSql = generalData.get_con();
            OleDbConnection conExcel = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + args[0].ToString() + ";Extended Properties='Excel 12.0;HDR=Yes;'");
            conSql.Open();
            conExcel.Open();

            DataTable dt = new DataTable();
            dt.Columns.Add("mid");
            dt.Columns.Add("name");
            dt.Columns.Add("collector");
            dt.Columns.Add("month");
            dt.Columns.Add("year");
            dt.Columns.Add("glaccount");
            dt.Columns.Add("bucket");
            dt.Columns.Add("amount");

            SqlCommand cmdInsertMonthly = new SqlCommand("INSERT INTO T_CSR_MONTHLY (MERCHANT_NUM, MERCHANT_NAME, COLLECTOR_USER, MONTH, YEAR)  OUTPUT INSERTED.ID_CSR_MONTHLY VALUES (@num, @name, @collector, @month, @year)", conSql);
            cmdInsertMonthly.Parameters.Add("@num", SqlDbType.VarChar);
            cmdInsertMonthly.Parameters.Add("@name", SqlDbType.VarChar);
            cmdInsertMonthly.Parameters.Add("@collector", SqlDbType.VarChar);
            cmdInsertMonthly.Parameters.Add("@month", SqlDbType.SmallInt);
            cmdInsertMonthly.Parameters.Add("@year", SqlDbType.SmallInt);

            SqlCommand cmdInsertDetail = new SqlCommand("INSERT INTO T_CSR_DETAIL (ID_CSR_MONTHLY, BUCKET_NAME, BUCKET_VALUE, GLACCOUNT) VALUES (@mid, @name, @value, @glaccount)", conSql);
            cmdInsertDetail.Parameters.Add("@mid", SqlDbType.Int);
            cmdInsertDetail.Parameters.Add("@name", SqlDbType.Int);
            cmdInsertDetail.Parameters.Add("@value", SqlDbType.Float);
            cmdInsertDetail.Parameters.Add("@glaccount", SqlDbType.VarChar);

            string[] myParameters_copy = myParameters;

            string param;
            OleDbDataReader oleDbDataReader;
            int num;

            for (int i = 0; i < myParameters_copy.Length; i++)
            {
                param = myParameters_copy[i];
                if (!string.IsNullOrWhiteSpace(param))
                {
                    //try
                    //{

                    num = Convert.ToInt32(new OleDbCommand("select COUNT(*) from [" + param + "$] WHERE [MID] <> null AND [Year] = " + args[3].ToString() + " AND [Month] = '" + args[2].ToString() + "'", conExcel).ExecuteScalar().ToString());
                    oleDbDataReader = new OleDbCommand("select * from [" + param + "$] WHERE [MID] <> null AND [Year] = " + args[3].ToString() + " AND [Month] = '" + args[2].ToString() + "'", conExcel).ExecuteReader();
                    
                    //}
                    //catch (Exception ex)
                    //{
                    //    MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                    //    MyLogger.WriteLog(string.Concat(new string[]
                    //        {
                    //            this.Text,
                    //            " ",
                    //            args[2].ToString(),
                    //            "/",
                    //            args[3].ToString(),
                    //            ": ",
                    //            ex.Message
                    //        }));
                    //    conExcel.Close();
                    //    conSql.Close();
                    //    e.Cancel = true;
                    //    return;
                    //}
                    int num2 = 1;
                    try
                    {
                        while (oleDbDataReader.Read())
                        {
                            if (oleDbDataReader[0] != DBNull.Value)
                            {
                                if (args[4].ToString() == "new")
                                {
                                    cmdInsertMonthly.Parameters["@num"].Value = oleDbDataReader[1].ToString();
                                    cmdInsertMonthly.Parameters["@name"].Value = oleDbDataReader[0].ToString();
                                    cmdInsertMonthly.Parameters["@collector"].Value = ((oleDbDataReader[3].ToString() == "54002") ? "Fraud" : "Collection");
                                    cmdInsertMonthly.Parameters["@month"].Value = generalData.valueMonth(args[2].ToString());
                                    cmdInsertMonthly.Parameters["@year"].Value = args[3].ToString().Remove(0, 2);
                                    string value = cmdInsertMonthly.ExecuteScalar().ToString();

                                    cmdInsertDetail.Parameters["@mid"].Value = value;
                                    cmdInsertDetail.Parameters["@name"].Value = generalData.creaBucket(oleDbDataReader[5].ToString()); // converte il bucket con il numero del mese
                                    cmdInsertDetail.Parameters["@value"].Value = double.Parse(oleDbDataReader[4].ToString());//importo
                                    cmdInsertDetail.Parameters["@glaccount"].Value = oleDbDataReader[3].ToString();
                                    cmdInsertDetail.ExecuteNonQuery();
                                }
                                else
                                {
                                    DataRow dataRow = dt.NewRow();
                                    dataRow["mid"] = oleDbDataReader[1].ToString();
                                    dataRow["name"] = oleDbDataReader[0].ToString();
                                    dataRow["collector"] = ((oleDbDataReader[3].ToString() == "54002") ? "Fraud" : "Collection");
                                    dataRow["month"] = generalData.valueMonth(args[2].ToString());
                                    dataRow["year"] = args[3].ToString().Remove(0, 2);
                                    dataRow["glaccount"] = oleDbDataReader[3].ToString();
                                    dataRow["bucket"] = generalData.creaBucket(oleDbDataReader[5].ToString());
                                    dataRow["amount"] = double.Parse(oleDbDataReader[4].ToString());
                                    dt.Rows.Add(dataRow);
                                }
                                this.myworker.ReportProgress(num2 * 100 / num);
                                num2++;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                        MyLogger.WriteLog(string.Concat(new string[]
				            {
					            this.Text,
					            " ",
					            args[2].ToString(),
					            "/",
					            args[3].ToString(),
					            ": ",
					            ex.Message
				            }));
                        conSql.Close();
                        conExcel.Close();
                        e.Cancel = true;
                        return;
                    }
                }
            }
            if (args[4].ToString() == "update")
            {
                SqlConnection con2 = generalData.get_con();
                con2.Open();
                int num3 = int.Parse(new SqlCommand(string.Concat(new object[]
		                        {
			                        "SELECT COUNT(*) FROM T_CSR_MONTHLY WHERE YEAR = ",
			                        args[3].ToString().Remove(0, 2),
			                        " AND MONTH = ",
			                        generalData.valueMonth(args[2].ToString())
		                        }), con2).ExecuteScalar().ToString());
                int num4 = 0;
                SqlDataReader aux = new SqlCommand(string.Concat(new object[]
		                                {
			                                "SELECT * FROM T_CSR_MONTHLY WHERE YEAR = ",
			                                args[3].ToString().Remove(0, 2),
			                                " AND MONTH = ",
			                                generalData.valueMonth(args[2].ToString())
		                                }), con2).ExecuteReader();
                SqlCommand sqlCommand3 = new SqlCommand("DELETE FROM T_CSR_MONTHLY WHERE ID_CSR_MONTHLY = @id ", conSql);
                sqlCommand3.Parameters.Add("@id", SqlDbType.Int);
                SqlCommand sqlCommand4 = new SqlCommand("DELETE FROM T_CSR_DETAIL WHERE ID_CSR_MONTHLY = @id ", conSql);
                sqlCommand4.Parameters.Add("@id", SqlDbType.Int);

                SqlCommand sqlCommand5 = new SqlCommand("UPDATE T_CSR_DETAIL SET GLACCOUNT = @gla, BUCKET_VALUE = @amount WHERE ID_CSR_MONTHLY = @idmonthly AND BUCKET_NAME = @bucket_name", conSql);
                SqlCommand cmdUpdateAllBucketGLAccount = new SqlCommand("UPDATE T_CSR_DETAIL SET GLACCOUNT = @gla WHERE ID_CSR_MONTHLY = @idmonthly", conSql);
                
                sqlCommand5.Parameters.Add("@gla", SqlDbType.VarChar);
                sqlCommand5.Parameters.Add("@amount", SqlDbType.Float);
                sqlCommand5.Parameters.Add("@idmonthly", SqlDbType.Int);
                sqlCommand5.Parameters.Add("@bucket_name", SqlDbType.SmallInt);

                cmdUpdateAllBucketGLAccount.Parameters.Add("@gla", SqlDbType.VarChar);
                cmdUpdateAllBucketGLAccount.Parameters.Add("@idmonthly", SqlDbType.Int);

                while (aux.Read())
                {
                    try
                    {
                        string s = new SqlCommand("SELECT SUM(BUCKET_VALUE) FROM T_CSR_DETAIL WHERE ID_CSR_MONTHLY = " + aux["ID_CSR_MONTHLY"].ToString(), conSql).ExecuteScalar().ToString();
                        DataRow dataRow2 = (from DataRow r in dt.Rows
                                            where r["mid"].ToString() == aux["MERCHANT_NUM"].ToString()
                                            select r).First<DataRow>();

                        if (double.Parse(dataRow2["amount"].ToString()) >= double.Parse(s))// && dataRow2[5].ToString() == "51101")
                        {
                            cmdUpdateAllBucketGLAccount.Parameters["@gla"].Value = dataRow2["glaccount"];
                            cmdUpdateAllBucketGLAccount.Parameters["@idmonthly"].Value = aux["ID_CSR_MONTHLY"];
                            cmdUpdateAllBucketGLAccount.ExecuteNonQuery();
                        }
                        if (double.Parse(dataRow2["amount"].ToString()) < double.Parse(s))
                        {
                            sqlCommand5.Parameters["@gla"].Value = dataRow2["glaccount"];
                            sqlCommand5.Parameters["@amount"].Value = dataRow2["amount"];
                            sqlCommand5.Parameters["@idmonthly"].Value = aux["ID_CSR_MONTHLY"];
                            sqlCommand5.Parameters["@bucket_name"].Value = dataRow2["bucket"];
                            sqlCommand5.ExecuteNonQuery();
                        }
                        dt.Rows.Remove(dataRow2);
                    }
                    catch (Exception)
                    {
                        sqlCommand3.Parameters["@id"].Value = aux["ID_CSR_MONTHLY"].ToString();
                        sqlCommand4.Parameters["@id"].Value = aux["ID_CSR_MONTHLY"].ToString();
                        sqlCommand3.ExecuteNonQuery();
                        sqlCommand4.ExecuteNonQuery();
                    }
                    num4++;
                    this.myworker.ReportProgress(num4 * 100 / num3);
                }
                con2.Close();
                foreach (DataRow dataRow3 in dt.Rows)
                {
                    cmdInsertMonthly.Parameters["@num"].Value = dataRow3["mid"].ToString();
                    cmdInsertMonthly.Parameters["@name"].Value = dataRow3["name"].ToString();
                    cmdInsertMonthly.Parameters["@collector"].Value = dataRow3["collector"].ToString();
                    cmdInsertMonthly.Parameters["@month"].Value = dataRow3["month"].ToString();
                    cmdInsertMonthly.Parameters["@year"].Value = dataRow3["year"].ToString();
                    string value = cmdInsertMonthly.ExecuteScalar().ToString();
                    cmdInsertDetail.Parameters["@mid"].Value = value;
                    cmdInsertDetail.Parameters["@name"].Value = dataRow3["bucket"].ToString();
                    cmdInsertDetail.Parameters["@value"].Value = dataRow3["amount"].ToString();
                    cmdInsertDetail.Parameters["@glaccount"].Value = dataRow3["glaccount"].ToString();
                    cmdInsertDetail.ExecuteNonQuery();
                }
            }
            conSql.Close();
            conExcel.Close();
        }
        private void myworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.myprogressbar.Value = e.ProgressPercentage;
        }
        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            if (this.myprogressbar.Value == 100)
            {
                MyMessage.showMessage(this.tbXslPath.Text + " IMPORTED", MessageBoxIcon.Asterisk);
            }
            else
            {
                MyMessage.showMessage("Import has been stopped", MessageBoxIcon.Hand);
            }
        }
    }
}
