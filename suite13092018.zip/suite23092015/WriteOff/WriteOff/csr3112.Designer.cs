﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace WriteOff
{
    partial class csr3112
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private Button btnbrowser;
        private TextBox tbXslPath;
        private Button btnimport;
        private Button btncancel;
        private ComboBox tbSheet;
        private Label lblsheet;
        private Label lblyear;
        private BackgroundWorker myworker;
        private DateTimePicker comboyear;
        private StatusStrip statusStrip1;
        private ToolStripProgressBar myprogressbar;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.btnbrowser = new Button();
            this.tbXslPath = new TextBox();
            this.btnimport = new Button();
            this.btncancel = new Button();
            this.tbSheet = new ComboBox();
            this.lblsheet = new Label();
            this.lblyear = new Label();
            this.myworker = new BackgroundWorker();
            this.comboyear = new DateTimePicker();
            this.statusStrip1 = new StatusStrip();
            this.myprogressbar = new ToolStripProgressBar();
            this.statusStrip1.SuspendLayout();
            base.SuspendLayout();
            this.btnbrowser.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
            this.btnbrowser.AutoSize = true;
            this.btnbrowser.Location = new Point(18, 19);
            this.btnbrowser.Margin = new Padding(4);
            this.btnbrowser.Name = "btnbrowser";
            this.btnbrowser.Padding = new Padding(3, 0, 3, 0);
            this.btnbrowser.Size = new Size(69, 25);
            this.btnbrowser.TabIndex = 1;
            this.btnbrowser.Text = "Browse..";
            this.btnbrowser.UseVisualStyleBackColor = true;
            this.btnbrowser.Click += new EventHandler(this.btnsearch_Click);
            this.tbXslPath.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
            this.tbXslPath.Location = new Point(93, 21);
            this.tbXslPath.Margin = new Padding(4);
            this.tbXslPath.Name = "tbXslPath";
            this.tbXslPath.ReadOnly = true;
            this.tbXslPath.Size = new Size(263, 23);
            this.tbXslPath.TabIndex = 10;
            this.tbXslPath.Tag = "File Excel";
            this.btnimport.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
            this.btnimport.AutoSize = true;
            this.btnimport.Location = new Point(93, 125);
            this.btnimport.Margin = new Padding(4);
            this.btnimport.Name = "btnimport";
            this.btnimport.Padding = new Padding(3, 0, 3, 0);
            this.btnimport.Size = new Size(89, 25);
            this.btnimport.TabIndex = 4;
            this.btnimport.Text = "Start import";
            this.btnimport.UseVisualStyleBackColor = true;
            this.btnimport.Click += new EventHandler(this.btnimport_Click);
            this.btncancel.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
            this.btncancel.AutoSize = true;
            this.btncancel.Location = new Point(205, 125);
            this.btncancel.Margin = new Padding(4);
            this.btncancel.Name = "btncancel";
            this.btncancel.Padding = new Padding(3, 0, 3, 0);
            this.btncancel.Size = new Size(60, 25);
            this.btncancel.TabIndex = 5;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new EventHandler(this.btncancel_Click);
            this.tbSheet.DropDownStyle = ComboBoxStyle.DropDownList;
            this.tbSheet.FormattingEnabled = true;
            this.tbSheet.Location = new Point(93, 54);
            this.tbSheet.Margin = new Padding(4);
            this.tbSheet.Name = "tbSheet";
            this.tbSheet.Size = new Size(263, 23);
            this.tbSheet.TabIndex = 2;
            this.lblsheet.AutoSize = true;
            this.lblsheet.Location = new Point(49, 57);
            this.lblsheet.Margin = new Padding(4, 0, 4, 0);
            this.lblsheet.Name = "lblsheet";
            this.lblsheet.Size = new Size(36, 15);
            this.lblsheet.TabIndex = 6;
            this.lblsheet.Text = "Sheet";
            this.lblyear.AutoSize = true;
            this.lblyear.Location = new Point(55, 93);
            this.lblyear.Margin = new Padding(4, 0, 4, 0);
            this.lblyear.Name = "lblyear";
            this.lblyear.Size = new Size(30, 15);
            this.lblyear.TabIndex = 7;
            this.lblyear.Text = "Year";
            this.myworker.WorkerReportsProgress = true;
            this.myworker.DoWork += new DoWorkEventHandler(this.myworker_DoWork);
            this.myworker.ProgressChanged += new ProgressChangedEventHandler(this.myworker_ProgressChanged);
            this.myworker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(this.myworker_RunWorkerCompleted);
            this.comboyear.CustomFormat = "yyyy";
            this.comboyear.Format = DateTimePickerFormat.Custom;
            this.comboyear.Location = new Point(93, 87);
            this.comboyear.Margin = new Padding(4);
            this.comboyear.Name = "comboyear";
            this.comboyear.ShowUpDown = true;
            this.comboyear.Size = new Size(110, 23);
            this.comboyear.TabIndex = 3;
            this.statusStrip1.Items.AddRange(new ToolStripItem[]
			{
				this.myprogressbar
			});
            this.statusStrip1.Location = new Point(0, 172);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(374, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 28;
            this.statusStrip1.Text = "statusStrip1";
            this.myprogressbar.Name = "myprogressbar";
            this.myprogressbar.Size = new Size(370, 16);
            base.AutoScaleDimensions = new SizeF(7f, 15f);
            base.ClientSize = new Size(374, 194);
            base.Controls.Add(this.statusStrip1);
            base.Controls.Add(this.comboyear);
            base.Controls.Add(this.lblyear);
            base.Controls.Add(this.lblsheet);
            base.Controls.Add(this.tbSheet);
            base.Controls.Add(this.btncancel);
            base.Controls.Add(this.btnimport);
            base.Controls.Add(this.tbXslPath);
            base.Controls.Add(this.btnbrowser);
            this.Font = new Font("Calibri", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            base.Margin = new Padding(4);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "csr3112";
            base.ShowIcon = false;
            base.ShowInTaskbar = false;
            this.Text = "Writeoff - Import CSR 31/12";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        #endregion
    }
}