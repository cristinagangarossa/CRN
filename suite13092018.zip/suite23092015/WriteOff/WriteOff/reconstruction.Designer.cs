﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace WriteOff
{
    partial class reconstruction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private Button btnCancel;
        private Button btnSave;
        private TextBox txtpercorso;
        private Button btnpercorso;
        private BackgroundWorker mywork;
        private Label label1;
        private ComboBox monthChoose;
        private Label label2;
        private Label lblyear;
        private DateTimePicker yearChoose;
        private DateTimePicker comboyear;
        private StatusStrip statusStrip1;
        private ToolStripProgressBar mybar;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnCancel = new Button();
            this.btnSave = new Button();
            this.txtpercorso = new TextBox();
            this.btnpercorso = new Button();
            this.mywork = new BackgroundWorker();
            this.label1 = new Label();
            this.monthChoose = new ComboBox();
            this.label2 = new Label();
            this.lblyear = new Label();
            this.yearChoose = new DateTimePicker();
            this.comboyear = new DateTimePicker();
            this.statusStrip1 = new StatusStrip();
            this.mybar = new ToolStripProgressBar();
            this.statusStrip1.SuspendLayout();
            base.SuspendLayout();
            this.btnCancel.AutoSize = true;
            this.btnCancel.Location = new Point(164, 156);
            this.btnCancel.Margin = new Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Padding = new Padding(3, 0, 3, 0);
            this.btnCancel.Size = new Size(60, 25);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new EventHandler(this.btnCancel_Click);
            this.btnSave.AutoSize = true;
            this.btnSave.Location = new Point(93, 156);
            this.btnSave.Margin = new Padding(4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Padding = new Padding(3, 0, 3, 0);
            this.btnSave.Size = new Size(48, 25);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new EventHandler(this.btnSave_Click);
            this.txtpercorso.Location = new Point(93, 21);
            this.txtpercorso.Margin = new Padding(4);
            this.txtpercorso.Name = "txtpercorso";
            this.txtpercorso.ReadOnly = true;
            this.txtpercorso.Size = new Size(263, 23);
            this.txtpercorso.TabIndex = 10;
            this.txtpercorso.Tag = "File Excel";
            this.btnpercorso.AutoSize = true;
            this.btnpercorso.Location = new Point(18, 19);
            this.btnpercorso.Margin = new Padding(4);
            this.btnpercorso.Name = "btnpercorso";
            this.btnpercorso.Padding = new Padding(3, 0, 3, 0);
            this.btnpercorso.Size = new Size(72, 25);
            this.btnpercorso.TabIndex = 1;
            this.btnpercorso.Text = "Browse..";
            this.btnpercorso.UseVisualStyleBackColor = true;
            this.btnpercorso.Click += new EventHandler(this.btnpercorso_Click);
            this.mywork.WorkerReportsProgress = true;
            this.mywork.DoWork += new DoWorkEventHandler(this.mywork_DoWork);
            this.mywork.ProgressChanged += new ProgressChangedEventHandler(this.mywork_ProgressChanged);
            this.mywork.RunWorkerCompleted += new RunWorkerCompletedEventHandler(this.mywork_RunWorkerCompleted);
            this.label1.AutoSize = true;
            this.label1.Location = new Point(24, 58);
            this.label1.Margin = new Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new Size(66, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "Year 31/12";
            this.monthChoose.DropDownStyle = ComboBoxStyle.DropDownList;
            this.monthChoose.FormattingEnabled = true;
            this.monthChoose.Items.AddRange(new object[]
			{
				"January ",
				"February ",
				"March ",
				"April ",
				"May ",
				"June ",
				"July ",
				"August",
				"September",
				"October",
				"November",
				"December"
			});
            this.monthChoose.Location = new Point(93, 87);
            this.monthChoose.Margin = new Padding(4);
            this.monthChoose.Name = "monthChoose";
            this.monthChoose.Size = new Size(109, 23);
            this.monthChoose.TabIndex = 3;
            this.label2.AutoSize = true;
            this.label2.Location = new Point(47, 90);
            this.label2.Margin = new Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new Size(43, 15);
            this.label2.TabIndex = 22;
            this.label2.Text = "Month";
            this.lblyear.AutoSize = true;
            this.lblyear.Location = new Point(60, 121);
            this.lblyear.Margin = new Padding(4, 0, 4, 0);
            this.lblyear.Name = "lblyear";
            this.lblyear.Size = new Size(30, 15);
            this.lblyear.TabIndex = 20;
            this.lblyear.Text = "Year";
            this.yearChoose.CustomFormat = "yyyy";
            this.yearChoose.Format = DateTimePickerFormat.Custom;
            this.yearChoose.Location = new Point(93, 118);
            this.yearChoose.Margin = new Padding(4);
            this.yearChoose.Name = "yearChoose";
            this.yearChoose.ShowUpDown = true;
            this.yearChoose.Size = new Size(110, 23);
            this.yearChoose.TabIndex = 4;
            this.comboyear.CustomFormat = "yyyy";
            this.comboyear.Format = DateTimePickerFormat.Custom;
            this.comboyear.Location = new Point(93, 54);
            this.comboyear.Margin = new Padding(4);
            this.comboyear.Name = "comboyear";
            this.comboyear.ShowUpDown = true;
            this.comboyear.Size = new Size(110, 23);
            this.comboyear.TabIndex = 2;
            this.statusStrip1.Items.AddRange(new ToolStripItem[]
			{
				this.mybar
			});
            this.statusStrip1.Location = new Point(0, 198);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(374, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 32;
            this.statusStrip1.Text = "statusStrip1";
            this.mybar.Name = "mybar";
            this.mybar.Size = new Size(370, 16);
            base.AutoScaleDimensions = new SizeF(7f, 15f);
            base.ClientSize = new Size(374, 220);
            base.Controls.Add(this.statusStrip1);
            base.Controls.Add(this.comboyear);
            base.Controls.Add(this.yearChoose);
            base.Controls.Add(this.monthChoose);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.lblyear);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.btnCancel);
            base.Controls.Add(this.btnSave);
            base.Controls.Add(this.txtpercorso);
            base.Controls.Add(this.btnpercorso);
            this.Font = new System.Drawing.Font("Calibri", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            base.Margin = new Padding(4);
            base.MaximizeBox = false;
            base.MinimizeBox = false;
            base.Name = "recostruction";
            base.ShowIcon = false;
            this.Text = "Writeoff - Export debt reconstruction";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        #endregion
    }
}