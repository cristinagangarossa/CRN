﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.IO;
using System.Collections;
using System.Web;
using System.Net;
//using Credit_risk_lib;
using System.Data.OleDb;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

namespace IceImport
{
    public partial class IceStart : Form
    {
        bool closeConsole = false;
        //viewConsole win;
        public IceStart()
        {
            InitializeComponent();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            this.myprogressbar.Value = 0;
           if (MyControl.checkControl(this.source_file))
           {
               
               base.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                MyLogger.WriteLog(this.Text + ": start import");
                this.myworker.RunWorkerAsync(new object[] { this.tbXslPath.Text, this.tbSheet.Text });
               
              /*  win = (Application.OpenForms["viewConsole"] != null) ? ((viewConsole)Application.OpenForms["viewConsole"]) : null;
                if (win == null)
                {
                    win = new viewConsole();
                    win.Show();
                    closeConsole = true;
                }*/

                if (!MyConsole.mostraCONSOLE.Visible)
                {
                    MyConsole.mostraCONSOLE.Show();
                    closeConsole = true;
                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "File Excel (*.xls, *.xlsx)|*.xls; *.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tbXslPath.Text = openFileDialog.FileName;
                MyExcel.FilledCombobox(ref this.tbSheet, this.tbXslPath.Text);
                Cursor.Current = Cursors.Arrow;
            }
        }

        private static Stream CopyAndClose(Stream inputStream)
        {
            byte[] buffer = new byte[256];
            MemoryStream memoryStream = new MemoryStream();
            for (int i = inputStream.Read(buffer, 0, 256); i > 0; i = inputStream.Read(buffer, 0, 256))
            {
                memoryStream.Write(buffer, 0, i);
            }
            memoryStream.Position = 0L;
            inputStream.Close();
            return memoryStream;
        }

        private static string getMerchantData(StreamReader srHtml, int mode)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            string text;
            
            while ((text = srHtml.ReadLine()) != null)
            {
                if (text.IndexOf("\"TextBox") != -1)
                {
                    int num = text.IndexOf("name=") + 6;
                    int num2 = text.IndexOf("\"", num);
                    int length = num2 - num;
                    string text2 = text.Substring(num, length);
                    string value;
                    if (text.IndexOf("value=") != -1)
                    {
                        num = text.IndexOf("value=") + 7;
                        num2 = text.IndexOf("\"", num);
                        length = num2 - num;
                        value = text.Substring(num, length);
                    }
                    else
                    {
                        value = "";
                    }
                    dictionary.Add(text2, value);
                }
                else
                {
                    if (text.IndexOf("\"DropDownList") != -1)
                    {
                        int num = text.IndexOf("name=") + 6;
                        int num2 = text.IndexOf("\"", num);
                        int length = num2 - num;
                        string text2 = text.Substring(num, length);
                        while (text.IndexOf("<option") == -1 && text.IndexOf("</select>") == -1)
                        {
                            text = srHtml.ReadLine();
                        }
                        if (text.IndexOf("</select>") == -1)
                        {
                            num = text.IndexOf("value=") + 7;
                            num2 = text.IndexOf("\"", num);
                            length = num2 - num;
                            string value = text.Substring(num, length);
                            while (text.IndexOf("</select>") == -1)
                            {
                                text = srHtml.ReadLine();
                                if (text.IndexOf("selected=\"selected\"") != -1)
                                {
                                    num = text.IndexOf("value=") + 7;
                                    num2 = text.IndexOf("\"", num);
                                    length = num2 - num;
                                    value = text.Substring(num, length);
                                }
                            }
                            if (mode == 0)
                            {
                                if (text2 == "DropDownList3")
                                {
                                    value = "8";
                                }
                                if (text2 == "DropDownList20")
                                {
                                    value = "26";
                                }
                            }
                            else
                            {
                                if (mode == 1)
                                {
                                    if (text2 == "DropDownList3")
                                    {
                                        value = "11";
                                    }
                                    if (text2 == "DropDownList20")
                                    {
                                        value = "26";
                                    }
                                }
                                else
                                {
                                    if (mode == 2)
                                    {
                                        if (text2 == "DropDownList3")
                                        {
                                            value = "13";
                                        }
                                        if (text2 == "DropDownList20")
                                        {
                                            value = "30";
                                        }
                                    }
                                    else
                                    {
                                        if (mode == 20)
                                        {
                                            if (text2 == "DropDownList5")
                                            {
                                                value = "349";
                                            }
                                        }
                                    }
                                }
                            }
                            dictionary.Add(text2, value);
                        }
                    }
                }
            }
            string text3 = "";
            foreach (KeyValuePair<string, string> current in dictionary)
            {
                string text4 = text3;
                text3 = string.Concat(new string[]
		{
			text4,
			"&",
			current.Key,
			"=",
			HttpUtility.UrlEncode(current.Value)
		});
            }
            return text3;
        }

        private static ArrayList getViewStateAndEventVal(StreamReader srHtml)
        {
            ArrayList arrayList = new ArrayList(2);
            string text;
            while ((text = srHtml.ReadLine()) != null)
            {
                if (text.IndexOf("\"__VIEWSTATE\"") != -1)
                {
                    int num = text.IndexOf("value=") + 7;
                    int num2 = text.IndexOf("\"", num);
                    int length = num2 - num;
                    arrayList.Insert(0, text.Substring(num, length));
                }
                if (text.IndexOf("\"__EVENTVALIDATION\"") != -1)
                {
                    int num = text.IndexOf("value=") + 7;
                    int num2 = text.IndexOf("\"", num);
                    int length = num2 - num;
                    arrayList.Insert(1, text.Substring(num, length));
                }
            }
            return arrayList;
        }

        //method to bypass invalid certificate
        static bool MyCertHandler(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors error)
        {
            // Ignore errors
            return true;
        }
        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {
            
           object[] array = (object[])e.Argument;
            try
            {

                //call method to bypass certificate
               ServicePointManager.ServerCertificateValidationCallback = MyCertHandler;
                //
                CookieContainer myCook = new CookieContainer();
                //string url = MyConnection.con_ice_import.url;
                string url = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/" + MyConnection.con_ice_import.url2;
                MyConsole.enqueue("Connection to " + url);
                WebClient wc = new WebClient();
                Stream st = wc.OpenRead(url);
                StreamReader sr = new StreamReader(st);

                ArrayList VsAndEv = new ArrayList(2);
                VsAndEv = getViewStateAndEventVal(sr);
                sr.Close();
                st.Close();

                string viewstate = (string)VsAndEv[0];
                string eventvalidation = (string)VsAndEv[1];

                viewstate = HttpUtility.UrlEncode(viewstate);
                eventvalidation = HttpUtility.UrlEncode(eventvalidation);
               // string data = "__LASTFOCUS=&__VIEWSTATE=" + viewstate + "&TextBox1=" + HttpUtility.UrlEncode(MyConnection.con_ice_import.username) + "&TextBox2=" + HttpUtility.UrlEncode(MyConnection.con_ice_import.url2) + "&Button1=Login&__EVENTTARGET=&__EVENTARGUMENT=&__EVENTVALIDATION=" + eventvalidation;
                string data = "__LASTFOCUS=&__VIEWSTATE=" + viewstate + "&TextBox1=" + HttpUtility.UrlEncode(MyConnection.con_ice_import.username) + "&TextBox2=" + HttpUtility.UrlEncode(MyConnection.con_ice_import.pwd) + "&Button1=Login&__EVENTTARGET=&__EVENTARGUMENT=&__EVENTVALIDATION=" + eventvalidation;
               
                byte[] buffer = Encoding.UTF8.GetBytes(data);

                // Step1: Login

                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "POST";
                req.ContentType = "application/x-www-form-urlencoded";
                req.ContentLength = buffer.Length;

                req.Proxy = WebProxy.GetDefaultProxy();
                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                req.CookieContainer = myCook; // enable cookies

                Stream reqst = req.GetRequestStream(); // add form data to request stream
                reqst.Write(buffer, 0, buffer.Length);
                reqst.Flush();
                reqst.Close();

                HttpWebResponse res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                Stream resst = CopyAndClose(res.GetResponseStream()); // display HTTP response
                StreamReader srResponse = new StreamReader(resst);
                MyConsole.enqueue("Try To Log In  = "+ MyConnection.con_ice_import.username);

                //Check credenziali
                string line;
                while ((line = srResponse.ReadLine()) != null)
                {
                    if (line.IndexOf("Invalid User ID Or Password") != -1)
                    {
                        MessageBox.Show("Invalid User ID Or Password", "ICE Import", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                MyConsole.enqueue("Logged in username = " + MyConnection.con_ice_import.username);
                
                resst.Position = 0; //Reset dello streamReader 
                srResponse = new StreamReader(resst); //Reset dello streamReader 

                //Step 2: Select Group
                //url = "http://" + MyConnection.con_ice_import.ip + "/ICE/SelectGroup.aspx";
                url = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/ICE/SelectGroup.aspx";
             
                req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "POST";
                req.ContentType = "application/x-www-form-urlencoded";

                VsAndEv = getViewStateAndEventVal(srResponse);
                
                srResponse.Close();
                resst.Close();
                viewstate = (string)VsAndEv[0];
                eventvalidation = (string)VsAndEv[1];

                viewstate = HttpUtility.UrlEncode(viewstate);
                eventvalidation = HttpUtility.UrlEncode(eventvalidation);

                data = "__EVENTTARGET=GridView1&__EVENTARGUMENT=Select%240&__VIEWSTATE=" + viewstate + "&__EVENTVALIDATION=" + eventvalidation;
                buffer = Encoding.UTF8.GetBytes(data);

                req.ContentLength = buffer.Length;

                req.Proxy = WebProxy.GetDefaultProxy();
                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                req.CookieContainer = myCook; // enable cookies

                reqst = req.GetRequestStream(); // add form data to request stream
                reqst.Write(buffer, 0, buffer.Length);
                reqst.Flush();
                reqst.Close();

                res.Close();
                res = (HttpWebResponse)req.GetResponse(); // send request,  get response
               
                //Inizio ciclo excel
                
                string con = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + tbXslPath.Text + ";Extended Properties='Excel 12.0;HDR=No;'";
                using (OleDbConnection connection = new OleDbConnection(con))
                {
                    
                    connection.Open();
                    
                    OleDbCommand command = new OleDbCommand("select * from [" + tbSheet.Text + "$]", connection);

                   
                    using (OleDbDataReader dr = command.ExecuteReader())
                    {
                      
                        while (dr.Read())
                        {
                            
                            if ( dr[0].ToString() != "")
                            {
                                
                                MyConsole.enqueue(" nuova riga " + dr[0] );
                                if (rbWriteoff.Checked) //Operazione aggiuntiva x WriteOff
                                {
                                    //Step 3: Merchant data update
                                    //url = "http://" + MyConnection.con_ice_import.ip + "/ICE/MerchantSelection.aspx";
                                    url = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/ICE/MerchantSelection.aspx";
                                   //Blocco per prelievo Response ------------------------------
                                    req = (HttpWebRequest)WebRequest.Create(url);
                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                                    req.CookieContainer = myCook; // enable cookies
                                    res.Close();
                                    res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                    resst = CopyAndClose(res.GetResponseStream()); // display HTTP response
                                    srResponse = new StreamReader(resst);
                                    // Fine blocco ----------------------------------------------

                                    req = (HttpWebRequest)WebRequest.Create(url);
                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                                    req.CookieContainer = myCook; // enable cookies

                                    req.Method = "POST";
                                    req.ContentType = "application/x-www-form-urlencoded";

                                    VsAndEv = getViewStateAndEventVal(srResponse);

                                    viewstate = (string)VsAndEv[0];
                                    eventvalidation = (string)VsAndEv[1];
                                    viewstate = UpperCaseUrlEncode(viewstate);
                                    eventvalidation = UpperCaseUrlEncode(eventvalidation);

                                    srResponse.Close();
                                    resst.Close();

                                    data = "__VIEWSTATE=" + viewstate + "&TextBox40=&TextBox1=" + dr[0] + "&TextBox2=&TextBox6=&DropDownList1=+&DropDownList2=&DropDownList3=&TextBox5=&TextBox7=&TextBox9=&TextBox15=&TextBox42=&DropDownList6=&DropDownList7=++&TextBox3=&DropDownList9=++&DropDownList10=21&TextBox8=&TextBox30=&TextBox33=&DropDownList16=++&DropDownList17=7&TextBox16=&DropDownList21=++&DropDownList4=7&TextBox4=&DropDownList30=&DropDownList31=++&DropDownList11=8&DropDownList12=++&TextBox10=&DropDownList13=7&TextBox11=&DropDownList14=7&TextBox12=&TextBox13=&TextBox14=&DropDownList15=8&TextBox18=&TextBox17=&TextBox19=&TextBox20=&TextBox21=&TextBox39=&TextBox29=&TextBox28=&TextBox32=&DropDownList19=8&DropDownList20=++&TextBox22=&TextBox23=&TextBox24=&DropDownList22=++&DropDownList23=8&TextBox25=&DropDownList24=8&TextBox26=&DropDownList25=8&DropDownList26=15&DropDownList27=7&TextBox27=&DropDownList28=11&DropDownList29=&TextBox31=&Button3=Select+Merchants&__EVENTVALIDATION=" + eventvalidation;

                                    buffer = Encoding.UTF8.GetBytes(data);

                                    req.ContentLength = buffer.Length;

                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                    req.CookieContainer = myCook; // enable cookies

                                    reqst = req.GetRequestStream(); // add form data to request stream
                                    reqst.Write(buffer, 0, buffer.Length);
                                    reqst.Flush();
                                    reqst.Close();

                                    res.Close();
                                    res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                    MyConsole.enqueue("Merchant " + dr[0] + " = \"Transfer to WO queue Step 1 of 3 completed\"");

                                    //Step 2 x WO
                                    //url = "http://" + MyConnection.con_ice_import.ip + "/ICE/MerchantSelectionGrid.aspx";
                                    url = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/ICE/MerchantSelectionGrid.aspx";
                                   
                                    //Blocco per prelievo Response ------------------------------
                                    req = (HttpWebRequest)WebRequest.Create(url);
                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                                    req.CookieContainer = myCook; // enable cookies
                                    res.Close();
                                    res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                    resst = CopyAndClose(res.GetResponseStream()); // display HTTP response
                                    srResponse = new StreamReader(resst);
                                    // Fine blocco ----------------------------------------------

                                    req = (HttpWebRequest)WebRequest.Create(url);
                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                                    req.CookieContainer = myCook; // enable cookies

                                    req.Method = "POST";
                                    req.ContentType = "application/x-www-form-urlencoded";

                                    VsAndEv = getViewStateAndEventVal(srResponse);

                                    viewstate = (string)VsAndEv[0];
                                    eventvalidation = (string)VsAndEv[1];
                                    viewstate = UpperCaseUrlEncode(viewstate);
                                    eventvalidation = UpperCaseUrlEncode(eventvalidation);

                                    srResponse.Close();
                                    resst.Close();

                                    data = "__EVENTTARGET=GridView1&__EVENTARGUMENT=Delete%240&__VIEWSTATE=" + viewstate + "&DropDownList2=CBalance&CheckBox1=on&CheckBox7=on&CheckBox8=on&DropDownList3=0&TextBox3=&__VIEWSTATEENCRYPTED=&__EVENTVALIDATION=" + eventvalidation;

                                    buffer = Encoding.UTF8.GetBytes(data);

                                    req.ContentLength = buffer.Length;

                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                    req.CookieContainer = myCook; // enable cookies

                                    reqst = req.GetRequestStream(); // add form data to request stream
                                    reqst.Write(buffer, 0, buffer.Length);
                                    reqst.Flush();
                                    reqst.Close();

                                    res.Close();
                                    res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                    MyConsole.enqueue("Merchant " + dr[0] + " = \"Transfer to WO queue Step 2 of 3 completed\"");

                                    //Step 3 x WO
                                    //url = "http://" + MyConnection.con_ice_import.ip + "/ICE/MerchantSelection.aspx?MerchNO=" + dr[0];
                                    url = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/ICE/MerchantSelection.aspx?MerchNO=" + dr[0];
                                    //Blocco per prelievo Response ------------------------------
                                    req = (HttpWebRequest)WebRequest.Create(url);
                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                                    req.CookieContainer = myCook; // enable cookies
                                    res.Close();
                                    res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                    resst = CopyAndClose(res.GetResponseStream()); // display HTTP response
                                    srResponse = new StreamReader(resst);
                                    // Fine blocco ----------------------------------------------

                                    req = (HttpWebRequest)WebRequest.Create(url);
                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                                    req.CookieContainer = myCook; // enable cookies

                                    req.Method = "POST";
                                    req.ContentType = "application/x-www-form-urlencoded";

                                    VsAndEv = getViewStateAndEventVal(srResponse);

                                    viewstate = (string)VsAndEv[0];
                                    eventvalidation = (string)VsAndEv[1];
                                    viewstate = UpperCaseUrlEncode(viewstate);
                                    eventvalidation = UpperCaseUrlEncode(eventvalidation);

                                    resst.Position = 0;
                                    srResponse = new StreamReader(resst);

                                    data = "__VIEWSTATE=" + viewstate + getMerchantData(srResponse, 20) + "&Button13=Process+Workflow+Action&__EVENTVALIDATION=" + eventvalidation;
                                    srResponse.Close();
                                    resst.Close();
                                    buffer = Encoding.UTF8.GetBytes(data);

                                    req.ContentLength = buffer.Length;

                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                    req.CookieContainer = myCook; // enable cookies

                                    reqst = req.GetRequestStream(); // add form data to request stream
                                    reqst.Write(buffer, 0, buffer.Length);
                                    reqst.Flush();
                                    reqst.Close();

                                    try
                                    {
                                        res.Close();
                                        res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                        MyConsole.enqueue("Merchant " + dr[0] + " = \"Transfer to WO queue Step 3 of 3 completed\"");
                                    }
                                    catch (WebException step3Excp)
                                    {
                                        MyConsole.enqueue("Merchant " + dr[0] + " = \"ERROR ON STEP 3\"");
                                        MyConsole.enqueue("Merchant " + dr[0] + " = \"Merchant already on WO Queue?\"");
                                    }
                                }

                                //Step 3: Merchant data update
                               // url = "http://" + MyConnection.con_ice_import.ip + "/ICE/MerchantSelection.aspx?MerchNO=" + dr[0];
                                url = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/ICE/MerchantSelection.aspx?MerchNO=" + dr[0];
                                //Blocco per prelievo Response ------------------------------
                                req = (HttpWebRequest)WebRequest.Create(url);
                                req.Proxy = WebProxy.GetDefaultProxy();
                                req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                                req.CookieContainer = myCook; // enable cookies
                                res.Close();
                                res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                resst = CopyAndClose(res.GetResponseStream()); // display HTTP response
                                srResponse = new StreamReader(resst);
                                
                                // Fine blocco ----------------------------------------------

                                req = (HttpWebRequest)WebRequest.Create(url);
                                req.Proxy = WebProxy.GetDefaultProxy();
                                req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                                req.CookieContainer = myCook; // enable cookies

                                req.Method = "POST";
                                req.ContentType = "application/x-www-form-urlencoded";

                                VsAndEv = getViewStateAndEventVal(srResponse);

                                viewstate = (string)VsAndEv[0];
                                eventvalidation = (string)VsAndEv[1];
                                viewstate = UpperCaseUrlEncode(viewstate);
                                eventvalidation = UpperCaseUrlEncode(eventvalidation);

                                resst.Position = 0;
                                srResponse = new StreamReader(resst);
                                
                                int mode = 1;
                                string nodeMode = "28";
                                string descMode = "In Collection";
                                if (rbAgency.Checked)
                                {
                                    mode = 0;
                                    nodeMode = "40";
                                    descMode = "Agency";
                                }
                                else if (rbLetters.Checked)
                                {
                                    mode = 1;
                                    nodeMode = "28";
                                    descMode = "In Collection";
                                }
                                else if (rbWriteoff.Checked)
                                {
                                    mode = 2;
                                    nodeMode = "33";
                                    descMode = "WriteOff";
                                }
                               
                                string merchantData = getMerchantData(srResponse, mode);
                                MyConsole.enqueue(" Merchant is" + merchantData);
                                srResponse.Close();
                                resst.Close();

                                data = "__VIEWSTATE=" + viewstate + merchantData + "&Button10=Update+Merchant&__EVENTVALIDATION=" + eventvalidation;
                                //textBox1.Text = data;
                                //return;
                                buffer = Encoding.UTF8.GetBytes(data);

                                req.ContentLength = buffer.Length;

                                req.Proxy = WebProxy.GetDefaultProxy();
                                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                req.CookieContainer = myCook; // enable cookies

                                reqst = req.GetRequestStream(); // add form data to request stream
                                reqst.Write(buffer, 0, buffer.Length);
                                reqst.Flush();
                                reqst.Close();

                                res.Close();
                                res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                MyConsole.enqueue("Merchant " + dr[0] + " = \"" + descMode + "\"");
                                
                                //Step 4: Merchant data update
                               // url = "http://" + MyConnection.con_ice_import.ip + "/ICE/MerchantNotes.aspx?MerchNO=" + dr[0];
                                url = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/ICE/MerchantNotes.aspx?MerchNO=" + dr[0];
                                MyConsole.enqueue("url " + url);
                                //Blocco per prelievo Response ------------------------------
                                req = (HttpWebRequest)WebRequest.Create(url);
                                req.Proxy = WebProxy.GetDefaultProxy();
                                req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                                req.CookieContainer = myCook; // enable cookies
                                res.Close();
                                res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                resst = res.GetResponseStream(); // display HTTP response
                                MyConsole.enqueue("rest " + resst);
                                srResponse = new StreamReader(resst);

                                // Fine blocco ----------------------------------------------

                                req = (HttpWebRequest)WebRequest.Create(url);
                                req.Proxy = WebProxy.GetDefaultProxy();
                                req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                                req.CookieContainer = myCook; // enable cookies

                                req.Method = "POST";
                                req.ContentType = "application/x-www-form-urlencoded";

                                VsAndEv = getViewStateAndEventVal(srResponse);

                                viewstate = (string)VsAndEv[0];
                                eventvalidation = (string)VsAndEv[1];
                                viewstate = UpperCaseUrlEncode(viewstate);
                                eventvalidation = UpperCaseUrlEncode(eventvalidation);

                                data = "__EVENTTARGET=&__EVENTARGUMENT=&__LASTFOCUS=&__VIEWSTATE=" + viewstate + "&TextBox40=&rb2=RadioButton3&rb1=RadioButton1&TextBox9=&DropDownList3=" + nodeMode + "&TextBox10=" + UpperCaseUrlEncode(dr[1].ToString()) + "&TextBox8=" + UpperCaseUrlEncode(dr[2].ToString()) + "&Button3=Add+New+Note&DropDownList4=978&__VIEWSTATEENCRYPTED=&__EVENTVALIDATION=" + eventvalidation;
                                srResponse.Close();
                                resst.Close();
                                buffer = Encoding.UTF8.GetBytes(data);

                                req.ContentLength = buffer.Length;

                                req.Proxy = WebProxy.GetDefaultProxy();
                                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                req.CookieContainer = myCook; // enable cookies

                                reqst = req.GetRequestStream(); // add form data to request stream
                                reqst.Write(buffer, 0, buffer.Length);
                                reqst.Flush();
                                reqst.Close();

                                res.Close();
                                res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                               
                                MyConsole.enqueue("Merchant " + dr[0].ToString() + " insert Note = \"" + dr[2].ToString() + "\"");
                               
                                res.Close();
                                
                                MyConsole.enqueue("end insert ");
                            }
                            
                        }
                        
                    }
                }
                MyConsole.enqueue("END OF PROGRAM: File " + tbXslPath.Text + " imported");
                MessageBox.Show("End of program\r\nFile " + tbXslPath.Text + " imported", "ICE Import", MessageBoxButtons.OK, MessageBoxIcon.Information);
           }
            catch (WebException ex)
            {
                MyConsole.enqueue("Exception Message :" + ex.Message);
                MyLogger.WriteLog(this.Text + " Exception Message :" + ex.Message);
                if (ex.Status == WebExceptionStatus.ProtocolError)
                {
                    HttpWebResponse httpWebResponse2 = (HttpWebResponse)ex.Response;
                    MyConsole.enqueue("Status Code : " + httpWebResponse2.StatusCode);
                    MyConsole.enqueue("Status Description : " + httpWebResponse2.StatusDescription);
                    MyMessage.showMessage("Error\nFile " + array[0].ToString() + " not imported", MessageBoxIcon.Hand);
                    MyLogger.WriteLog("Error\nFile " + array[0].ToString() + " not imported");
                }
           }
            catch (Exception ex2)
            {
                MyConsole.enqueue("Exception Message :" + ex2.Message);
                MyLogger.WriteLog(this.Text + " Exception Message :" + ex2.Message);
                MyMessage.showMessage(this.Text + " Exception Message :" + ex2.Message, MessageBoxIcon.Hand);
            }
        }

        private void myworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.myprogressbar.Value = e.ProgressPercentage;
        }

        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            Cursor.Current = Cursors.Arrow;
            /*if (this.myprogressbar.Value == 100)
            {
                MyMessage.showMessage(this.tbXslPath.Text + " IMPORTED", MessageBoxIcon.Asterisk);
            }
            else
            {
                MyMessage.showMessage("Import has been stopped", MessageBoxIcon.Hand);
            }*/
            if (closeConsole)
            {
                //win.Close();
                //win = null;
                MyConsole.mostraCONSOLE.Hide();
            }
        }

        private static string UpperCaseUrlEncode(string s)
        {
            char[] array = HttpUtility.UrlEncode(s).ToCharArray();
            for (int i = 0; i < array.Length - 2; i++)
            {
                if (array[i] == '%')
                {
                    array[i + 1] = char.ToUpper(array[i + 1]);
                    array[i + 2] = char.ToUpper(array[i + 2]);
                }
            }
            return new string(array);
        }

    }
}
