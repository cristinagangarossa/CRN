﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace FraudManager
{
    public partial class frmImportFromExcel : Form
    {
        //viewConsole viewConsole;
        bool closeWin = false;

        public frmImportFromExcel()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.myprogressbar.Value = 0;
            if (MyControl.checkControl(this.sourcefile))
            {
                base.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                MyLogger.WriteLog(this.Text + ": start import");
                this.myworker.RunWorkerAsync(new object[] { this.tbXslPath.Text, this.tbSheet.Text });

                if (!MyConsole.mostraCONSOLE.Visible)
                {
                    MyConsole.mostraCONSOLE.Show();
                    closeWin = true;
                }

                /*iewConsole = (Application.OpenForms["viewConsole"] != null) ? ((viewConsole)Application.OpenForms["csr3112"]) : null;
                if (viewConsole == null)
                {
                    viewConsole = new viewConsole();
                    viewConsole.Show();
                    closeWin = true;
                }*/
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "File Excel (*.xls, *.xlsx)|*.xls; *.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tbXslPath.Text = openFileDialog.FileName;
                MyExcel.FilledCombobox(ref this.tbSheet, this.tbXslPath.Text);
                Cursor.Current = Cursors.Arrow;
            }
        }
        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {
            object[] array = e.Argument as object[];
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + array[0].ToString() + ";Extended Properties='Excel 12.0;HDR=No;'";
            bool flag = false;

            using (SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud))
            {
                sqlConnection.Open();
                using (OleDbConnection oleDbConnection = new OleDbConnection(connectionString))
                {
                    try
                    {
                        oleDbConnection.Open();
                        OleDbCommand oleDbCommand = new OleDbCommand("select * from [" + array[1].ToString() + "$]", oleDbConnection);
                        int num = 1;
                        int num2 = int.Parse(new OleDbCommand("select COUNT(*) from [" + array[1].ToString() + "$]", oleDbConnection).ExecuteScalar().ToString());
                        using (OleDbDataReader oleDbDataReader = oleDbCommand.ExecuteReader())
                        {
                            while (oleDbDataReader.Read())
                            {
                                if (oleDbDataReader[0].ToString() != string.Empty && flag)
                                {
                                    string text = oleDbDataReader[6].ToString();
                                    string text2 = text.Substring(0, 6);
                                    string text3 = (float.Parse(oleDbDataReader[10].ToString()) / 100f).ToString().Replace(",", ".");
                                    string text4 = "INSERT INTO T_FRAUD VALUES (@merchant,";
                                    text4 += "@city,";
                                    text4 += "@state,";
                                    text4 += "@mcc,";
                                    text4 += "@fraud_type,";
                                    text4 += "@amount,";
                                    text4 += "@auth_date,";
                                    text4 += "@card_num,";
                                    text4 += "@pos_entry_mode,";
                                    text4 += "@arn,";
                                    text4 += "@card_bin,";
                                    text4 += "(select top(1) COUNTRY from T_BINS where bin=@card_bin),";
                                    text4 += "(select case when (select top(1) bank from t_bins where bin=@card_bin AND BANK<>'UNKNOWN') like 'banca nazionale del lavoro%' then 1 else 0 end),";
                                    text4 += "'MC')";
                                    SqlCommand sqlCommand = new SqlCommand(text4, sqlConnection);
                                    sqlCommand.Parameters.AddWithValue("@merchant", oleDbDataReader[17]);
                                    sqlCommand.Parameters.AddWithValue("@city", oleDbDataReader[18]);
                                    sqlCommand.Parameters.AddWithValue("@state", oleDbDataReader[21]);
                                    sqlCommand.Parameters.AddWithValue("@mcc", oleDbDataReader[24]);
                                    sqlCommand.Parameters.AddWithValue("@fraud_type", oleDbDataReader[4]);
                                    sqlCommand.Parameters.AddWithValue("@amount", text3);
                                    sqlCommand.Parameters.AddWithValue("@auth_date", oleDbDataReader[3].ToString().Substring(6, 4) + oleDbDataReader[3].ToString().Substring(3, 2) + oleDbDataReader[3].ToString().Substring(0, 2));
                                    sqlCommand.Parameters.AddWithValue("@card_num", text);
                                    sqlCommand.Parameters.AddWithValue("@pos_entry_mode", oleDbDataReader[26]);
                                    sqlCommand.Parameters.AddWithValue("@arn", oleDbDataReader[31]);
                                    sqlCommand.Parameters.AddWithValue("@card_bin", text2);
                                    if (sqlCommand.ExecuteNonQuery() > 0)
                                    {
                                        MyConsole.enqueue(string.Concat(new object[]
										{
											"Insert fraud:bin=",
											text2,
											" amount=",
											text3,
											" city=",
											oleDbDataReader[18]
										}));
                                    }

                                }
                                if (!flag && oleDbDataReader[0].ToString() == "Acq")
                                {
                                    flag = true;
                                }

                                this.myworker.ReportProgress(num * 100 / num2);
                                num++;
                            }
                            MyConsole.enqueue("END OF IMPORT: File " + array[0].ToString() + " imported");
                            MyMessage.showMessage("END OF IMPORT: File " + array[0].ToString() + " imported");

                            Cursor.Current = Cursors.WaitCursor;
                            utilities.getBinFromWeb();
                            Cursor.Current = Cursors.Default;
                        }
                    }
                    catch (Exception ex)
                    {
                        sqlConnection.Close();
                        oleDbConnection.Close();
                        MyMessage.showMessage("ERROR\r\n" + ex.Message, MessageBoxIcon.Hand);
                        MyLogger.WriteLog(this.Text + " ERROR: " + ex.Message);
                        MyConsole.enqueue("ERROR: " + ex.Message);
                    }
                }
            }
        }
        private void myworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.myprogressbar.Value = e.ProgressPercentage;
        }
        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            Cursor.Current = Cursors.Arrow;
            /*if (this.myprogressbar.Value == 100)
            {
                MyMessage.showMessage("End of program\r\nFile " + tbXslPath.Text + " imported", MessageBoxIcon.Asterisk);
            }
            else
            {
                MyMessage.showMessage("Import has been stopped", MessageBoxIcon.Hand);
            }*/

            if (closeWin)
            {
               /* viewConsole.Close();
                viewConsole = null;*/
                MyConsole.mostraCONSOLE.Hide();
            }
        }
    }
}
