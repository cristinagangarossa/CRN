﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Globalization;

namespace FraudManager
{
    public partial class FraudManager : Form
    {
        private string myreportType;
        private ArrayList floatColumns = new ArrayList();

        public FraudManager(string reportType)
        {
            InitializeComponent();
            this.myreportType = reportType;
            this.Text = this.Text + ": " + reportType.Replace("_", " "); 

        }

        private void GetData(string selectCommand)
        {
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommand, MyConnection.con_string_db_fraud);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
                DataTable dataTable = new DataTable();
                dataTable.Locale = CultureInfo.InvariantCulture;
                sqlDataAdapter.Fill(dataTable);
                this.bindingSource1.DataSource = dataTable;
                this.dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("ERROR\r\n" + ex.Message, MessageBoxIcon.Hand);
                MyConsole.enqueue("ERROR: " + ex.Message);
                MyLogger.WriteLog(this.Text + " " + ex.Message);
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = this.bindingSource1;
            string text = "";
            string text2 = this.dateTimePicker1.Value.ToString("yyyyMMdd");
            string text3 = this.dateTimePicker2.Value.ToString("yyyyMMdd");
            if (this.myreportType == "FRAUD_TYPE")
            {
                this.floatColumns.Add(1);
                this.floatColumns.Add(2);
                this.floatColumns.Add(5);
                text += "SELECT  FRAUD_TYPE , ";
                text += "        SUM(AMOUNT) AS AMOUNT , ";
                text += "        ( SUM(AMOUNT) * 100 / ( SELECT   SUM(AMOUNT) ";
                text += "                                   FROM     T_FRAUD ";
                text = text + "                                   WHERE    AUTH_DATE >= '" + text2 + "'";
                text = text + "                                            AND AUTH_DATE <= '" + text3 + "'";
                text += "                                 ) ) AS AMOUNT_PERCENTAGE , ";
                text += "        COUNT(ID_FRAUD) AS 'COUNT' , ";
                text += "        ( COUNT(ID_FRAUD) * 100 / ( SELECT   COUNT(*) ";
                text += "                                       FROM     T_FRAUD ";
                text = text + "                                   WHERE    AUTH_DATE >= '" + text2 + "'";
                text = text + "                                            AND AUTH_DATE <= '" + text3 + "'";
                text += "                                     ) ) AS COUNT_PERCENTAGE , ";
                text += "        AVG(AMOUNT) AS AVG_TRX_AMOUNT ";
                text += "FROM    [DBO].[T_FRAUD] ";
                text = text + "WHERE    AUTH_DATE >= '" + text2 + "'";
                text = text + "         AND AUTH_DATE <= '" + text3 + "'";
                text += "GROUP BY FRAUD_TYPE ";
                text += "ORDER BY FRAUD_TYPE";
            }
            if (this.myreportType == "MCC")
            {
                this.floatColumns.Add(1);
                this.floatColumns.Add(2);
                this.floatColumns.Add(5);
                text += "SELECT  MCC , ";
                text += "        SUM(AMOUNT) AS AMOUNT , ";
                text += "        ( SUM(AMOUNT) * 100 / ( SELECT   SUM(AMOUNT) ";
                text += "                                   FROM     T_FRAUD ";
                text = text + "                                   WHERE    AUTH_DATE >= '" + text2 + "'";
                text = text + "                                            AND AUTH_DATE <= '" + text3 + "'";
                text += "                                 ) ) AS AMOUNT_PERCENTAGE , ";
                text += "        COUNT(ID_FRAUD) AS 'COUNT' , ";
                text += "        ( COUNT(ID_FRAUD) * 100 / ( SELECT   COUNT(*) ";
                text += "                                       FROM     T_FRAUD ";
                text = text + "                                   WHERE    AUTH_DATE >= '" + text2 + "'";
                text = text + "                                            AND AUTH_DATE <= '" + text3 + "'";
                text += "                                     ) ) AS COUNT_PERCENTAGE , ";
                text += "        AVG(AMOUNT) AS AVG_TRX_AMOUNT ";
                text += "FROM    [DBO].[T_FRAUD] ";
                text = text + "                                   WHERE    AUTH_DATE >= '" + text2 + "'";
                text = text + "                                            AND AUTH_DATE <= '" + text3 + "'";
                text += "GROUP BY MCC ";
                text += "ORDER BY MCC";
            }
            if (this.myreportType == "ISSUER_STATE")
            {
                this.floatColumns.Add(2);
                this.floatColumns.Add(3);
                this.floatColumns.Add(6);
                text += "SELECT  ISSUER_STATE, DESCRIPTION, ";
                text += "        SUM(AMOUNT) AS AMOUNT , ";
                text += "        ( SUM(AMOUNT) * 100 / ( SELECT   SUM(AMOUNT) ";
                text += "                                   FROM     T_FRAUD ";
                text = text + "                                   WHERE    AUTH_DATE >= '" + text2 + "'";
                text = text + "                                            AND AUTH_DATE <= '" + text3 + "'";
                text += "                                 ) ) AS AMOUNT_PERCENTAGE , ";
                text += "        COUNT(ID_FRAUD) AS 'COUNT' , ";
                text += "        ( COUNT(ID_FRAUD) * 100 / ( SELECT   COUNT(*) ";
                text += "                                       FROM     T_FRAUD ";
                text = text + "                                   WHERE    AUTH_DATE >= '" + text2 + "'";
                text = text + "                                            AND AUTH_DATE <= '" + text3 + "'";
                text += "                                     ) ) AS COUNT_PERCENTAGE , ";
                text += "        AVG(AMOUNT) AS AVG_TRX_AMOUNT ";
                text += "FROM    [DBO].[T_FRAUD] JOIN T_STATE ON ISSUER_STATE=CODE3 ";
                text = text + "                                   WHERE    AUTH_DATE >= '" + text2 + "'";
                text = text + "                                            AND AUTH_DATE <= '" + text3 + "'";
                text += "GROUP BY ISSUER_STATE, DESCRIPTION ";
                text += "ORDER BY DESCRIPTION";
            }
            if (this.myreportType == "GROSS_FRAUD")
            {
                this.floatColumns.Add(1);
                string text4 = text;
                text = string.Concat(new string[]
				{
					text4,
					"SELECT 'GROSS FRAUD AMOUNT' AS DESCRIPTION, SUM(AMOUNT) AS VALUE FROM T_FRAUD WHERE AUTH_DATE >= '",
					text2,
					"' AND AUTH_DATE <= '",
					text3,
					"' "
				});
                text += "UNION ALL ";
                text4 = text;
                text = string.Concat(new string[]
				{
					text4,
					"SELECT 'ON US', SUM(AMOUNT) FROM T_FRAUD WHERE BNL=1 AND AUTH_DATE >= '",
					text2,
					"' AND AUTH_DATE <= '",
					text3,
					"' "
				});
                text += "UNION ALL ";
                text4 = text;
                text = string.Concat(new string[]
				{
					text4,
					"SELECT 'DOMESTIC', SUM(AMOUNT) FROM T_FRAUD WHERE BNL=0 AND ISSUER_STATE='ITA' AND AUTH_DATE >= '",
					text2,
					"' AND AUTH_DATE <= '",
					text3,
					"' "
				});
                text += "UNION ALL ";
                text4 = text;
                text = string.Concat(new string[]
				{
					text4,
					"SELECT 'INTERNATIONAL', SUM(AMOUNT) FROM T_FRAUD WHERE ISSUER_STATE<>'ITA' AND AUTH_DATE >= '",
					text2,
					"' AND AUTH_DATE <= '",
					text3,
					"' "
				});
                text += "UNION ALL ";
                text4 = text;
                text = string.Concat(new string[]
				{
					text4,
					"SELECT 'CNP W. GROSS FRAUD', SUM(AMOUNT) FROM T_FRAUD WHERE FRAUD_TYPE=6 AND AUTH_DATE >= '",
					text2,
					"' AND AUTH_DATE <= '",
					text3,
					"' "
				});
                text += "UNION ALL ";
                text4 = text;
                text = string.Concat(new string[]
				{
					text4,
					"SELECT 'CNP %', (SUM(AMOUNT)*100/(SELECT SUM(AMOUNT)FROM T_FRAUD)) FROM T_FRAUD WHERE FRAUD_TYPE=6 AND AUTH_DATE >= '",
					text2,
					"' AND AUTH_DATE <= '",
					text3,
					"' "
				});
                text += "UNION ALL ";
                text4 = text;
                text = string.Concat(new string[]
				{
					text4,
					"SELECT 'MOTO W. CNP', SUM(AMOUNT) FROM T_FRAUD WHERE FRAUD_TYPE=6 AND POS_ENTRY_MODE<>1 AND AUTH_DATE >= '",
					text2,
					"' AND AUTH_DATE <= '",
					text3,
					"' "
				});
            }
            this.GetData(text);
        }
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            try
            {
                utilities.exportToExcel(this.dataGridView1, this.floatColumns);
                MyMessage.showMessage("File created", MessageBoxIcon.Asterisk);
                MyLogger.WriteLog(this.Text + ": CSV created");
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("ERROR:\r\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog("ERROR: " + ex.Message);
            }
        }
    }
}
