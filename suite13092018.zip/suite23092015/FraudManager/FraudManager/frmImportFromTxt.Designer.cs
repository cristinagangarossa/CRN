﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace FraudManager
{
    partial class frmImportFromTxt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private TextBox tbXslPath;
        private Button button3;
        private Button button1;
        private GroupBox import_txt;
        private BackgroundWorker myworker;
        private StatusStrip statusStrip1;
        private ToolStripProgressBar myprogressbar;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbXslPath = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.import_txt = new System.Windows.Forms.GroupBox();
            this.myworker = new System.ComponentModel.BackgroundWorker();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.myprogressbar = new System.Windows.Forms.ToolStripProgressBar();
            this.import_txt.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbXslPath
            // 
            this.tbXslPath.Location = new System.Drawing.Point(86, 26);
            this.tbXslPath.Name = "tbXslPath";
            this.tbXslPath.ReadOnly = true;
            this.tbXslPath.Size = new System.Drawing.Size(230, 23);
            this.tbXslPath.TabIndex = 16;
            this.tbXslPath.Tag = "File Excel";
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.Location = new System.Drawing.Point(11, 24);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.button3.Size = new System.Drawing.Size(69, 25);
            this.button3.TabIndex = 14;
            this.button3.Text = "Browse..";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(119, 63);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.button1.Size = new System.Drawing.Size(89, 27);
            this.button1.TabIndex = 18;
            this.button1.Text = "Start import";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // import_txt
            // 
            this.import_txt.Controls.Add(this.button3);
            this.import_txt.Controls.Add(this.button1);
            this.import_txt.Controls.Add(this.tbXslPath);
            this.import_txt.Location = new System.Drawing.Point(8, 12);
            this.import_txt.Name = "import_txt";
            this.import_txt.Size = new System.Drawing.Size(326, 99);
            this.import_txt.TabIndex = 19;
            this.import_txt.TabStop = false;
            this.import_txt.Text = "Source file";
            // 
            // myworker
            // 
            this.myworker.WorkerReportsProgress = true;
            this.myworker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.myworker_DoWork);
            this.myworker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.myworker_ProgressChanged);
            this.myworker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.myworker_RunWorkerCompleted);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.myprogressbar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 128);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(342, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 30;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // myprogressbar
            // 
            this.myprogressbar.Name = "myprogressbar";
            this.myprogressbar.Size = new System.Drawing.Size(335, 16);
            // 
            // frmImportFromTxt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 150);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.import_txt);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmImportFromTxt";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Fraud Manager - Import from TXT";
            this.import_txt.ResumeLayout(false);
            this.import_txt.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}