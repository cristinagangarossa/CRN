﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Data.SqlClient;
using System.IO;

namespace FraudManager
{
    public partial class frmImportFromTxt : Form
    {
        private bool showMessage = true;
        //viewConsole viewConsole;
        bool closeWin = false;
        public frmImportFromTxt()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.myprogressbar.Value = 0;
            if (MyControl.checkControl(this.import_txt))
            {
                base.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                this.myprogressbar.Style = ProgressBarStyle.Marquee;
                MyLogger.WriteLog(this.Text + ": start import");
                this.myworker.RunWorkerAsync(new object[]
				{
					this.tbXslPath.Text
				});

                if (!MyConsole.mostraCONSOLE.Visible)
                {
                    MyConsole.mostraCONSOLE.Show();
                    closeWin = true;
                }

                /*if (viewConsole == null)
                {
                    viewConsole = new viewConsole();
                    viewConsole.Show();
                    closeWin = true;
                }*/
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                this.tbXslPath.Text = openFileDialog.FileName;
            }
        }
        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {
            object[] array = e.Argument as object[];

            using (SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud))
            {
                try
                {
                    sqlConnection.Open();
                    int num = 0;
                    StreamReader streamReader = new StreamReader(array[0].ToString());
                    string text;
                    while ((text = streamReader.ReadLine()) != null)
                    {
                        bool flag = false;
                        if (text.Contains("CTRY MCC TYPE"))
                        {
                            streamReader.ReadLine();
                            streamReader.ReadLine();
                            streamReader.ReadLine();
                            text = streamReader.ReadLine();
                            while (!flag)
                            {
                                if (text.Length > 0)
                                {
                                    string value = text.Substring(0, 25).Trim();
                                    string text2 = text.Substring(25, 13).Trim();
                                    string value2 = text.Substring(39, 3).Trim();
                                    string value3 = text.Substring(43, 4).Trim();
                                    string value4 = text.Substring(48, 1).Trim();
                                    string text3 = (float.Parse(text.Replace(",", "").Substring(50, 16).Trim()) / 100f).ToString().Replace(",", ".");
                                    string value5 = "20" + text.Substring(80, 2) + text.Substring(74, 2) + text.Substring(77, 2);
                                    string value6 = text.Substring(83, 16).Trim();
                                    string value7 = text.Substring(129, 2).Trim();
                                    string value8 = text.Substring(105, 23).Trim();
                                    string text4 = text.Substring(67, 6).Trim();
                                    string text5 = "INSERT INTO T_FRAUD VALUES (@merchant,";
                                    text5 += "@city,";
                                    text5 += "(select top(1) CODE3 from T_STATE WHERE CODE2=@state),";
                                    text5 += "@mcc,";
                                    text5 += "@fraud_type,";
                                    text5 += "@amount,";
                                    text5 += "@auth_date,";
                                    text5 += "@card_number,";
                                    text5 += "@pos_entry_mode,";
                                    text5 += "@arn,";
                                    text5 += "@issuer_bin,";
                                    text5 += "(select top(1) COUNTRY from T_BINS where bin=@issuer_bin),";
                                    text5 += "(select case when (select top(1) bank from t_bins where bin=@issuer_bin AND BANK<>'UNKNOWN') like 'banca nazionale del lavoro%' then 1 else 0 end),";
                                    text5 += "'VISA')";
                                    SqlCommand sqlCommand = new SqlCommand(text5, sqlConnection);
                                    sqlCommand.Parameters.AddWithValue("@merchant", value);
                                    sqlCommand.Parameters.AddWithValue("@city", text2);
                                    sqlCommand.Parameters.AddWithValue("@state", value2);
                                    sqlCommand.Parameters.AddWithValue("@mcc", value3);
                                    sqlCommand.Parameters.AddWithValue("@fraud_type", value4);
                                    sqlCommand.Parameters.AddWithValue("@amount", text3);
                                    sqlCommand.Parameters.AddWithValue("@auth_date", value5);
                                    sqlCommand.Parameters.AddWithValue("@card_number", value6);
                                    sqlCommand.Parameters.AddWithValue("@pos_entry_mode", value7);
                                    sqlCommand.Parameters.AddWithValue("@arn", value8);
                                    sqlCommand.Parameters.AddWithValue("@issuer_bin", text4);
                                    if (sqlCommand.ExecuteNonQuery() > 0)
                                    {
                                        MyConsole.enqueue(string.Concat(new string[]
										{
											"Insert fraud:bin=",
											text4,
											" amount=",
											text3,
											" city=",
											text2
										}));
                                    }
                                }
                                text = streamReader.ReadLine();
                                if (text.Contains("** VISA CONFIDENTIAL **") || text.Contains("----------------"))
                                {
                                    flag = true;
                                }
                            }
                        }
                        num++;
                    }
                    MyConsole.enqueue("END OF PROGRAM: File " + array[0].ToString() + " imported");
                    MyMessage.showMessage("End of program\r\nFile " + tbXslPath.Text + " imported", MessageBoxIcon.Information);
                   
                        Cursor.Current = Cursors.WaitCursor;
                        utilities.getBinFromWeb();
                        Cursor.Current = Cursors.Default;
                  
                    streamReader.Close();
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("ERROR\r\n" + ex.Message, MessageBoxIcon.Hand);
                    MyLogger.WriteLog(this.Text + " ERROR: " + ex.Message);
                    this.showMessage = false;
                    sqlConnection.Close();
                }
            }
        }

        private void myworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.myprogressbar.Value = e.ProgressPercentage;
        }

        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            this.myprogressbar.Style = ProgressBarStyle.Blocks;
            Cursor.Current = Cursors.Arrow;
          
            if (closeWin)
            {
                //viewConsole.Close();
                //viewConsole = null;
                MyConsole.mostraCONSOLE.Hide();
            }
        }
    }
}
