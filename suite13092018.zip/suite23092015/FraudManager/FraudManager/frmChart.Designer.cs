﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
namespace FraudManager
{
    partial class frmChart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private Chart chart1;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private Label label1;
        private Label label2;
        private Button button3;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ChartArea chartArea = new ChartArea();
            Legend legend = new Legend();
            this.chart1 = new Chart();
            this.dateTimePicker1 = new DateTimePicker();
            this.dateTimePicker2 = new DateTimePicker();
            this.label1 = new Label();
            this.label2 = new Label();
            this.button3 = new Button();
            ((ISupportInitialize)this.chart1).BeginInit();
            base.SuspendLayout();
            this.chart1.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
            this.chart1.BackColor = Color.Empty;
            this.chart1.BorderlineColor = Color.Empty;
            chartArea.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea);
            legend.Name = "Legend1";
            this.chart1.Legends.Add(legend);
            this.chart1.Location = new Point(11, 54);
            this.chart1.Name = "chart1";
            this.chart1.Palette = ChartColorPalette.None;
            this.chart1.Size = new Size(890, 471);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "Fraud amount x month";
            this.dateTimePicker1.Checked = false;
            this.dateTimePicker1.Format = DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new Point(52, 16);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new Size(110, 23);
            this.dateTimePicker1.TabIndex = 1;
            this.dateTimePicker2.Checked = false;
            this.dateTimePicker2.Format = DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new Point(211, 16);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new Size(110, 23);
            this.dateTimePicker2.TabIndex = 2;
            this.label1.AutoSize = true;
            this.label1.Location = new Point(186, 20);
            this.label1.Name = "label1";
            this.label1.Size = new Size(19, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "To";
            this.label2.AutoSize = true;
            this.label2.Location = new Point(11, 20);
            this.label2.Name = "label2";
            this.label2.Size = new Size(35, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "From";
            this.button3.AutoSize = true;
            this.button3.BackColor = SystemColors.Control;
            this.button3.Location = new Point(334, 15);
            this.button3.Name = "button3";
            this.button3.Padding = new Padding(3, 0, 3, 0);
            this.button3.Size = new Size(81, 25);
            this.button3.TabIndex = 3;
            this.button3.Text = "Load chart";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new EventHandler(this.button3_Click);
            base.AutoScaleDimensions = new SizeF(7f, 15f);
            base.ClientSize = new Size(913, 537);
            base.Controls.Add(this.button3);
            base.Controls.Add(this.label2);
            base.Controls.Add(this.label1);
            base.Controls.Add(this.dateTimePicker2);
            base.Controls.Add(this.dateTimePicker1);
            base.Controls.Add(this.chart1);
            this.Font = new Font("Calibri", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
            base.Name = "frmChart";
            base.ShowIcon = false;
            base.ShowInTaskbar = false;
            this.Text = "Fraud Manager - Chart";
            ((ISupportInitialize)this.chart1).EndInit();
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        #endregion
    }
}