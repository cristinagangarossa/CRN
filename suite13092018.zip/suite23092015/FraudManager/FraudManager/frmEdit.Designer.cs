﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace FraudManager
{
    partial class frmEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private TextBox txtCity;
        private ComboBox cbState;
        private ComboBox cbFraudType;
        private ComboBox cbMcc;
        private TextBox txtAmount;
        private ComboBox cbPosEntryMode;
        private TextBox txtCardNumber;
        private TextBox txtBin;
        private TextBox txtARN;
        private ComboBox cbIssuerState;
        private TextBox txtMerchantName;
        private DateTimePicker dtAuth;
        private Button btSave;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private GroupBox groupBox2;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private GroupBox groupBox1;
        private CheckBox cbIsBnl;
        private Button btCancel;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCity = new System.Windows.Forms.TextBox();
            this.cbState = new System.Windows.Forms.ComboBox();
            this.cbFraudType = new System.Windows.Forms.ComboBox();
            this.cbMcc = new System.Windows.Forms.ComboBox();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.cbPosEntryMode = new System.Windows.Forms.ComboBox();
            this.txtCardNumber = new System.Windows.Forms.TextBox();
            this.txtBin = new System.Windows.Forms.TextBox();
            this.txtARN = new System.Windows.Forms.TextBox();
            this.cbIssuerState = new System.Windows.Forms.ComboBox();
            this.txtMerchantName = new System.Windows.Forms.TextBox();
            this.dtAuth = new System.Windows.Forms.DateTimePicker();
            this.btSave = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbIsBnl = new System.Windows.Forms.CheckBox();
            this.btCancel = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCity
            // 
            this.txtCity.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCity.Location = new System.Drawing.Point(531, 19);
            this.txtCity.MaxLength = 30;
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(150, 23);
            this.txtCity.TabIndex = 3;
            // 
            // cbState
            // 
            this.cbState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbState.Location = new System.Drawing.Point(259, 48);
            this.cbState.Name = "cbState";
            this.cbState.Size = new System.Drawing.Size(150, 23);
            this.cbState.TabIndex = 4;
            // 
            // cbFraudType
            // 
            this.cbFraudType.Location = new System.Drawing.Point(259, 79);
            this.cbFraudType.Name = "cbFraudType";
            this.cbFraudType.Size = new System.Drawing.Size(150, 23);
            this.cbFraudType.TabIndex = 6;
            // 
            // cbMcc
            // 
            this.cbMcc.Location = new System.Drawing.Point(531, 49);
            this.cbMcc.Name = "cbMcc";
            this.cbMcc.Size = new System.Drawing.Size(150, 23);
            this.cbMcc.TabIndex = 5;
            // 
            // txtAmount
            // 
            this.txtAmount.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAmount.Location = new System.Drawing.Point(15, 26);
            this.txtAmount.MaxLength = 14;
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(110, 23);
            this.txtAmount.TabIndex = 1;
            // 
            // cbPosEntryMode
            // 
            this.cbPosEntryMode.Location = new System.Drawing.Point(259, 110);
            this.cbPosEntryMode.Name = "cbPosEntryMode";
            this.cbPosEntryMode.Size = new System.Drawing.Size(150, 23);
            this.cbPosEntryMode.TabIndex = 8;
            // 
            // txtCardNumber
            // 
            this.txtCardNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCardNumber.Location = new System.Drawing.Point(531, 81);
            this.txtCardNumber.MaxLength = 16;
            this.txtCardNumber.Name = "txtCardNumber";
            this.txtCardNumber.Size = new System.Drawing.Size(150, 23);
            this.txtCardNumber.TabIndex = 7;
            // 
            // txtBin
            // 
            this.txtBin.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBin.Location = new System.Drawing.Point(259, 141);
            this.txtBin.MaxLength = 6;
            this.txtBin.Name = "txtBin";
            this.txtBin.Size = new System.Drawing.Size(150, 23);
            this.txtBin.TabIndex = 10;
            // 
            // txtARN
            // 
            this.txtARN.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtARN.Location = new System.Drawing.Point(531, 112);
            this.txtARN.MaxLength = 23;
            this.txtARN.Name = "txtARN";
            this.txtARN.Size = new System.Drawing.Size(150, 23);
            this.txtARN.TabIndex = 9;
            // 
            // cbIssuerState
            // 
            this.cbIssuerState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbIssuerState.Location = new System.Drawing.Point(531, 142);
            this.cbIssuerState.Name = "cbIssuerState";
            this.cbIssuerState.Size = new System.Drawing.Size(150, 23);
            this.cbIssuerState.TabIndex = 11;
            // 
            // txtMerchantName
            // 
            this.txtMerchantName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMerchantName.Location = new System.Drawing.Point(259, 19);
            this.txtMerchantName.MaxLength = 60;
            this.txtMerchantName.Name = "txtMerchantName";
            this.txtMerchantName.Size = new System.Drawing.Size(150, 23);
            this.txtMerchantName.TabIndex = 2;
            // 
            // dtAuth
            // 
            this.dtAuth.Checked = false;
            this.dtAuth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtAuth.Location = new System.Drawing.Point(15, 26);
            this.dtAuth.Name = "dtAuth";
            this.dtAuth.Size = new System.Drawing.Size(110, 23);
            this.dtAuth.TabIndex = 0;
            // 
            // btSave
            // 
            this.btSave.AutoSize = true;
            this.btSave.BackColor = System.Drawing.SystemColors.Control;
            this.btSave.Location = new System.Drawing.Point(273, 205);
            this.btSave.Name = "btSave";
            this.btSave.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btSave.Size = new System.Drawing.Size(56, 27);
            this.btSave.TabIndex = 14;
            this.btSave.Text = "Save";
            this.btSave.UseVisualStyleBackColor = true;
            this.btSave.Click += new System.EventHandler(this.btSave_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(453, 146);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 15);
            this.label14.TabIndex = 94;
            this.label14.Text = "Issuer State";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(223, 146);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(26, 15);
            this.label13.TabIndex = 93;
            this.label13.Text = "BIN";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(490, 114);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 15);
            this.label12.TabIndex = 92;
            this.label12.Text = "ARN";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(177, 115);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 15);
            this.label11.TabIndex = 91;
            this.label11.Text = "Pos entry m.";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(472, 83);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 15);
            this.label10.TabIndex = 90;
            this.label10.Text = "Card no.";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtAmount);
            this.groupBox2.Location = new System.Drawing.Point(12, 99);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(140, 65);
            this.groupBox2.TabIndex = 85;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Amount";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(185, 83);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 15);
            this.label7.TabIndex = 89;
            this.label7.Text = "Fraud type";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(489, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 15);
            this.label6.TabIndex = 88;
            this.label6.Text = "MCC";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(212, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 15);
            this.label5.TabIndex = 87;
            this.label5.Text = "State";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(496, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 15);
            this.label4.TabIndex = 86;
            this.label4.Text = "City";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(191, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 15);
            this.label3.TabIndex = 84;
            this.label3.Text = "Merchant";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dtAuth);
            this.groupBox1.Location = new System.Drawing.Point(12, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(140, 65);
            this.groupBox1.TabIndex = 83;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Authorization date";
            // 
            // cbIsBnl
            // 
            this.cbIsBnl.AutoSize = true;
            this.cbIsBnl.Location = new System.Drawing.Point(259, 171);
            this.cbIsBnl.Name = "cbIsBnl";
            this.cbIsBnl.Size = new System.Drawing.Size(65, 19);
            this.cbIsBnl.TabIndex = 12;
            this.cbIsBnl.Text = "On BNL";
            this.cbIsBnl.UseVisualStyleBackColor = true;
            // 
            // btCancel
            // 
            this.btCancel.AutoSize = true;
            this.btCancel.BackColor = System.Drawing.SystemColors.Control;
            this.btCancel.Location = new System.Drawing.Point(358, 205);
            this.btCancel.Name = "btCancel";
            this.btCancel.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btCancel.Size = new System.Drawing.Size(65, 27);
            this.btCancel.TabIndex = 13;
            this.btCancel.Text = "Cancel";
            this.btCancel.UseVisualStyleBackColor = true;
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click);
            // 
            // frmEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(697, 240);
            this.Controls.Add(this.btCancel);
            this.Controls.Add(this.btSave);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbIsBnl);
            this.Controls.Add(this.txtMerchantName);
            this.Controls.Add(this.cbIssuerState);
            this.Controls.Add(this.txtBin);
            this.Controls.Add(this.txtARN);
            this.Controls.Add(this.cbPosEntryMode);
            this.Controls.Add(this.txtCardNumber);
            this.Controls.Add(this.cbFraudType);
            this.Controls.Add(this.cbMcc);
            this.Controls.Add(this.cbState);
            this.Controls.Add(this.txtCity);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmEdit";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Fraud Manager - Edit fraud";
            this.Load += new System.EventHandler(this.frmEdit_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}