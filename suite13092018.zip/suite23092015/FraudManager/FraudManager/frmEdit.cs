﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Data.SqlClient;

namespace FraudManager
{
    public partial class frmEdit : Form
    {
        public string ID;
        public string returnQuery;
        private frmBrowse myOwner;
        private string _form_mode;

        public frmEdit(string form_mode, string selectedID = "", string query = "", frmBrowse owner = null)
        {
            this.myOwner = owner;
            this.ID = selectedID;
            this.returnQuery = query;
            this._form_mode = form_mode;
            InitializeComponent();
        }

        private void frmEdit_Load(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                utilities.fillDropDownList("SELECT CODE3, DESCRIPTION FROM T_STATE ORDER BY DESCRIPTION", this.cbState, "CODE3", "DESCRIPTION", false);
                utilities.fillDropDownList("SELECT DISTINCT MCC FROM T_FRAUD ORDER BY MCC", this.cbMcc, "MCC", "MCC", false);
                utilities.fillDropDownList("SELECT DISTINCT FRAUD_TYPE FROM T_FRAUD ORDER BY FRAUD_TYPE", this.cbFraudType, "FRAUD_TYPE", "FRAUD_TYPE", false);
                utilities.fillDropDownList("SELECT DISTINCT POS_ENTRY_MODE FROM T_FRAUD ORDER BY POS_ENTRY_MODE", this.cbPosEntryMode, "POS_ENTRY_MODE", "POS_ENTRY_MODE", false);
                utilities.fillDropDownList("SELECT CODE3, DESCRIPTION FROM T_STATE ORDER BY DESCRIPTION", this.cbIssuerState, "CODE3", "DESCRIPTION", false);
                if (this.ID != null && this._form_mode == "EDIT")
                {
                    string cmdText = "SELECT [MERCHANT_NAME],[CITY],[STATE],[MCC],[FRAUD_TYPE],[AMOUNT],[AUTH_DATE],[CARD_NUMBER],[POS_ENTRY_MODE],[ARN],[BIN],[ISSUER_STATE],[BNL] FROM [dbo].[T_FRAUD] WHERE ID_FRAUD=@id";
                    SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud);
                    SqlCommand sqlCommand = new SqlCommand(cmdText, sqlConnection);
                    sqlCommand.Parameters.AddWithValue("@id", this.ID);
                    sqlConnection.Open();
                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                    if (sqlDataReader.Read())
                    {
                        this.txtMerchantName.Text = sqlDataReader[0].ToString();
                        this.txtCity.Text = sqlDataReader[1].ToString();
                        this.cbState.SelectedValue = sqlDataReader[2].ToString();
                        this.cbMcc.SelectedValue = sqlDataReader[3].ToString();
                        this.cbFraudType.SelectedValue = sqlDataReader[4].ToString();
                        this.txtAmount.Text = sqlDataReader[5].ToString();
                        this.dtAuth.Text = sqlDataReader[6].ToString();
                        this.txtCardNumber.Text = sqlDataReader[7].ToString();
                        this.cbPosEntryMode.SelectedValue = sqlDataReader[8].ToString();
                        this.txtARN.Text = sqlDataReader[9].ToString();
                        this.txtBin.Text = sqlDataReader[10].ToString();
                        this.cbIssuerState.SelectedValue = sqlDataReader[11].ToString();
                        if (sqlDataReader[12].ToString().Equals("True"))
                        {
                            this.cbIsBnl.Checked = true;
                        }
                        else
                        {
                            this.cbIsBnl.Checked = false;
                        }
                    }
                    sqlConnection.Close();
                }
            }
            catch (Exception ex)
            {
                MyConsole.enqueue(this.Text + " ERROR: " + ex.Message);
                MyMessage.showMessage("ERROR:\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog(this.Text + " ERROR: " + ex.Message);
            }
            Cursor.Current = Cursors.WaitCursor;
        }
        
        private void btCancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }
        
        private void btSave_Click(object sender, EventArgs e)
        {
            string cmdText = "";
            if (this._form_mode == "EDIT")
            {
                cmdText = "UPDATE T_FRAUD SET MERCHANT_NAME=@merchant, CITY=@city, STATE=@state, MCC=@mcc, FRAUD_TYPE=@fraud_type, AMOUNT=@amount, AUTH_DATE=@auth_date, CARD_NUMBER=@card_number, POS_ENTRY_MODE=@pos_entry_mode, ARN=@arn, BIN=@bin, ISSUER_STATE=@issuer_state, BNL=@bnl WHERE ID_FRAUD=" + this.ID;
            }
            else
            {
                if (this._form_mode == "NEW")
                {
                    cmdText = "INSERT INTO T_FRAUD VALUES (@merchant, @city, @state, @mcc, @fraud_type, @amount, @auth_date, @card_number, @pos_entry_mode, @arn, @bin, @issuer_state, @bnl, 'CUST')";
                }
            }
            SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud);
            try
            {
                
                SqlCommand sqlCommand = new SqlCommand(cmdText, sqlConnection);
                sqlCommand.Parameters.AddWithValue("@merchant", this.txtMerchantName.Text);
                sqlCommand.Parameters.AddWithValue("@city", this.txtCity.Text);
                sqlCommand.Parameters.AddWithValue("@state", this.cbState.SelectedValue);
                sqlCommand.Parameters.AddWithValue("@mcc", this.cbMcc.Text);
                sqlCommand.Parameters.AddWithValue("@fraud_type", this.cbFraudType.Text);
                sqlCommand.Parameters.AddWithValue("@amount", this.txtAmount.Text.Replace(",", "."));
                sqlCommand.Parameters.AddWithValue("@auth_date", this.dtAuth.Value.ToString("yyyyMMdd"));
                sqlCommand.Parameters.AddWithValue("@card_number", this.txtCardNumber.Text);
                sqlCommand.Parameters.AddWithValue("@pos_entry_mode", this.cbPosEntryMode.Text);
                sqlCommand.Parameters.AddWithValue("@arn", this.txtARN.Text);
                sqlCommand.Parameters.AddWithValue("@bin", this.txtBin.Text);
                sqlCommand.Parameters.AddWithValue("@issuer_state", this.cbIssuerState.SelectedValue);
                sqlCommand.Parameters.AddWithValue("@bnl", this.cbIsBnl.Checked ? 1 : 0);
                sqlCommand.Parameters.AddWithValue("@id", this.ID);
                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();
                MyMessage.showMessage("SAVED", MessageBoxIcon.Asterisk);
                if (this._form_mode == "EDIT")
                {
                    this.myOwner.GetData(this.returnQuery);
                }
                base.Close();
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("INVALID DATA\r\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog(this.Text + " INVALID DATA: " + ex.Message);
                MyConsole.enqueue("INVALID DATA: " + ex.Message);
                sqlConnection.Close();
            }
        }
    }
}
