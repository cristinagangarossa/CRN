﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Data.SqlClient;

namespace FraudManager
{
    public partial class frmBinFix : Form
    {
       // viewConsole viewConsole;
        public frmBinFix()
        {
            InitializeComponent();
        }

        private void count_null_state()
        {
            string cmdText = "SELECT COUNT(DISTINCT BIN) FROM T_FRAUD WHERE ISSUER_STATE IS NULL";
            SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud);
            SqlCommand sqlCommand = new SqlCommand(cmdText, sqlConnection);
            try
            {
                sqlConnection.Open();
                int num = (int)sqlCommand.ExecuteScalar();
                this.textBox1.Text = num.ToString();
                if (num > 0)
                {
                    this.button3.Enabled = true;
                }
                else
                {
                    this.button3.Enabled = false;
                }
                sqlConnection.Close();
            }
            catch (Exception)
            {
                sqlConnection.Close();
            }           
        }
        private void frmBinFix_Load(object sender, EventArgs e)
        {
            this.count_null_state();
        }
        private void button3_Click(object sender, EventArgs e)
        {
          /*  viewConsole = (Application.OpenForms["viewConsole"] != null) ? ((viewConsole)Application.OpenForms["csr3112"]) : null;
            if (viewConsole == null)
            {
                viewConsole = new viewConsole();
                viewConsole.Show();
                Cursor.Current = Cursors.WaitCursor;
                utilities.getBinFromWeb();
                this.count_null_state();
                Cursor.Current = Cursors.Default;
                viewConsole.Close();
                viewConsole = null;
            }
            else
            {
                Cursor.Current = Cursors.WaitCursor;
                utilities.getBinFromWeb();
                this.count_null_state();
                Cursor.Current = Cursors.Default;
            }*/

             
            if (!MyConsole.mostraCONSOLE.Visible)
            {
               MyConsole.mostraCONSOLE.Show();
                Cursor.Current = Cursors.WaitCursor;
                utilities.getBinFromWeb();
                this.count_null_state();
                Cursor.Current = Cursors.Default;
              MyConsole.mostraCONSOLE.Hide();
            }
            else
            {
                Cursor.Current = Cursors.WaitCursor;
                utilities.getBinFromWeb();
                this.count_null_state();
                Cursor.Current = Cursors.Default;
            }
        }
    }
}
