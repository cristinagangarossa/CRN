﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Windows.Forms.DataVisualization.Charting;

namespace FraudManager
{
    public partial class frmChart : Form
    {
        public string mychartType;
        public frmChart(string chartType)
        {
            InitializeComponent();
            this.mychartType = chartType;
            this.Text = this.Text + ": " + chartType.Replace("_", " ");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string text = this.dateTimePicker1.Value.ToString("yyyyMMdd");
            string text2 = this.dateTimePicker2.Value.ToString("yyyyMMdd");
            string cmdText = "";
            SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud);
            if (this.mychartType == "GROSS_FRAUD")
            {
                cmdText = string.Concat(new string[]
				{
					"select month(auth_date) fraud_period,sum(amount) total_amount from t_fraud WHERE AUTH_DATE >= '",
					text,
					"' AND AUTH_DATE <= '",
					text2,
					"' group by month(auth_date) order by fraud_period"
				});
            }
            if (this.mychartType == "GROSS_FRAUD_VISA_MC")
            {
                cmdText = string.Concat(new string[]
				{
					"select month(auth_date) fraud_period,sum(case when source='VISA' then amount else 0 end) total_amount_visa,sum(case when source='MC' then amount else 0 end) total_amount_mc from t_fraud WHERE AUTH_DATE >= '",
					text,
					"' AND AUTH_DATE <= '",
					text2,
					"' group by month(auth_date) order by fraud_period"
				});
            }
            if (this.mychartType == "AVERAGE_AMOUNT")
            {
                cmdText = string.Concat(new string[]
				{
					"select year(auth_date) fraud_period,avg(case when source='VISA' then amount end) average_amount_visa,avg(case when source='MC' then amount end) average_amount_mc from t_fraud WHERE AUTH_DATE >= '",
					text,
					"' AND AUTH_DATE <= '",
					text2,
					"' group by year(auth_date) order by fraud_period"
				});
            }
            if (this.mychartType == "AVERAGE_TRANSACTIONS")
            {
                cmdText = string.Concat(new string[]
				{
					"select year(auth_date) fraud_period,count(case when source='VISA' then id_fraud end) count_visa,count(case when source='MC' then id_fraud end) count_mc from t_fraud WHERE AUTH_DATE >= '",
					text,
					"' AND AUTH_DATE <= '",
					text2,
					"' group by year(auth_date) order by fraud_period"
				});
            }
            try
            {
                SqlCommand sqlCommand = new SqlCommand(cmdText, sqlConnection);
                sqlCommand.Connection.Open();
                SqlDataReader dataSource = sqlCommand.ExecuteReader(CommandBehavior.CloseConnection);
                this.chart1.Series.Clear();
                this.chart1.ResetAutoValues();
                this.chart1.DataBindTable(dataSource, "fraud_period");
                sqlConnection.Close();
                foreach (Series current in this.chart1.Series)
                {
                    current.IsValueShownAsLabel = true;
                }
            }
            catch (Exception ee)
            {
                MyMessage.showMessage("Error:\n" + ee.Message);
                MyLogger.WriteLog(this.Text + " Error:\n" + ee.Message);
                MyConsole.enqueue("Error: " + ee.Message);
            }
           
        }
    }
}
