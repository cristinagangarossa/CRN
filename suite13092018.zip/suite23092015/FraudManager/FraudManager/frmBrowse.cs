﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Data.SqlClient;
using System.Globalization;
using System.Collections;

namespace FraudManager
{
    public partial class frmBrowse : Form
    {
        public static string query;
        public frmBrowse()
        {
            InitializeComponent();
        }

        private void frmBrowse_Load(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            utilities.fillDropDownList("SELECT CODE3, DESCRIPTION FROM T_STATE ORDER BY DESCRIPTION", this.cbState, "CODE3", "DESCRIPTION", true);
            utilities.fillDropDownList("SELECT DISTINCT MCC FROM T_FRAUD ORDER BY MCC", this.cbMcc, "MCC", "MCC", true);
            utilities.fillDropDownList("SELECT DISTINCT FRAUD_TYPE FROM T_FRAUD ORDER BY FRAUD_TYPE", this.cbFraudtype, "FRAUD_TYPE", "FRAUD_TYPE", true);
            utilities.fillDropDownList("SELECT DISTINCT POS_ENTRY_MODE FROM T_FRAUD ORDER BY POS_ENTRY_MODE", this.cbPosentry, "POS_ENTRY_MODE", "POS_ENTRY_MODE", true);
            utilities.fillDropDownList("SELECT CODE3, DESCRIPTION FROM T_STATE ORDER BY DESCRIPTION", this.cbIssuerstate, "CODE3", "DESCRIPTION", true);
            Cursor.Current = Cursors.Default;
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (this.panel1.Visible)
            {
                this.panel1.Visible = false;
                this.dataGridView1.Location = new Point(8, 37);
                this.dataGridView1.Size = new Size(this.dataGridView1.Size.Width, this.dataGridView1.Size.Height + 270);
            }
            else
            {
                this.panel1.Visible = true;
                this.dataGridView1.Location = new Point(8, 280);
                this.dataGridView1.Size = new Size(this.dataGridView1.Size.Width, this.dataGridView1.Size.Height - 270);
            }
        }
        public void GetData(string selectCommand)
        {
            try
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommand, MyConnection.con_string_db_fraud);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
                DataTable dataTable = new DataTable();
                dataTable.Locale = CultureInfo.InvariantCulture;
                sqlDataAdapter.Fill(dataTable);
                this.bindingSource1.DataSource = dataTable;
                this.dataGridView1.Columns[0].Visible = false;
                this.dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.DisplayedCells);
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("ERROR\r\n" + ex.Message, MessageBoxIcon.Hand);
                MyConsole.enqueue("ERROR: " + ex.Message);
                MyLogger.WriteLog(this.Text + " ERROR: " + ex.Message);
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                this.dataGridView1.DataSource = this.bindingSource1;
                //frmBrowse.query = "SELECT ID_FRAUD,[MERCHANT_NAME],[CITY],[STATE],[MCC],[FRAUD_TYPE],[AMOUNT],[AUTH_DATE],[CARD_NUMBER],[POS_ENTRY_MODE],[ARN],[BIN],[ISSUER_STATE],[BNL] FROM [dbo].[T_FRAUD] WHERE 1=1 ";
                frmBrowse.query = "SELECT ID_FRAUD,[MERCHANT_NAME],[CITY],[STATE],[MCC],[FRAUD_TYPE],[AMOUNT],[AUTH_DATE],[CARD_NUMBER],[POS_ENTRY_MODE],[ARN],[BIN],[ISSUER_STATE], [DESCRIPTION] as [ISSUER_STATE_DESCRIPTION], [BNL] FROM [dbo].[T_FRAUD] INNER JOIN [dbo].[T_STATE] ON T_STATE.CODE3 = T_FRAUD.ISSUER_STATE WHERE 1=1 ";
                if (this.dateTimePicker1.Checked)
                {
                    frmBrowse.query = frmBrowse.query + "AND AUTH_DATE >= '" + this.dateTimePicker1.Value.ToString("yyyyMMdd") + "' ";
                }
                if (this.dateTimePicker2.Checked)
                {
                    frmBrowse.query = frmBrowse.query + "AND AUTH_DATE <= '" + this.dateTimePicker2.Value.ToString("yyyyMMdd") + "' ";
                }
                if (this.tbMerchant.Text != "")
                {
                    frmBrowse.query = frmBrowse.query + "AND MERCHANT_NAME LIKE '" + this.tbMerchant.Text.Replace("*", "%") + "' ";
                }
                if (this.tbCity.Text != "")
                {
                    frmBrowse.query = frmBrowse.query + "AND CITY LIKE '" + this.tbCity.Text.Replace("*", "%") + "' ";
                }
                if (this.cbState.SelectedIndex > 0)
                {
                    object obj = frmBrowse.query;
                    frmBrowse.query = string.Concat(new object[]
					{
						obj,
						"AND STATE = '",
						this.cbState.SelectedValue,
						"' "
					});
                }
                if (this.cbMcc.SelectedIndex > 0)
                {
                    object obj = frmBrowse.query;
                    frmBrowse.query = string.Concat(new object[]
					{
						obj,
						"AND MCC = '",
						this.cbMcc.SelectedValue,
						"' "
					});
                }
                if (this.cbFraudtype.SelectedIndex > 0)
                {
                    object obj = frmBrowse.query;
                    frmBrowse.query = string.Concat(new object[]
					{
						obj,
						"AND FRAUD_TYPE = '",
						this.cbFraudtype.SelectedValue,
						"' "
					});
                }
                if (this.tbCardno.Text != "")
                {
                    frmBrowse.query = frmBrowse.query + "AND CARD_NUMBER LIKE '" + this.tbCardno.Text.Replace("*", "%") + "' ";
                }
                if (this.cbPosentry.SelectedIndex > 0)
                {
                    object obj = frmBrowse.query;
                    frmBrowse.query = string.Concat(new object[]
					{
						obj,
						"AND POS_ENTRY_MODE = '",
						this.cbPosentry.SelectedValue,
						"' "
					});
                }
                if (this.tbArn.Text != "")
                {
                    frmBrowse.query = frmBrowse.query + "AND ARN LIKE '" + this.tbArn.Text.Replace("*", "%") + "' ";
                }
                if (this.tbBin.Text != "")
                {
                    frmBrowse.query = frmBrowse.query + "AND BIN LIKE '" + this.tbBin.Text.Replace("*", "%") + "' ";
                }
                if (this.cbIssuerstate.SelectedIndex > 0)
                {
                    object obj = frmBrowse.query;
                    frmBrowse.query = string.Concat(new object[]
					{
						obj,
						"AND ISSUER_STATE = '",
						this.cbIssuerstate.SelectedValue,
						"' "
					});
                }
                if (this.tbAmount1.Text != "")
                {
                    frmBrowse.query = frmBrowse.query + "AND AMOUNT >= '" + this.tbAmount1.Text.Replace(",", ".") + "' ";
                }
                if (this.tbAmount2.Text != "")
                {
                    frmBrowse.query = frmBrowse.query + "AND AMOUNT <= '" + this.tbAmount2.Text.Replace(",", ".") + "' ";
                }
                if (this.cbBnl.Checked)
                {
                    frmBrowse.query += "AND BNL=1 ";
                }
                this.GetData(frmBrowse.query);
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("ERROR\r\n" + ex.Message, MessageBoxIcon.Hand);
                MyConsole.enqueue("ERROR: " + ex.Message);
                MyLogger.WriteLog(this.Text + " ERROR: " + ex.Message);
            }
        }
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            ArrayList arrayList = new ArrayList();
            arrayList.Add(6);
            utilities.exportToExcel(this.dataGridView1, arrayList);
        }
        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            frmEdit frmEdit = new frmEdit("EDIT", this.dataGridView1.Rows[this.dataGridView1.SelectedCells[0].RowIndex].Cells[0].Value.ToString(), frmBrowse.query, this);
            frmEdit.Show();
        }
        private void fraudDelete()
        {
            if (MyMessage.askMessage(this.dataGridView1.SelectedRows.Count + " RECORDS WILL BE DELETED\r\nCONFIRM?"))
            {
                Cursor.Current = Cursors.WaitCursor;
                SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud);
                sqlConnection.Open();
                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.Connection = sqlConnection;
                try
                {
                    foreach (DataGridViewRow dataGridViewRow in this.dataGridView1.SelectedRows)
                    {
                        sqlCommand.CommandText = "DELETE FROM T_FRAUD WHERE ID_FRAUD=" + this.dataGridView1.Rows[dataGridViewRow.Index].Cells[0].Value.ToString();
                        sqlCommand.ExecuteNonQuery();
                        this.dataGridView1.Rows.Remove(dataGridViewRow);
                    }
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("UNABLE TO DELETE FRAUD\r\n" + ex.Message, MessageBoxIcon.Hand);
                    MyLogger.WriteLog(this.Text + " UNABLE TO DELETE FRAUD\r\n" + ex.Message);
                    MyConsole.enqueue("UNABLE TO DELETE FRAUD: " + ex.Message);
                }
                sqlConnection.Close();
                Cursor.Current = Cursors.Default;
            }
        }
        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                this.fraudDelete();
            }
        }
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            this.fraudDelete();
        }
    }
}
