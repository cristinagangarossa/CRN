﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Net;
using System.Data;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;



namespace FraudManager
{
    public static class utilities
    {
        public static void exportToExcel(DataGridView myDGV, ArrayList floatColumns, string proposedFilename = "")
        {
            int i;
            SaveFileDialog saveFileDialog = new SaveFileDialog()
            {
                Filter = "Excel File|*.xls",
                FileName = proposedFilename,
                Title = "Export fraud file"
            };
            DialogResult dialogResult = saveFileDialog.ShowDialog();
            if ((saveFileDialog.FileName == "" ? false : dialogResult == DialogResult.OK))
            {
                Cursor.Current = Cursors.WaitCursor;
                Excel.Application variable = new Excel.Application();
                Excel.Workbook variable1 = variable.Workbooks.Add(Missing.Value);
                Excel.Worksheet worksheets = (Excel.Worksheet)((dynamic)variable1.Worksheets[1]);
                variable.DisplayAlerts = false;
                variable.Visible = false;
                try
                {
                    for (i = 1; i < myDGV.Columns.Count; i++)
                    {
                        worksheets.Cells[1, i] = myDGV.Columns[i].Name;
                    }
                    for (i = 0; i <= myDGV.RowCount - 1; i++)
                    {
                        for (int j = 1; j <= myDGV.ColumnCount - 1; j++)
                        {
                            DataGridViewCell item = myDGV[j, i];
                            if (floatColumns.Contains(j))
                            {
                                worksheets.Cells[i + 2, j] = double.Parse(item.Value.ToString());
                            }
                            else if ((item.Value.ToString().EndsWith(" 00:00:00") ? false : !item.Value.ToString().EndsWith(" 0.00.00")))
                            {
                                worksheets.Cells[i + 2, j] = string.Concat("'", item.Value);
                            }
                            else
                            {
                                DateTime dateTime = Convert.ToDateTime(item.Value.ToString().Substring(0, 10));
                                worksheets.Cells[i + 2, j] = dateTime;
                            }
                        }
                    }
                    variable1.SaveAs(saveFileDialog.FileName, Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
                    variable1.Close(true, Missing.Value, Missing.Value);
                    variable.Quit();
                    Cursor.Current = Cursors.Default;
                }
                catch (Exception ee)
                {
                    variable.Quit();
                    Cursor.Current = Cursors.Default;
                    MyConsole.enqueue("Error:\n" + ee.Message);
                    MyLogger.WriteLog("Error:\n" + ee.Message);
                }
            }
        }
        public static void getBinFromWeb()
        {
            string cmdText = "SELECT DISTINCT BIN FROM T_FRAUD WHERE ISSUER_STATE IS NULL ORDER BY BIN";
            SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud);
            SqlCommand sqlCommand = new SqlCommand(cmdText, sqlConnection);
            sqlConnection.Open();
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            if (sqlDataReader.HasRows)
            {
                MyConsole.enqueue("Connecting to BINLIST.NET ... Please wait");
            }
            SqlConnection sqlConnection2 = new SqlConnection(MyConnection.con_string_db_fraud);
            try
            {
                sqlConnection2.Open();
                while (sqlDataReader.Read())
                {
                    CookieContainer cookieContainer = new CookieContainer();
                    string requestUriString = "http://www.binlist.net/csv/" + sqlDataReader["BIN"];
                    HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(requestUriString);
                    httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                    httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                    httpWebRequest.CookieContainer = cookieContainer;
                    httpWebRequest.Method = "GET";
                    httpWebRequest.ContentType = "application/csv";
                    try
                    {
                        HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                        Stream responseStream = httpWebResponse.GetResponseStream();
                        StreamReader streamReader = new StreamReader(responseStream);
                        string[] array = streamReader.ReadLine().Replace("\"", "").Split(new char[]
						{
							','
						});
                        if (array[2].Length > 0)
                        {
                            MyConsole.enqueue(string.Concat(new object[]
							{
								"Insert BIN ",
								sqlDataReader["BIN"],
								": ",
								array[4],
								" (COUNTRY: ",
								array[2],
								") from source BINLIST.NET\r\n"
							}));
                            string cmdText2 = "INSERT INTO T_BINS (BIN,BANK,COUNTRY) VALUES (@bin,@bank,(SELECT CODE3 FROM T_STATE WHERE CODE2=@country)) SELECT @@IDENTITY AS 'Identity'";
                            SqlCommand sqlCommand2 = new SqlCommand(cmdText2, sqlConnection2);
                            sqlCommand2.Parameters.AddWithValue("@bin", sqlDataReader["BIN"]);
                            if (array[4] == string.Empty)
                            {
                                array[4] = "UNKNOWN";
                            }
                            sqlCommand2.Parameters.AddWithValue("@bank", array[4]);
                            sqlCommand2.Parameters.AddWithValue("@country", array[2]);
                            string value = sqlCommand2.ExecuteScalar().ToString();
                            cmdText2 = "INSERT INTO T_BINLISTNET (ID_BIN,DATE_RETRIEVED) VALUES (@id_bin,GETDATE())";
                            sqlCommand2 = new SqlCommand(cmdText2, sqlConnection2);
                            sqlCommand2.Parameters.AddWithValue("@id_bin", value);
                            sqlCommand2.ExecuteNonQuery();
                            cmdText2 = "UPDATE T_FRAUD SET ISSUER_STATE = (SELECT CODE3 FROM T_STATE WHERE CODE2=@country) WHERE BIN=@bin";
                            sqlCommand2 = new SqlCommand(cmdText2, sqlConnection2);
                            sqlCommand2.Parameters.AddWithValue("@bin", sqlDataReader["BIN"]);
                            sqlCommand2.Parameters.AddWithValue("@country", array[2]);
                            sqlCommand2.ExecuteNonQuery();
                        }
                        else
                        {
                            MyConsole.enqueue("BIN " + sqlDataReader["BIN"] + ": BINLIST.NET: Not found");
                        }
                    }
                    catch (WebException ex)
                    {
                        if (ex.Message.Contains("404"))
                        {
                            MyConsole.enqueue("BIN " + sqlDataReader["BIN"] + ": BINLIST.NET: Not found");
                        }
                        else
                        {
                            if (ex.Message.Contains("403"))
                            {
                                sqlConnection.Close();
                                MyConsole.enqueue("BINLIST.NET Error: Try again in 1 hour");
                                return;
                            }
                            MyConsole.enqueue(string.Concat(new object[]
							{
								"WEB ERROR ",
								sqlDataReader["BIN"],
								": ",
								ex.Message
							}));
                        }
                    }
                }
                sqlConnection2.Close();
            }
            catch (Exception ex2)
            {
                sqlConnection.Close();
                MyMessage.showMessage("ERROR\n" + ex2.Message, MessageBoxIcon.Hand);
                MyConsole.enqueue(ex2.Message);
                MyLogger.WriteLog("ERROR getBinFromWeb() : " + ex2.Message);
            }
            sqlConnection.Close();
        }
        public static void fillDropDownList(string Query, ComboBox DropDownName, string valueMember, string displayMember, bool emptyRow = false)
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud))
            {
                sqlConnection.Open();
                try
                {
                    SqlCommand sqlCommand = new SqlCommand(Query, sqlConnection);
                    SqlDataReader reader = sqlCommand.ExecuteReader();
                    dataTable.Load(reader);
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("ERROR\n" + ex.Message, MessageBoxIcon.Hand);
                    MyConsole.enqueue(ex.Message);
                    MyLogger.WriteLog("ERROR getBinFromWeb() : " + ex.Message);
                }
            }
            if (emptyRow)
            {
                DataRow dataRow = dataTable.NewRow();
                dataRow[displayMember] = "";
                dataRow[valueMember] = "";
                dataTable.Rows.InsertAt(dataRow, 0);
            }
            DropDownName.DataSource = dataTable;
            DropDownName.ValueMember = valueMember;
            DropDownName.DisplayMember = displayMember;
        }
        public static void resetAllControls(Control form)
        {
            foreach (Control control in form.Controls)
            {
                if (control is TextBox)
                {
                    TextBox textBox = (TextBox)control;
                    textBox.Text = null;
                }
                if (control is ComboBox)
                {
                    ComboBox comboBox = (ComboBox)control;
                    if (comboBox.Items.Count > 0)
                    {
                        comboBox.SelectedIndex = 0;
                    }
                }
                if (control is CheckBox)
                {
                    CheckBox checkBox = (CheckBox)control;
                    checkBox.Checked = false;
                }
                if (control is ListBox)
                {
                    ListBox listBox = (ListBox)control;
                    listBox.ClearSelected();
                }
            }
        }
    }
}
