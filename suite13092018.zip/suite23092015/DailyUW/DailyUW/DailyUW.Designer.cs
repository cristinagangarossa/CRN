﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace DailyUW
{
    partial class DailyUW
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private GroupBox destination_file;
        private TextBox tbXslPath;
        private Button button3;
        private GroupBox groupBox1;
        private RadioButton rbCreate;
        private RadioButton rbComplete;
        private Button button1;
        private DateTimePicker dateTimePicker1;
        private Label label7;
        private DateTimePicker dateTimePicker2;
        private Label label8;
        private Button button4;
        private StatusStrip statusStrip1;
        private ToolStripProgressBar myprogressbar;
        private BackgroundWorker backgroundWorker1;
        private ComboBox tbSheet;
        private Label lbl_sheetname;
        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.destination_file = new System.Windows.Forms.GroupBox();
            this.tbSheet = new System.Windows.Forms.ComboBox();
            this.lbl_sheetname = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.tbXslPath = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbCreate = new System.Windows.Forms.RadioButton();
            this.rbComplete = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.myprogressbar = new System.Windows.Forms.ToolStripProgressBar();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.destination_file.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // destination_file
            // 
            this.destination_file.Controls.Add(this.tbSheet);
            this.destination_file.Controls.Add(this.lbl_sheetname);
            this.destination_file.Controls.Add(this.dateTimePicker2);
            this.destination_file.Controls.Add(this.label8);
            this.destination_file.Controls.Add(this.label7);
            this.destination_file.Controls.Add(this.dateTimePicker1);
            this.destination_file.Controls.Add(this.tbXslPath);
            this.destination_file.Controls.Add(this.button3);
            this.destination_file.Location = new System.Drawing.Point(9, 101);
            this.destination_file.Name = "destination_file";
            this.destination_file.Size = new System.Drawing.Size(339, 133);
            this.destination_file.TabIndex = 28;
            this.destination_file.TabStop = false;
            this.destination_file.Text = "Destination file";
            // 
            // tbSheet
            // 
            this.tbSheet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tbSheet.FormattingEnabled = true;
            this.tbSheet.Location = new System.Drawing.Point(92, 60);
            this.tbSheet.Name = "tbSheet";
            this.tbSheet.Size = new System.Drawing.Size(175, 23);
            this.tbSheet.TabIndex = 35;
            this.tbSheet.Visible = false;
            // 
            // lbl_sheetname
            // 
            this.lbl_sheetname.AutoSize = true;
            this.lbl_sheetname.Location = new System.Drawing.Point(17, 63);
            this.lbl_sheetname.Name = "lbl_sheetname";
            this.lbl_sheetname.Size = new System.Drawing.Size(69, 15);
            this.lbl_sheetname.TabIndex = 34;
            this.lbl_sheetname.Text = "Sheet name";
            this.lbl_sheetname.Visible = false;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(92, 92);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(209, 23);
            this.dateTimePicker2.TabIndex = 33;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(40, 98);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 15);
            this.label8.TabIndex = 32;
            this.label8.Text = "Date to";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 15);
            this.label7.TabIndex = 31;
            this.label7.Text = "Date from";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(92, 60);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(209, 23);
            this.dateTimePicker1.TabIndex = 18;
            // 
            // tbXslPath
            // 
            this.tbXslPath.Location = new System.Drawing.Point(92, 28);
            this.tbXslPath.Name = "tbXslPath";
            this.tbXslPath.ReadOnly = true;
            this.tbXslPath.Size = new System.Drawing.Size(230, 23);
            this.tbXslPath.TabIndex = 16;
            this.tbXslPath.Tag = "Destination file";
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.Location = new System.Drawing.Point(17, 26);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.button3.Size = new System.Drawing.Size(69, 25);
            this.button3.TabIndex = 14;
            this.button3.Text = "Browse..";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbCreate);
            this.groupBox1.Controls.Add(this.rbComplete);
            this.groupBox1.Location = new System.Drawing.Point(9, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(339, 77);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Import mode";
            // 
            // rbCreate
            // 
            this.rbCreate.AutoSize = true;
            this.rbCreate.Checked = true;
            this.rbCreate.Location = new System.Drawing.Point(33, 33);
            this.rbCreate.Name = "rbCreate";
            this.rbCreate.Size = new System.Drawing.Size(97, 19);
            this.rbCreate.TabIndex = 1;
            this.rbCreate.TabStop = true;
            this.rbCreate.Text = "Create report";
            this.rbCreate.UseVisualStyleBackColor = true;
            this.rbCreate.CheckedChanged += new System.EventHandler(this.rbCreate_CheckedChanged);
            // 
            // rbComplete
            // 
            this.rbComplete.AutoSize = true;
            this.rbComplete.Location = new System.Drawing.Point(155, 33);
            this.rbComplete.Name = "rbComplete";
            this.rbComplete.Size = new System.Drawing.Size(151, 19);
            this.rbComplete.TabIndex = 0;
            this.rbComplete.Text = "Complete w/ Appr. date";
            this.rbComplete.UseVisualStyleBackColor = true;
            this.rbComplete.CheckedChanged += new System.EventHandler(this.rbComplete_CheckedChanged);
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(115, 244);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.button1.Size = new System.Drawing.Size(48, 25);
            this.button1.TabIndex = 24;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.AutoSize = true;
            this.button4.BackColor = System.Drawing.SystemColors.Control;
            this.button4.Location = new System.Drawing.Point(181, 244);
            this.button4.Name = "button4";
            this.button4.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.button4.Size = new System.Drawing.Size(60, 25);
            this.button4.TabIndex = 31;
            this.button4.Text = "Cancel";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.myprogressbar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 279);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(356, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 32;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // myprogressbar
            // 
            this.myprogressbar.Name = "myprogressbar";
            this.myprogressbar.Size = new System.Drawing.Size(350, 16);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.WorkerReportsProgress = true;
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker1_ProgressChanged);
            this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            // 
            // DailyUW
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 301);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.destination_file);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DailyUW";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Daily UW";
            this.destination_file.ResumeLayout(false);
            this.destination_file.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion


    }
}

