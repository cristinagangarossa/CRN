﻿using System;
using System.ComponentModel;
using System.Net;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.IO;
using System.Xml;
using System.Collections;
using System.Data.OleDb;
using Microsoft.Office.Interop.Excel;
using System.Threading;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

namespace DailyUW
{
    public partial class DailyUW : Form
    {
        //viewConsole win;
        bool closeConsole = false;

        public DailyUW()
        {
            InitializeComponent();
        }
        static bool MyCertHandler(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors error)
        {
            // Ignore errors
            return true;
        }
        // DailyUW.Dailyuw
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                //call method to bypass certificate
                ServicePointManager.ServerCertificateValidationCallback = MyCertHandler;

                CookieContainer myCook = new CookieContainer();
                string url = MyConnection.con_dailyuw.url + "login.do?key=null";
                MyConsole.enqueue("Connection to " + MyConnection.con_dailyuw.url); 

                string data = "username=" + MyConnection.con_dailyuw.username + "&password=" + MyConnection.con_dailyuw.pwd;
                byte[] buffer = Encoding.UTF8.GetBytes(data);

                // Step 0: Login

                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "POST";
                req.ContentType = "application/x-www-form-urlencoded";
                req.ContentLength = buffer.Length;

                req.Proxy = WebProxy.GetDefaultProxy();
                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                req.CookieContainer = myCook; // enable cookies

                Stream reqst = req.GetRequestStream(); // add form data to request stream
                reqst.Write(buffer, 0, buffer.Length);
                reqst.Flush();
                reqst.Close();

                HttpWebResponse res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                StreamReader srResponse = new StreamReader(res.GetResponseStream());
                //Check credenziali
                string line;
                while ((line = srResponse.ReadLine()) != null)
                {
                    if (line.IndexOf("Invalid UserID/Password") != -1)
                    {
                        MessageBox.Show("Invalid UserID/Password", "Daily UW", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                MyConsole.enqueue("Logged in");
                Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                if (rbCreate.Checked)
                {
                    //Step 1
                    url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/goT.do?key=null";
                    req = (HttpWebRequest)WebRequest.Create(url);
                    req.Method = "POST";
                    req.ContentType = "application/x-www-form-urlencoded";

                    DateTime dateValue = DateTime.Now;
                    string reportDateFrom = dateTimePicker1.Value.ToString("dd.MM.yyyy");
                    string reportDateTo = dateTimePicker2.Value.ToString("dd.MM.yyyy");

                    data = "kval=&cnt=&txt_mid=&txt_salesmenNumber=&txt_co=&txt_tradingName=&txt_legalName=&txt_tradingAddressPhone=&txt_principalPhone=&txt_principalFirstName=&txt_principalLastName=&li_portfolio=00&li_countryName=00&li_accountStatus=04&li_workflowStatus=00&li_typeOfAccount=00&txt_entryDateFrom=" + reportDateFrom + "&txt_entryDateTo=" + reportDateTo;
                    buffer = Encoding.UTF8.GetBytes(data);

                    req.ContentLength = buffer.Length;

                    req.Proxy = WebProxy.GetDefaultProxy();
                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                    req.CookieContainer = myCook; // enable cookies

                    reqst = req.GetRequestStream(); // add form data to request stream
                    reqst.Write(buffer, 0, buffer.Length);
                    reqst.Flush();
                    reqst.Close();

                    res.Close();
                    res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                    MyConsole.enqueue("Getting results\r\n");

                    bool xmlLoop = true;

                    xlApp.Visible = false;
                    xlApp.DisplayAlerts = false;
                    Workbook wb = xlApp.Workbooks.Add();
                    Worksheet ws = (Worksheet)wb.Worksheets[1];
                    ws.Cells[1, 1] = "#";
                    ws.Cells[1, 2] = "DBA Name";
                    ws.Cells[1, 3] = "Date IN";
                    ws.Cells[1, 4] = "Approval date";
                    ws.Cells[1, 5] = "Working days";
                    ws.Cells[1, 6] = "M. Code";
                    ws.Cells[1, 7] = "Source Code";
                    ws.Cells[1, 8] = "BNL";
                    ws.Cells[1, 9] = "Mcc";
                    ws.Cells[1, 10] = "Risk";
                    ws.Cells[1, 11] = "Internet Y/N";
                    ws.Cells[1, 12] = "DBA City";
                    ws.Cells[1, 13] = "Auto-approved";
                    MyConsole.enqueue("Initialize XLS");
                    int i = 1;
                    int xmlPageCount = 0;
                    int accept_string_index;
                    string salesman = "";
                    int salesman_start_index;
                    string salesman_part = "";
                    while (xmlLoop)
                    {
                        xmlPageCount++;
                        //Get XML
                        url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/AjaxRequestHandler?_=1111111111111&page=" + xmlPageCount + "&noOfPages=1&noOfRec=1000&maxNumofData=1000";
                        req = (HttpWebRequest)WebRequest.Create(url);
                        req.Method = "GET";
                        req.ContentType = "text/xml;charset=ISO-8859-1";

                        req.Proxy = WebProxy.GetDefaultProxy();
                        req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                        req.CookieContainer = myCook; // enable cookies

                        res.Close();

                        res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                        srResponse = new StreamReader(res.GetResponseStream());

                        XmlDocument doc = new XmlDocument();
                        doc.LoadXml(srResponse.ReadToEnd());

                        XmlNode code = doc.SelectSingleNode("Data/Code");

                        if (code.InnerText != "0")
                        {
                            MyConsole.enqueue("Parsing result page n. " + xmlPageCount + "\r\n");
                            XmlNodeList infos = doc.SelectNodes("Data/datalist/info");
                            ArrayList xlsRow = new ArrayList();

                            foreach (XmlNode info in infos)
                            {
                                xlsRow.Clear();
                                MyLogger.WriteLog("contract id " +info["contractid"].InnerText);
                                //Get Dba City
                                url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/merchantresearchT.do?CID=" + info["contractid"].InnerText + "&BUTTON=merchant&MID_RESEARCH=99999999";
                                req = (HttpWebRequest)WebRequest.Create(url);
                                req.Method = "GET";
                                req.ContentType = "text/html; charset=ISO-8859-1";

                                req.Proxy = WebProxy.GetDefaultProxy();
                                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                req.CookieContainer = myCook; // enable cookies

                                res.Close();

                                res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                srResponse = new StreamReader(res.GetResponseStream());

                                string detailHtml = srResponse.ReadToEnd();
                                string city = detailHtml.Substring(detailHtml.IndexOf("TXTCDWADDRESSSTATE") + 27, 2);
                                
                                //Get Salesman - Bank
                                url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/bankingresearchT.do?CID=" + info["contractid"].InnerText + "&BUTTON=banking";
                                req = (HttpWebRequest)WebRequest.Create(url);
                                req.Method = "GET";
                                req.ContentType = "text/html; charset=ISO-8859-1";

                                req.Proxy = WebProxy.GetDefaultProxy();
                                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                req.CookieContainer = myCook; // enable cookies

                                res.Close();

                                res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                srResponse = new StreamReader(res.GetResponseStream());

                                detailHtml = srResponse.ReadToEnd();
                                salesman_start_index = detailHtml.IndexOf("INTCONTREXT_SALESMANID") + 31;
                                
                                salesman = "";
                                salesman_part = "";
                                while (salesman_part != "\"")
                                {
                                    salesman += salesman_part;
                                    
                                    salesman_part = detailHtml.Substring(salesman_start_index, 1);
                                    
                                    salesman_start_index++;
                                }

                                //salesman = "'" + detailHtml.Substring(detailHtml.IndexOf("INTCONTREXT_SALESMANID") + 31, 4);
                                string bnlYN = ((detailHtml.Substring(detailHtml.IndexOf("TXTCONTREXT_BANKSORTCODE") + 33, 5)).Equals("01005")) ? "BNL" : "OM";
                                
                                //Get Mcc - Risk
                                url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/riskresearchT.do?CID=" + info["contractid"].InnerText + "&BUTTON=risk";
                                req = (HttpWebRequest)WebRequest.Create(url);
                                req.Method = "GET";
                                req.ContentType = "text/html; charset=ISO-8859-1";

                                req.Proxy = WebProxy.GetDefaultProxy();
                                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                req.CookieContainer = myCook; // enable cookies

                                res.Close();

                                res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                srResponse = new StreamReader(res.GetResponseStream());

                                detailHtml = srResponse.ReadToEnd();
                                
                                string mcc = detailHtml.Substring(detailHtml.IndexOf("TXTMCCCODE") + 19, 4);
                                
                                if (mcc.StartsWith("\"")) mcc = "";
                                string risklevel = detailHtml.Substring(detailHtml.IndexOf("Risk Level") + 58, 1);
                                
                                url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/historyT.do?CID=" + info["contractid"].InnerText + "&BUTTON=history";
                                req = (HttpWebRequest)WebRequest.Create(url);
                                req.Method = "GET";
                                req.ContentType = "text/html; charset=ISO-8859-1";

                                req.Proxy = WebProxy.GetDefaultProxy();
                                req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                req.CookieContainer = myCook; // enable cookies

                                res.Close();

                                res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                srResponse = new StreamReader(res.GetResponseStream());

                                detailHtml = srResponse.ReadToEnd();
                                string dateIn = info["datein"].InnerText;//.Replace(".", "/");
                                //MyLogger.WriteLog("datein " + dateIn);
                                if (dateIn != "")
                                {
                                    string[] dateInArray = dateIn.Split('.');
                                    DateTime dtDateIn = new DateTime(int.Parse(dateInArray[2]), int.Parse(dateInArray[1]), int.Parse(dateInArray[0]));
                                    dateIn = dtDateIn.ToString("yyyy/MM/dd");
                                }
                                string dateAccept = "";

                                if (detailHtml.IndexOf("CO ACCEPT") > 0)
                                {
                                    accept_string_index = detailHtml.IndexOf("CO ACCEPT");
                                    accept_string_index = detailHtml.LastIndexOf("18%\">", accept_string_index, 400);
                                    
                                    dateAccept = detailHtml.Substring(accept_string_index + 5, 10).Replace(".", "/");
                                    }
                                else if (detailHtml.IndexOf("CO HARD DECLINE") > 0)
                                {
                                    accept_string_index = detailHtml.IndexOf("CO HARD DECLINE");
                                    accept_string_index = detailHtml.LastIndexOf("18%\">", accept_string_index, 400);
                                    dateAccept = detailHtml.Substring(accept_string_index + 5, 10).Replace(".", "/");
                                     }
                                else if (dateAccept == "" && info["accountstate"].InnerText == "Auto Approved" && detailHtml.IndexOf("Autoapproval Service") > 0)
                                {
                                    accept_string_index = detailHtml.IndexOf("Autoapproval Service");
                                    accept_string_index = detailHtml.LastIndexOf("18%\">", accept_string_index, 400);
                                    dateAccept = detailHtml.Substring(accept_string_index + 5, 10).Replace(".", "/");
                                     }
                                //Autoapproval Service

                                //Get INET YN
                                string internetYN;
                                
                                
                                if (detailHtml.IndexOf("Risk Calculation Service") > 0)
                                {
                                   
                                   // MyLogger.WriteLog("start debug 3005 ");
                                    
                                    //modifica31082017 anomalia internetYN - Cristina
                                    //String retrieveId = detailHtml.Substring(detailHtml.IndexOf("Risk Calculation Service") - 119, 8);è cambiato
                                     String retrieveId = detailHtml.Substring(detailHtml.IndexOf("Risk Calculation Service") - 118, 8);
                                      if (retrieveId.IndexOf("'") >= 0)
                                    {
                                         retrieveId = detailHtml.Substring(detailHtml.IndexOf("Risk Calculation Service") - 119, 8); //(118-7)
                                       
                                       // retrieveId = retrieveId.Substring(1);
                                        MyLogger.WriteLog("--------------------------------------------------------> id con 7 cifre "+retrieveId);
                                    }
                                     url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/showaction.do?GID=" + retrieveId;
                                     

                                    //url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/showaction.do?GID=" + detailHtml.Substring(detailHtml.IndexOf("Risk Calculation Service") - 119, 7);
                                    
                                    //MyLogger.WriteLog(" retrieve id " + retrieveId + " from " + detailHtml.Substring(detailHtml.IndexOf("Risk Calculation Service") - 119, 8));
                                    req = (HttpWebRequest)WebRequest.Create(url);
                                    req.Method = "GET";
                                    req.ContentType = "text/html; charset=ISO-8859-1";

                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                    req.CookieContainer = myCook; // enable cookies

                                    res.Close();

                                    res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                    srResponse = new StreamReader(res.GetResponseStream());
                                    detailHtml = srResponse.ReadToEnd();
                                    MyLogger.WriteLog("controllo MCCode...");
                                    //MyLogger.WriteLog(detailHtml);
                                    if (detailHtml.Length > 0)
                                    {
                                        MyLogger.WriteLog("MCCode " + (detailHtml.Substring(detailHtml.IndexOf("MCCode") + 45, 4)) + " e " + mcc);

                                        if (detailHtml.IndexOf("MCCode") != -1) // aggiunta tmp per verifiche 10/05/2017
                                        {
                                            internetYN = (detailHtml.Substring(detailHtml.IndexOf("MCCode") + 45, 4)) == "5969" ? "YES" : "NO";
                                        }
                                        else
                                        {
                                            internetYN = "N.A.";
                                           MyLogger.WriteLog("caso 1 MCCode -1 ->" + detailHtml.IndexOf("MCCode"));
                                            // MyLogger.WriteLog("internetYN N.A. MCCode=-1");
                                        }
                                    }
                                    else
                                    {
                                        internetYN = "N.A.";
                                        MyLogger.WriteLog("caso 2 MMCode ?" + detailHtml);
                                    }
                                }
                                else
                                {
                                    internetYN = "N.A.";
                                   MyLogger.WriteLog("caso 3 detailHTML RCS =0 " + detailHtml.IndexOf("Risk Calculation Service"));
                                  //  MyLogger.WriteLog("internetYN N.A. RCS=0");
                                }

                                //finalize
                                xlsRow.Add(i.ToString());
                                xlsRow.Add(info["dbaName"].InnerText);
                                xlsRow.Add(dateIn);
                                xlsRow.Add(dateAccept);
                                if (dateAccept != "")
                                {
                                    xlsRow.Add("=GIORNI.LAVORATIVI.TOT(C" + (i + 1) + ";D" + (i + 1) + ")-1");
                                }
                                else
                                {
                                    xlsRow.Add("");
                                }
                                xlsRow.Add("'" + info["mid"].InnerText);
                                xlsRow.Add(salesman);
                                xlsRow.Add(bnlYN);
                                xlsRow.Add(mcc);
                                xlsRow.Add(risklevel);
                                xlsRow.Add(internetYN);
                                city = city.Replace("\"", "").Replace(" ", "");
                                xlsRow.Add(city);
                                xlsRow.Add((info["accountstate"].InnerText == "Auto Approved") ? "Y" : "N");
                                MyConsole.enqueue("INSERT ROW " + i + ": " + info["dbaName"].InnerText);
                                MyLogger.WriteLog("INSERT ROW " + i + ": " + info["dbaName"].InnerText);
                                reportAddLine(ws, xlsRow, i + 1);
                                i++;
                                MyLogger.WriteLog("index line  "+i);
                            }
                        }
                        else
                        {
                            xmlLoop = false;
                        }
                    }
                    wb.SaveAs(tbXslPath.Text, XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing, false, false, XlSaveAsAccessMode.xlNoChange, XlSaveConflictResolution.xlLocalSessionChanges);
                    wb.Close(true);
                    xlApp.Quit();
                }
                else if (rbComplete.Checked)
                {
                    MyConsole.enqueue("Copia del file...");
                    //Copia del file
                    string pathCompl = Path.GetDirectoryName(tbXslPath.Text);
                    string extension = Path.GetExtension(tbXslPath.Text);

                    string tempFilePath = pathCompl + "\\" + Path.GetFileNameWithoutExtension(tbXslPath.Text) + "_temp" + extension;
                    File.Copy(tbXslPath.Text, tempFilePath, true);

                    //Inizio ciclo excel
                    string con = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + tempFilePath + ";Extended Properties='Excel 12.0;HDR=Yes;'";
                    using (OleDbConnection connection = new OleDbConnection(con))
                    {
                        connection.Open();
                        OleDbCommand command = new OleDbCommand("select * from [" + tbSheet.Text + "$] where [Approval date] is null", connection);
                        using (OleDbDataReader dr = command.ExecuteReader())
                        {
                            xlApp.Visible = false;
                            xlApp.DisplayAlerts = false;
                            Workbook wb = xlApp.Workbooks.Add(tbXslPath.Text);
                            Worksheet ws = (Worksheet)wb.Worksheets[tbSheet.Text];
                            while (dr.Read())
                            {
                                if (dr[0].ToString() != "")
                                {
                                    //Step 1
                                    url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/goT.do?key=null";
                                    req = (HttpWebRequest)WebRequest.Create(url);
                                    req.Method = "POST";
                                    req.ContentType = "application/x-www-form-urlencoded";

                                    data = "kval=&cnt=&txt_mid=" + dr[5].ToString() + "&txt_salesmenNumber=&txt_co=&txt_tradingName=&txt_legalName=&txt_tradingAddressPhone=&txt_principalPhone=&txt_principalFirstName=&txt_principalLastName=&li_portfolio=00&li_countryName=00&li_accountStatus=04&li_workflowStatus=00&li_typeOfAccount=00&txt_entryDateFrom=&txt_entryDateTo=";

                                    buffer = Encoding.UTF8.GetBytes(data);

                                    req.ContentLength = buffer.Length;

                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                    req.CookieContainer = myCook; // enable cookies

                                    reqst = req.GetRequestStream(); // add form data to request stream
                                    reqst.Write(buffer, 0, buffer.Length);
                                    reqst.Flush();
                                    reqst.Close();

                                    res.Close();
                                    res = (HttpWebResponse)req.GetResponse(); // send request,  get response

                                    //Get XML
                                    url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/AjaxRequestHandler?_=1111111111111&page=1&noOfPages=1&noOfRec=1000&maxNumofData=1000";
                                    req = (HttpWebRequest)WebRequest.Create(url);
                                    req.Method = "GET";
                                    req.ContentType = "text/xml;charset=ISO-8859-1";

                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                    req.CookieContainer = myCook; // enable cookies

                                    res.Close();

                                    res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                    srResponse = new StreamReader(res.GetResponseStream());

                                    XmlDocument doc = new XmlDocument();
                                    doc.LoadXml(srResponse.ReadToEnd());
                                    XmlNode info = doc.SelectSingleNode("Data/datalist/info");

                                    //step Vincenzo (Ricarica a vuoto)
                                    url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/merchantresearchT.do?CID=" + info["contractid"].InnerText + "&BUTTON=merchant&MID_RESEARCH=99999999";
                                    req = (HttpWebRequest)WebRequest.Create(url);
                                    req.Method = "GET";
                                    req.ContentType = "text/html; charset=ISO-8859-1";
                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;
                                    req.CookieContainer = myCook; // enable cookies
                                    res.Close();
                                    res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                    //fine step Vincenzo (Ricarica a vuoto)

                                    url = "https://" + MyConnection.con_dailyuw.ip + "/GlobalUnderwriter/historyT.do?CID=" + info["contractid"].InnerText + "&BUTTON=history";
                                    req = (HttpWebRequest)WebRequest.Create(url);
                                    req.Method = "GET";
                                    req.ContentType = "text/html; charset=ISO-8859-1";

                                    req.Proxy = WebProxy.GetDefaultProxy();
                                    req.Proxy.Credentials = CredentialCache.DefaultCredentials;

                                    req.CookieContainer = myCook; // enable cookies

                                    res.Close();

                                    res = (HttpWebResponse)req.GetResponse(); // send request,  get response
                                    srResponse = new StreamReader(res.GetResponseStream());

                                    string detailHtml = srResponse.ReadToEnd();

                                    string dateAccept = "";

                                    int row = (int.Parse(dr[0].ToString())) + 1;
                                    int accept_string_index = 0;
                                    if (detailHtml.IndexOf("CO ACCEPT") > 0)
                                    {
                                        accept_string_index = detailHtml.IndexOf("CO ACCEPT");
                                        accept_string_index = detailHtml.LastIndexOf("18%\">", accept_string_index, 400);
                                        
                                        dateAccept = detailHtml.Substring(accept_string_index + 5, 10).Replace(".", "/");
                                        
                                        MyConsole.enqueue("UPDATE MID: " + info["mid"].InnerText + " CONTRACT-ID: " + info["contractid"].InnerText + " Appr.date: " + dateAccept + " (CO ACCEPT)");
                                        ws.Cells[row, 4] = dateAccept;
                                        //ws.Cells[row, 5] = "=GIORNI.LAVORATIVI.TOT(C" + row + ";D" + row + ")-1";
                                        ((Range)ws.Cells[row, 5]).FormulaLocal = "=GIORNI.LAVORATIVI.TOT(C" + row + ";D" + row + ")-1";
                                    }
                                    else if (detailHtml.IndexOf("CO HARD DECLINE") > 0)
                                    {
                                        accept_string_index = detailHtml.IndexOf("CO HARD DECLINE");
                                        accept_string_index = detailHtml.LastIndexOf("18%\">", accept_string_index, 400);
                                        
                                        dateAccept = detailHtml.Substring(accept_string_index + 5, 10).Replace(".", "/");
                                        
                                        MyConsole.enqueue("UPDATE MID: " + info["mid"].InnerText + " CONTRACT-ID: " + info["contractid"].InnerText + " Appr.date: " + dateAccept + " (HARD DECLINE)");
                                        ws.Cells[row, 4] = dateAccept;
                                        //ws.Cells[row, 5] = "=GIORNI.LAVORATIVI.TOT(C" + row + ";D" + row + ")-1";
                                        ((Range)ws.Cells[row, 5]).FormulaLocal = "=GIORNI.LAVORATIVI.TOT(C" + row + ";D" + row + ")-1";
                                    }
                                    else
                                    {
                                        MyConsole.enqueue("UPDATE MID: " + info["mid"].InnerText + " CONTRACT-ID: " + info["contractid"].InnerText + " Appr.date: NO DATA AVAILABLE");
                                    }
                                }
                            }
                            wb.SaveAs(tbXslPath.Text, XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing, false, false, XlSaveAsAccessMode.xlNoChange, XlSaveConflictResolution.xlLocalSessionChanges);
                            wb.Close(true);
                            xlApp.Quit();
                        }
                    }
                    File.Delete(tempFilePath);
                }
                MyConsole.enqueue("END OF PROCEDURE. File " + tbXslPath.Text + " updated");
            }
            catch (Exception ee)
            {
                MessageBox.Show("ERROR\r\n" + ee.Message, "Credit & Risk", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                MyConsole.enqueue("ERROR: " + ee.Message);
            }
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            Cursor.Current = Cursors.Arrow;
            /*if (this.myprogressbar.Value != 100)
            {
                MyMessage.showMessage("Import has been stopped", MessageBoxIcon.Hand);
            }
            else
            {
                MyMessage.showMessage(string.Concat(this.tbXslPath.Text, " SAVED"), MessageBoxIcon.Asterisk);
            }*/

            if (closeConsole)
            {
                MyConsole.mostraCONSOLE.Hide();
            }
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.myprogressbar.Value = e.ProgressPercentage;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.myprogressbar.Value = 0;
            if (MyControl.checkControl(this.destination_file))
            {
                base.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                MyLogger.WriteLog(string.Concat(this.Text, ": start create"));
                BackgroundWorker backgroundWorker = this.backgroundWorker1;
                backgroundWorker.RunWorkerAsync(new object[] { this.tbXslPath.Text, this.tbSheet.Text, (this.rbCreate.Checked ? "rbCreate" : "rbComplete") });

               /* win = (System.Windows.Forms.Application.OpenForms["viewConsole"] != null) ? ((viewConsole)System.Windows.Forms.Application.OpenForms["viewConsole"]) : null;
                if (win == null)
                {
                    win = new viewConsole();
                    win.Show();
                    closeConsole = true;
                }*/

                if (!MyConsole.mostraCONSOLE.Visible)
                {
                    closeConsole = true;
                    MyConsole.mostraCONSOLE.Show();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.rbCreate.Checked)
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog()
                {
                    Filter = "File Excel (*.xls, *.xlsx)|*.xls; *.xlsx"
                };
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    this.tbXslPath.Text = saveFileDialog.FileName;
                }
            }
            else if (this.rbComplete.Checked)
            {
                OpenFileDialog openFileDialog = new OpenFileDialog()
                {
                    Filter = "File Excel (*.xls, *.xlsx)|*.xls; *.xlsx"
                };
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    Cursor.Current = Cursors.WaitCursor;
                    this.tbXslPath.Text = openFileDialog.FileName;
                    MyExcel.FilledCombobox(ref this.tbSheet, this.tbXslPath.Text);
                    Cursor.Current = Cursors.Arrow;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void rbComplete_CheckedChanged(object sender, EventArgs e)
        {
            this.destination_file.Text = "Source file";
            this.lbl_sheetname.Visible = true;
            this.tbSheet.Visible = true;
            this.dateTimePicker1.Visible = false;
            this.label7.Visible = false;
            this.label8.Visible = false;
            this.dateTimePicker2.Visible = false;
        }

        private void rbCreate_CheckedChanged(object sender, EventArgs e)
        {
            this.destination_file.Text = "Destination file";
            this.lbl_sheetname.Visible = false;
            this.tbSheet.Visible = false;
            this.dateTimePicker1.Visible = true;
            this.label7.Visible = true;
            this.label8.Visible = true;
            this.dateTimePicker2.Visible = true;
        }

        private void reportAddLine(Worksheet ws, ArrayList line, int index)
        {
            int col = 1;
            foreach (string element in line)
            {
                if (element.StartsWith("="))
                {
                    ((Range)ws.Cells[index, col]).FormulaLocal = element;
                }
                else
                {
                    ws.Cells[index, col] = element;
                }
                col++;
            }
        }
    }
}
