﻿using Credit_risk_lib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Credit_Risk
{
    public partial class Start : Form
    {
        public Start()
        {
            InitializeComponent();
            this.lblstatus.Text = "Loading...";
            Cursor.Current = Cursors.WaitCursor;
            this.myworker.RunWorkerAsync();
        }

        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {

            if (System.IO.File.Exists("basic_settings.xml"))
            {
                this.myworker.ReportProgress(15);
                MyConnection.InizializeParameter_ice();
                this.myworker.ReportProgress(30);
                MyConnection.InizializeConnection_db_Fraud();
                this.myworker.ReportProgress(45);
                MyConnection.InizializeConnection_db_Writeoff();
                this.myworker.ReportProgress(60);
                MyConnection.InizializeParameter_dailyuw();
                this.myworker.ReportProgress(90);
                MyConnection.InizializeConnection_db_Tagetik_MS();
                MyConnection.InizializeConnection_db_Tagetik_Oracle();
                this.myworker.ReportProgress(100);
                Thread.Sleep(500);
                MyConnection.InizializeConnection_db_Tagetik_Ftp();
            }
            else
            {
                
                string mydoc = string.Concat(new string[] 
                {
                    "<?xml version=\"1.0\" encoding=\"utf-8\" ?>",
                    "<Root><connectionString_fraud source=\"\" username=\"\" pwd=\"\" />",
                    "<connectionString_writeoff source=\"\" username=\"\" pwd=\"\" />",
                    "<connectionString_tagetikMS source=\"\" username=\"\" pwd=\"\" />",
                    "<connectionString_tagetikOracle host=\"\" port=\"\" username=\"\" pwd=\"\" sid=\"\" />",
                    "<connectionString_tagetikFTP host=\"\" port=\"\" username=\"\" pwd=\"\" path=\"\" />",
                    "<connectionICE username=\"\" pwd=\"\" ip=\"\" />",
                    "<connectionDailyUW username=\"\" pwd=\"\" ip=\"\" />",
                    "<RAMcredential username=\"\" pwd=\"\" />",
                    "</Root>"
                });
                File.WriteAllText("basic_settings.xml", MyConnection.crypta(mydoc));
                MyLogger.WriteLog("Create file settings");
                MyConsole.enqueue("Create file settings");
            }
        }
        private void myworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.ProgressPercentage <= 15)
            {
                this.lblstatus.Text = "Initialize parameter ice import";
            }
            else
            {
                if (e.ProgressPercentage > 15 && e.ProgressPercentage <= 30)
                {
                    this.lblstatus.Text = "Initialize parameter fraud manager";
                }
                else
                {
                    if (e.ProgressPercentage > 30 && e.ProgressPercentage <= 45)
                    {
                        this.lblstatus.Text = "Initialize parameter write off";
                    }
                    else
                    {
                        if (e.ProgressPercentage > 45 && e.ProgressPercentage <= 60)
                        {
                            this.lblstatus.Text = "Initialize parameter Daily UW";
                        }
                        else
                        {
                            this.lblstatus.Text = "Initialize Tagetik";
                        }
                    }
                }
            }
            this.mybar.Value = e.ProgressPercentage;
        }
        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Cursor.Current = Cursors.Default;
            base.Close();
        }
    }
}
