﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace Credit_Risk
{
    partial class setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private Button btnSaveSetting;
        private TabPage writeoff;
        private GroupBox db_writeoff;
        private Button db_w_btntest;
        private TextBox db_w_txtpwd;
        private TextBox db_w_txtname;
        private Label db_w_lblname;
        private Label db_w_lblpwd;
        private TextBox db_w_txtserver;
        private Label db_w_lblserver;
        private TabPage dailyuw;
        private GroupBox groupBox2;
        private TextBox daily_username;
        private TextBox daily_url;
        private Label label4;
        private Label label6;
        private TextBox daily_ip;
        private Label label7;
        private Label label8;
        private TabPage fraudmanager;
        private GroupBox groupBox5;
        private TextBox ram_password;
        private TextBox ram_username;
        private Label label18;
        private Label label19;
        private GroupBox db_fraud;
        private Button db_f_btntest;
        private TextBox db_f_txtpwd;
        private TextBox db_f_txtname;
        private Label db_f_lblname;
        private Label db_f_lblpwd;
        private TextBox db_f_txtserver;
        private Label db_f_lblserver;
        private TabPage tagetik;
        private GroupBox groupBox4;
        private TextBox db_tFTP_txtport;
        private Label label15;
        private TextBox db_tFTP_txtpwd;
        private TextBox db_tFTP_txtname;
        private Label label12;
        private Label label13;
        private TextBox db_tFTP_txthost;
        private Label label14;
        private GroupBox groupOracle;
        private TextBox db_tORA_txthost;
        private Label label17;
        private TextBox db_tORA_txtport;
        private Label label16;
        private Button button1;
        private TextBox db_tORA_txtpwd;
        private TextBox db_tORA_txtname;
        private Label label9;
        private Label label10;
        private TextBox db_tORA_txtsid;
        private Label label11;
        private GroupBox db_tagetik;
        private Button db_t_btntest;
        private TextBox db_tMS_txtpwd;
        private TextBox db_tMS_txtname;
        private Label db_t_lblname;
        private Label db_t_lblpwd;
        private TextBox db_tMS_txtserver;
        private Label db_t_lblserver;
        private TabPage iceimport;
        private GroupBox groupBox1;
        private TextBox ice_username;
        private TextBox ice_url;
        private Label label1;
        private Label label5;
        private TextBox ice_ip;
        private Label label2;
        private Label label3;
        private TabControl tabControl1;
        private Label label20;
        private TextBox db_tFTP_txtpath;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSaveSetting = new System.Windows.Forms.Button();
            this.writeoff = new System.Windows.Forms.TabPage();
            this.db_writeoff = new System.Windows.Forms.GroupBox();
            this.db_w_btntest = new System.Windows.Forms.Button();
            this.db_w_txtpwd = new System.Windows.Forms.TextBox();
            this.db_w_txtname = new System.Windows.Forms.TextBox();
            this.db_w_lblname = new System.Windows.Forms.Label();
            this.db_w_lblpwd = new System.Windows.Forms.Label();
            this.db_w_txtserver = new System.Windows.Forms.TextBox();
            this.db_w_lblserver = new System.Windows.Forms.Label();
            this.dailyuw = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.daily_pwd = new System.Windows.Forms.TextBox();
            this.daily_username = new System.Windows.Forms.TextBox();
            this.daily_url = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.daily_ip = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.fraudmanager = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ram_password = new System.Windows.Forms.TextBox();
            this.ram_username = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.db_fraud = new System.Windows.Forms.GroupBox();
            this.db_f_btntest = new System.Windows.Forms.Button();
            this.db_f_txtpwd = new System.Windows.Forms.TextBox();
            this.db_f_txtname = new System.Windows.Forms.TextBox();
            this.db_f_lblname = new System.Windows.Forms.Label();
            this.db_f_lblpwd = new System.Windows.Forms.Label();
            this.db_f_txtserver = new System.Windows.Forms.TextBox();
            this.db_f_lblserver = new System.Windows.Forms.Label();
            this.tagetik = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.db_tFTP_txtpath = new System.Windows.Forms.TextBox();
            this.db_tFTP_txtport = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.db_tFTP_txtpwd = new System.Windows.Forms.TextBox();
            this.db_tFTP_txtname = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.db_tFTP_txthost = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupOracle = new System.Windows.Forms.GroupBox();
            this.db_tORA_txthost = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.db_tORA_txtport = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.db_tORA_txtpwd = new System.Windows.Forms.TextBox();
            this.db_tORA_txtname = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.db_tORA_txtsid = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.db_tagetik = new System.Windows.Forms.GroupBox();
            this.db_t_btntest = new System.Windows.Forms.Button();
            this.db_tMS_txtpwd = new System.Windows.Forms.TextBox();
            this.db_tMS_txtname = new System.Windows.Forms.TextBox();
            this.db_t_lblname = new System.Windows.Forms.Label();
            this.db_t_lblpwd = new System.Windows.Forms.Label();
            this.db_tMS_txtserver = new System.Windows.Forms.TextBox();
            this.db_t_lblserver = new System.Windows.Forms.Label();
            this.iceimport = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ice_url2 = new System.Windows.Forms.TextBox();
            this.ice_pwd = new System.Windows.Forms.TextBox();
            this.ice_username = new System.Windows.Forms.TextBox();
            this.ice_url = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ice_ip = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ice_http = new System.Windows.Forms.TextBox();
            this.writeoff.SuspendLayout();
            this.db_writeoff.SuspendLayout();
            this.dailyuw.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.fraudmanager.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.db_fraud.SuspendLayout();
            this.tagetik.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupOracle.SuspendLayout();
            this.db_tagetik.SuspendLayout();
            this.iceimport.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSaveSetting
            // 
            this.btnSaveSetting.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveSetting.AutoSize = true;
            this.btnSaveSetting.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveSetting.Location = new System.Drawing.Point(204, 395);
            this.btnSaveSetting.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSaveSetting.Name = "btnSaveSetting";
            this.btnSaveSetting.Padding = new System.Windows.Forms.Padding(13, 0, 13, 0);
            this.btnSaveSetting.Size = new System.Drawing.Size(113, 25);
            this.btnSaveSetting.TabIndex = 34;
            this.btnSaveSetting.Tag = "Pressed Button save settings";
            this.btnSaveSetting.Text = "Save settings";
            this.btnSaveSetting.UseVisualStyleBackColor = true;
            this.btnSaveSetting.Click += new System.EventHandler(this.btnSaveSetting_Click);
            // 
            // writeoff
            // 
            this.writeoff.Controls.Add(this.db_writeoff);
            this.writeoff.Location = new System.Drawing.Point(4, 24);
            this.writeoff.Name = "writeoff";
            this.writeoff.Padding = new System.Windows.Forms.Padding(3);
            this.writeoff.Size = new System.Drawing.Size(482, 358);
            this.writeoff.TabIndex = 5;
            this.writeoff.Text = "WriteOff";
            this.writeoff.UseVisualStyleBackColor = true;
            // 
            // db_writeoff
            // 
            this.db_writeoff.Controls.Add(this.db_w_btntest);
            this.db_writeoff.Controls.Add(this.db_w_txtpwd);
            this.db_writeoff.Controls.Add(this.db_w_txtname);
            this.db_writeoff.Controls.Add(this.db_w_lblname);
            this.db_writeoff.Controls.Add(this.db_w_lblpwd);
            this.db_writeoff.Controls.Add(this.db_w_txtserver);
            this.db_writeoff.Controls.Add(this.db_w_lblserver);
            this.db_writeoff.Location = new System.Drawing.Point(8, 86);
            this.db_writeoff.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_writeoff.Name = "db_writeoff";
            this.db_writeoff.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_writeoff.Size = new System.Drawing.Size(466, 187);
            this.db_writeoff.TabIndex = 11;
            this.db_writeoff.TabStop = false;
            this.db_writeoff.Text = "Database connection";
            // 
            // db_w_btntest
            // 
            this.db_w_btntest.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.db_w_btntest.AutoSize = true;
            this.db_w_btntest.Location = new System.Drawing.Point(172, 142);
            this.db_w_btntest.Name = "db_w_btntest";
            this.db_w_btntest.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.db_w_btntest.Size = new System.Drawing.Size(115, 27);
            this.db_w_btntest.TabIndex = 33;
            this.db_w_btntest.Tag = "";
            this.db_w_btntest.Text = "Test connection";
            this.db_w_btntest.UseVisualStyleBackColor = true;
            this.db_w_btntest.Click += new System.EventHandler(this.db_w_btntest_Click_1);
            // 
            // db_w_txtpwd
            // 
            this.db_w_txtpwd.Location = new System.Drawing.Point(172, 114);
            this.db_w_txtpwd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_w_txtpwd.MaxLength = 50;
            this.db_w_txtpwd.Name = "db_w_txtpwd";
            this.db_w_txtpwd.PasswordChar = '*';
            this.db_w_txtpwd.Size = new System.Drawing.Size(155, 23);
            this.db_w_txtpwd.TabIndex = 32;
            this.db_w_txtpwd.Tag = "Account password";
            // 
            // db_w_txtname
            // 
            this.db_w_txtname.Location = new System.Drawing.Point(172, 82);
            this.db_w_txtname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_w_txtname.MaxLength = 50;
            this.db_w_txtname.Name = "db_w_txtname";
            this.db_w_txtname.Size = new System.Drawing.Size(155, 23);
            this.db_w_txtname.TabIndex = 31;
            this.db_w_txtname.Tag = "Account name";
            // 
            // db_w_lblname
            // 
            this.db_w_lblname.AutoSize = true;
            this.db_w_lblname.Location = new System.Drawing.Point(82, 85);
            this.db_w_lblname.Name = "db_w_lblname";
            this.db_w_lblname.Size = new System.Drawing.Size(85, 15);
            this.db_w_lblname.TabIndex = 4;
            this.db_w_lblname.Text = "Account name";
            // 
            // db_w_lblpwd
            // 
            this.db_w_lblpwd.AutoSize = true;
            this.db_w_lblpwd.Location = new System.Drawing.Point(58, 117);
            this.db_w_lblpwd.Name = "db_w_lblpwd";
            this.db_w_lblpwd.Size = new System.Drawing.Size(105, 15);
            this.db_w_lblpwd.TabIndex = 3;
            this.db_w_lblpwd.Text = "Account password";
            // 
            // db_w_txtserver
            // 
            this.db_w_txtserver.Location = new System.Drawing.Point(172, 50);
            this.db_w_txtserver.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_w_txtserver.MaxLength = 50;
            this.db_w_txtserver.Name = "db_w_txtserver";
            this.db_w_txtserver.Size = new System.Drawing.Size(237, 23);
            this.db_w_txtserver.TabIndex = 30;
            this.db_w_txtserver.Tag = "Server name";
            // 
            // db_w_lblserver
            // 
            this.db_w_lblserver.AutoSize = true;
            this.db_w_lblserver.Location = new System.Drawing.Point(92, 53);
            this.db_w_lblserver.Name = "db_w_lblserver";
            this.db_w_lblserver.Size = new System.Drawing.Size(72, 15);
            this.db_w_lblserver.TabIndex = 0;
            this.db_w_lblserver.Text = "Server name";
            // 
            // dailyuw
            // 
            this.dailyuw.Controls.Add(this.groupBox2);
            this.dailyuw.Location = new System.Drawing.Point(4, 24);
            this.dailyuw.Name = "dailyuw";
            this.dailyuw.Padding = new System.Windows.Forms.Padding(3);
            this.dailyuw.Size = new System.Drawing.Size(482, 358);
            this.dailyuw.TabIndex = 3;
            this.dailyuw.Text = "Daily Uw";
            this.dailyuw.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.daily_pwd);
            this.groupBox2.Controls.Add(this.daily_username);
            this.groupBox2.Controls.Add(this.daily_url);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.daily_ip);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(8, 86);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(466, 187);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Daily UW connection";
            // 
            // daily_pwd
            // 
            this.daily_pwd.Location = new System.Drawing.Point(158, 66);
            this.daily_pwd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.daily_pwd.MaxLength = 50;
            this.daily_pwd.Name = "daily_pwd";
            this.daily_pwd.PasswordChar = '*';
            this.daily_pwd.Size = new System.Drawing.Size(155, 23);
            this.daily_pwd.TabIndex = 27;
            this.daily_pwd.Tag = "Account password";
            // 
            // daily_username
            // 
            this.daily_username.Location = new System.Drawing.Point(158, 34);
            this.daily_username.MaxLength = 50;
            this.daily_username.Name = "daily_username";
            this.daily_username.Size = new System.Drawing.Size(155, 23);
            this.daily_username.TabIndex = 26;
            // 
            // daily_url
            // 
            this.daily_url.Location = new System.Drawing.Point(158, 130);
            this.daily_url.Name = "daily_url";
            this.daily_url.ReadOnly = true;
            this.daily_url.Size = new System.Drawing.Size(237, 23);
            this.daily_url.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(90, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "Username";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(72, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 15);
            this.label6.TabIndex = 17;
            this.label6.Text = "Resulting URL";
            // 
            // daily_ip
            // 
            this.daily_ip.Location = new System.Drawing.Point(158, 98);
            this.daily_ip.MaxLength = 16;
            this.daily_ip.Name = "daily_ip";
            this.daily_ip.Size = new System.Drawing.Size(109, 23);
            this.daily_ip.TabIndex = 28;
            this.daily_ip.TextChanged += new System.EventHandler(this.daily_ip_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(91, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 15);
            this.label7.TabIndex = 16;
            this.label7.Text = "Password";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(87, 101);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 15);
            this.label8.TabIndex = 11;
            this.label8.Text = "IP Address";
            // 
            // fraudmanager
            // 
            this.fraudmanager.Controls.Add(this.groupBox5);
            this.fraudmanager.Controls.Add(this.db_fraud);
            this.fraudmanager.Location = new System.Drawing.Point(4, 24);
            this.fraudmanager.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fraudmanager.Name = "fraudmanager";
            this.fraudmanager.Size = new System.Drawing.Size(482, 358);
            this.fraudmanager.TabIndex = 2;
            this.fraudmanager.Text = "Fraud Incident/Manager";
            this.fraudmanager.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ram_password);
            this.groupBox5.Controls.Add(this.ram_username);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Location = new System.Drawing.Point(8, 231);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Size = new System.Drawing.Size(466, 93);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "RAM credential";
            // 
            // ram_password
            // 
            this.ram_password.Location = new System.Drawing.Point(345, 35);
            this.ram_password.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ram_password.MaxLength = 50;
            this.ram_password.Name = "ram_password";
            this.ram_password.PasswordChar = '*';
            this.ram_password.Size = new System.Drawing.Size(104, 23);
            this.ram_password.TabIndex = 25;
            // 
            // ram_username
            // 
            this.ram_username.Location = new System.Drawing.Point(86, 35);
            this.ram_username.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ram_username.MaxLength = 50;
            this.ram_username.Name = "ram_username";
            this.ram_username.Size = new System.Drawing.Size(155, 23);
            this.ram_username.TabIndex = 24;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(18, 38);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 15);
            this.label18.TabIndex = 4;
            this.label18.Text = "Username";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(278, 38);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 15);
            this.label19.TabIndex = 3;
            this.label19.Text = "Password";
            // 
            // db_fraud
            // 
            this.db_fraud.Controls.Add(this.db_f_btntest);
            this.db_fraud.Controls.Add(this.db_f_txtpwd);
            this.db_fraud.Controls.Add(this.db_f_txtname);
            this.db_fraud.Controls.Add(this.db_f_lblname);
            this.db_fraud.Controls.Add(this.db_f_lblpwd);
            this.db_fraud.Controls.Add(this.db_f_txtserver);
            this.db_fraud.Controls.Add(this.db_f_lblserver);
            this.db_fraud.Location = new System.Drawing.Point(8, 34);
            this.db_fraud.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_fraud.Name = "db_fraud";
            this.db_fraud.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_fraud.Size = new System.Drawing.Size(466, 187);
            this.db_fraud.TabIndex = 10;
            this.db_fraud.TabStop = false;
            this.db_fraud.Text = "Database connection";
            // 
            // db_f_btntest
            // 
            this.db_f_btntest.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.db_f_btntest.AutoSize = true;
            this.db_f_btntest.Location = new System.Drawing.Point(172, 127);
            this.db_f_btntest.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_f_btntest.Name = "db_f_btntest";
            this.db_f_btntest.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.db_f_btntest.Size = new System.Drawing.Size(115, 27);
            this.db_f_btntest.TabIndex = 23;
            this.db_f_btntest.Tag = "";
            this.db_f_btntest.Text = "Test connection";
            this.db_f_btntest.UseVisualStyleBackColor = true;
            this.db_f_btntest.Click += new System.EventHandler(this.db_f_btntest_Click_1);
            // 
            // db_f_txtpwd
            // 
            this.db_f_txtpwd.Location = new System.Drawing.Point(172, 98);
            this.db_f_txtpwd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_f_txtpwd.MaxLength = 50;
            this.db_f_txtpwd.Name = "db_f_txtpwd";
            this.db_f_txtpwd.PasswordChar = '*';
            this.db_f_txtpwd.Size = new System.Drawing.Size(155, 23);
            this.db_f_txtpwd.TabIndex = 22;
            this.db_f_txtpwd.Tag = "Server password";
            // 
            // db_f_txtname
            // 
            this.db_f_txtname.Location = new System.Drawing.Point(172, 66);
            this.db_f_txtname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_f_txtname.MaxLength = 50;
            this.db_f_txtname.Name = "db_f_txtname";
            this.db_f_txtname.Size = new System.Drawing.Size(155, 23);
            this.db_f_txtname.TabIndex = 21;
            this.db_f_txtname.Tag = "Account name";
            // 
            // db_f_lblname
            // 
            this.db_f_lblname.AutoSize = true;
            this.db_f_lblname.Location = new System.Drawing.Point(82, 69);
            this.db_f_lblname.Name = "db_f_lblname";
            this.db_f_lblname.Size = new System.Drawing.Size(85, 15);
            this.db_f_lblname.TabIndex = 4;
            this.db_f_lblname.Text = "Account name";
            // 
            // db_f_lblpwd
            // 
            this.db_f_lblpwd.AutoSize = true;
            this.db_f_lblpwd.Location = new System.Drawing.Point(58, 101);
            this.db_f_lblpwd.Name = "db_f_lblpwd";
            this.db_f_lblpwd.Size = new System.Drawing.Size(105, 15);
            this.db_f_lblpwd.TabIndex = 3;
            this.db_f_lblpwd.Text = "Account password";
            // 
            // db_f_txtserver
            // 
            this.db_f_txtserver.Location = new System.Drawing.Point(172, 34);
            this.db_f_txtserver.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_f_txtserver.MaxLength = 50;
            this.db_f_txtserver.Name = "db_f_txtserver";
            this.db_f_txtserver.Size = new System.Drawing.Size(237, 23);
            this.db_f_txtserver.TabIndex = 20;
            this.db_f_txtserver.Tag = "Server name";
            // 
            // db_f_lblserver
            // 
            this.db_f_lblserver.AutoSize = true;
            this.db_f_lblserver.Location = new System.Drawing.Point(92, 37);
            this.db_f_lblserver.Name = "db_f_lblserver";
            this.db_f_lblserver.Size = new System.Drawing.Size(72, 15);
            this.db_f_lblserver.TabIndex = 0;
            this.db_f_lblserver.Text = "Server name";
            // 
            // tagetik
            // 
            this.tagetik.Controls.Add(this.groupBox4);
            this.tagetik.Controls.Add(this.groupOracle);
            this.tagetik.Controls.Add(this.db_tagetik);
            this.tagetik.Location = new System.Drawing.Point(4, 24);
            this.tagetik.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tagetik.Name = "tagetik";
            this.tagetik.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tagetik.Size = new System.Drawing.Size(482, 358);
            this.tagetik.TabIndex = 1;
            this.tagetik.Text = "Tagetik Import";
            this.tagetik.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.db_tFTP_txtpath);
            this.groupBox4.Controls.Add(this.db_tFTP_txtport);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.db_tFTP_txtpwd);
            this.groupBox4.Controls.Add(this.db_tFTP_txtname);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.db_tFTP_txthost);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Location = new System.Drawing.Point(9, 228);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Size = new System.Drawing.Size(466, 120);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "FTP connection";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(68, 90);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 15);
            this.label20.TabIndex = 11;
            this.label20.Text = "Path";
            // 
            // db_tFTP_txtpath
            // 
            this.db_tFTP_txtpath.Location = new System.Drawing.Point(106, 87);
            this.db_tFTP_txtpath.MaxLength = 256;
            this.db_tFTP_txtpath.Name = "db_tFTP_txtpath";
            this.db_tFTP_txtpath.Size = new System.Drawing.Size(343, 23);
            this.db_tFTP_txtpath.TabIndex = 19;
            this.db_tFTP_txtpath.Tag = "Path destination";
            // 
            // db_tFTP_txtport
            // 
            this.db_tFTP_txtport.Location = new System.Drawing.Point(342, 23);
            this.db_tFTP_txtport.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tFTP_txtport.MaxLength = 4;
            this.db_tFTP_txtport.Name = "db_tFTP_txtport";
            this.db_tFTP_txtport.Size = new System.Drawing.Size(60, 23);
            this.db_tFTP_txtport.TabIndex = 16;
            this.db_tFTP_txtport.Tag = "Account password";
            this.db_tFTP_txtport.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.check_digit_number);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(306, 26);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 15);
            this.label15.TabIndex = 7;
            this.label15.Text = "Port";
            // 
            // db_tFTP_txtpwd
            // 
            this.db_tFTP_txtpwd.Location = new System.Drawing.Point(342, 53);
            this.db_tFTP_txtpwd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tFTP_txtpwd.MaxLength = 50;
            this.db_tFTP_txtpwd.Name = "db_tFTP_txtpwd";
            this.db_tFTP_txtpwd.PasswordChar = '*';
            this.db_tFTP_txtpwd.Size = new System.Drawing.Size(107, 23);
            this.db_tFTP_txtpwd.TabIndex = 18;
            this.db_tFTP_txtpwd.Tag = "Account password";
            // 
            // db_tFTP_txtname
            // 
            this.db_tFTP_txtname.Location = new System.Drawing.Point(106, 55);
            this.db_tFTP_txtname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tFTP_txtname.MaxLength = 50;
            this.db_tFTP_txtname.Name = "db_tFTP_txtname";
            this.db_tFTP_txtname.Size = new System.Drawing.Size(155, 23);
            this.db_tFTP_txtname.TabIndex = 17;
            this.db_tFTP_txtname.Tag = "Account name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 56);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 15);
            this.label12.TabIndex = 4;
            this.label12.Text = "Account name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(275, 56);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 15);
            this.label13.TabIndex = 3;
            this.label13.Text = "Password";
            // 
            // db_tFTP_txthost
            // 
            this.db_tFTP_txthost.Location = new System.Drawing.Point(106, 23);
            this.db_tFTP_txthost.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tFTP_txthost.MaxLength = 50;
            this.db_tFTP_txthost.Name = "db_tFTP_txthost";
            this.db_tFTP_txthost.Size = new System.Drawing.Size(155, 23);
            this.db_tFTP_txthost.TabIndex = 15;
            this.db_tFTP_txthost.Tag = "Server name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(68, 26);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(32, 15);
            this.label14.TabIndex = 0;
            this.label14.Text = "Host";
            // 
            // groupOracle
            // 
            this.groupOracle.Controls.Add(this.db_tORA_txthost);
            this.groupOracle.Controls.Add(this.label17);
            this.groupOracle.Controls.Add(this.db_tORA_txtport);
            this.groupOracle.Controls.Add(this.label16);
            this.groupOracle.Controls.Add(this.button1);
            this.groupOracle.Controls.Add(this.db_tORA_txtpwd);
            this.groupOracle.Controls.Add(this.db_tORA_txtname);
            this.groupOracle.Controls.Add(this.label9);
            this.groupOracle.Controls.Add(this.label10);
            this.groupOracle.Controls.Add(this.db_tORA_txtsid);
            this.groupOracle.Controls.Add(this.label11);
            this.groupOracle.Location = new System.Drawing.Point(9, 104);
            this.groupOracle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupOracle.Name = "groupOracle";
            this.groupOracle.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupOracle.Size = new System.Drawing.Size(466, 120);
            this.groupOracle.TabIndex = 8;
            this.groupOracle.TabStop = false;
            this.groupOracle.Text = "Oracle connection";
            // 
            // db_tORA_txthost
            // 
            this.db_tORA_txthost.Location = new System.Drawing.Point(106, 21);
            this.db_tORA_txthost.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tORA_txthost.MaxLength = 50;
            this.db_tORA_txthost.Name = "db_tORA_txthost";
            this.db_tORA_txthost.Size = new System.Drawing.Size(155, 23);
            this.db_tORA_txthost.TabIndex = 9;
            this.db_tORA_txthost.Tag = "Account name";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(50, 24);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 15);
            this.label17.TabIndex = 11;
            this.label17.Text = "DB Host";
            // 
            // db_tORA_txtport
            // 
            this.db_tORA_txtport.Location = new System.Drawing.Point(342, 21);
            this.db_tORA_txtport.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tORA_txtport.MaxLength = 4;
            this.db_tORA_txtport.Name = "db_tORA_txtport";
            this.db_tORA_txtport.Size = new System.Drawing.Size(60, 23);
            this.db_tORA_txtport.TabIndex = 12;
            this.db_tORA_txtport.Tag = "Account password";
            this.db_tORA_txtport.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.check_digit_number);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(306, 24);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 15);
            this.label16.TabIndex = 9;
            this.label16.Text = "Port";
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.AutoSize = true;
            this.button1.Location = new System.Drawing.Point(342, 83);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.button1.Size = new System.Drawing.Size(115, 27);
            this.button1.TabIndex = 14;
            this.button1.Tag = "";
            this.button1.Text = "Test connection";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // db_tORA_txtpwd
            // 
            this.db_tORA_txtpwd.Location = new System.Drawing.Point(342, 53);
            this.db_tORA_txtpwd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tORA_txtpwd.MaxLength = 50;
            this.db_tORA_txtpwd.Name = "db_tORA_txtpwd";
            this.db_tORA_txtpwd.PasswordChar = '*';
            this.db_tORA_txtpwd.Size = new System.Drawing.Size(107, 23);
            this.db_tORA_txtpwd.TabIndex = 13;
            this.db_tORA_txtpwd.Tag = "Account password";
            // 
            // db_tORA_txtname
            // 
            this.db_tORA_txtname.Location = new System.Drawing.Point(106, 53);
            this.db_tORA_txtname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tORA_txtname.MaxLength = 50;
            this.db_tORA_txtname.Name = "db_tORA_txtname";
            this.db_tORA_txtname.Size = new System.Drawing.Size(155, 23);
            this.db_tORA_txtname.TabIndex = 10;
            this.db_tORA_txtname.Tag = "Account name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 15);
            this.label9.TabIndex = 4;
            this.label9.Text = "Account name";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(275, 56);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 15);
            this.label10.TabIndex = 3;
            this.label10.Text = "Password";
            // 
            // db_tORA_txtsid
            // 
            this.db_tORA_txtsid.Location = new System.Drawing.Point(106, 85);
            this.db_tORA_txtsid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tORA_txtsid.MaxLength = 50;
            this.db_tORA_txtsid.Name = "db_tORA_txtsid";
            this.db_tORA_txtsid.Size = new System.Drawing.Size(211, 23);
            this.db_tORA_txtsid.TabIndex = 11;
            this.db_tORA_txtsid.Tag = "Server name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(75, 88);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 15);
            this.label11.TabIndex = 0;
            this.label11.Text = "SID";
            // 
            // db_tagetik
            // 
            this.db_tagetik.Controls.Add(this.db_t_btntest);
            this.db_tagetik.Controls.Add(this.db_tMS_txtpwd);
            this.db_tagetik.Controls.Add(this.db_tMS_txtname);
            this.db_tagetik.Controls.Add(this.db_t_lblname);
            this.db_tagetik.Controls.Add(this.db_t_lblpwd);
            this.db_tagetik.Controls.Add(this.db_tMS_txtserver);
            this.db_tagetik.Controls.Add(this.db_t_lblserver);
            this.db_tagetik.Location = new System.Drawing.Point(8, 10);
            this.db_tagetik.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tagetik.Name = "db_tagetik";
            this.db_tagetik.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tagetik.Size = new System.Drawing.Size(466, 90);
            this.db_tagetik.TabIndex = 1;
            this.db_tagetik.TabStop = false;
            this.db_tagetik.Text = "MS Server connection";
            // 
            // db_t_btntest
            // 
            this.db_t_btntest.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.db_t_btntest.AutoSize = true;
            this.db_t_btntest.Location = new System.Drawing.Point(343, 22);
            this.db_t_btntest.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_t_btntest.Name = "db_t_btntest";
            this.db_t_btntest.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.db_t_btntest.Size = new System.Drawing.Size(115, 27);
            this.db_t_btntest.TabIndex = 8;
            this.db_t_btntest.Tag = "";
            this.db_t_btntest.Text = "Test connection";
            this.db_t_btntest.UseVisualStyleBackColor = true;
            this.db_t_btntest.Click += new System.EventHandler(this.db_t_btntest_Click_1);
            // 
            // db_tMS_txtpwd
            // 
            this.db_tMS_txtpwd.Location = new System.Drawing.Point(343, 56);
            this.db_tMS_txtpwd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tMS_txtpwd.MaxLength = 50;
            this.db_tMS_txtpwd.Name = "db_tMS_txtpwd";
            this.db_tMS_txtpwd.PasswordChar = '*';
            this.db_tMS_txtpwd.Size = new System.Drawing.Size(107, 23);
            this.db_tMS_txtpwd.TabIndex = 7;
            this.db_tMS_txtpwd.Tag = "Account password";
            // 
            // db_tMS_txtname
            // 
            this.db_tMS_txtname.Location = new System.Drawing.Point(107, 56);
            this.db_tMS_txtname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tMS_txtname.MaxLength = 50;
            this.db_tMS_txtname.Name = "db_tMS_txtname";
            this.db_tMS_txtname.Size = new System.Drawing.Size(155, 23);
            this.db_tMS_txtname.TabIndex = 6;
            this.db_tMS_txtname.Tag = "Account name";
            // 
            // db_t_lblname
            // 
            this.db_t_lblname.AutoSize = true;
            this.db_t_lblname.Location = new System.Drawing.Point(16, 59);
            this.db_t_lblname.Name = "db_t_lblname";
            this.db_t_lblname.Size = new System.Drawing.Size(85, 15);
            this.db_t_lblname.TabIndex = 4;
            this.db_t_lblname.Text = "Account name";
            // 
            // db_t_lblpwd
            // 
            this.db_t_lblpwd.AutoSize = true;
            this.db_t_lblpwd.Location = new System.Drawing.Point(276, 59);
            this.db_t_lblpwd.Name = "db_t_lblpwd";
            this.db_t_lblpwd.Size = new System.Drawing.Size(57, 15);
            this.db_t_lblpwd.TabIndex = 3;
            this.db_t_lblpwd.Text = "Password";
            // 
            // db_tMS_txtserver
            // 
            this.db_tMS_txtserver.Location = new System.Drawing.Point(107, 24);
            this.db_tMS_txtserver.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.db_tMS_txtserver.MaxLength = 50;
            this.db_tMS_txtserver.Name = "db_tMS_txtserver";
            this.db_tMS_txtserver.Size = new System.Drawing.Size(211, 23);
            this.db_tMS_txtserver.TabIndex = 5;
            this.db_tMS_txtserver.Tag = "Server name";
            // 
            // db_t_lblserver
            // 
            this.db_t_lblserver.AutoSize = true;
            this.db_t_lblserver.Location = new System.Drawing.Point(26, 27);
            this.db_t_lblserver.Name = "db_t_lblserver";
            this.db_t_lblserver.Size = new System.Drawing.Size(72, 15);
            this.db_t_lblserver.TabIndex = 0;
            this.db_t_lblserver.Text = "Server name";
            // 
            // iceimport
            // 
            this.iceimport.Controls.Add(this.groupBox1);
            this.iceimport.Location = new System.Drawing.Point(4, 24);
            this.iceimport.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.iceimport.Name = "iceimport";
            this.iceimport.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.iceimport.Size = new System.Drawing.Size(482, 358);
            this.iceimport.TabIndex = 0;
            this.iceimport.Text = "ICE Import";
            this.iceimport.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ice_http);
            this.groupBox1.Controls.Add(this.ice_url2);
            this.groupBox1.Controls.Add(this.ice_pwd);
            this.groupBox1.Controls.Add(this.ice_username);
            this.groupBox1.Controls.Add(this.ice_url);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.ice_ip);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(8, 86);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(466, 187);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ICE connection";
            // 
            // ice_url2
            // 
            this.ice_url2.Location = new System.Drawing.Point(352, 130);
            this.ice_url2.Name = "ice_url2";
            this.ice_url2.Size = new System.Drawing.Size(100, 23);
            this.ice_url2.TabIndex = 18;
            // 
            // ice_pwd
            // 
            this.ice_pwd.Location = new System.Drawing.Point(158, 66);
            this.ice_pwd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ice_pwd.MaxLength = 50;
            this.ice_pwd.Name = "ice_pwd";
            this.ice_pwd.PasswordChar = '*';
            this.ice_pwd.Size = new System.Drawing.Size(155, 23);
            this.ice_pwd.TabIndex = 3;
            this.ice_pwd.Tag = "Account password";
            // 
            // ice_username
            // 
            this.ice_username.Location = new System.Drawing.Point(158, 34);
            this.ice_username.MaxLength = 50;
            this.ice_username.Name = "ice_username";
            this.ice_username.Size = new System.Drawing.Size(155, 23);
            this.ice_username.TabIndex = 2;
            // 
            // ice_url
            // 
            this.ice_url.Location = new System.Drawing.Point(203, 130);
            this.ice_url.MaxLength = 100;
            this.ice_url.Name = "ice_url";
            this.ice_url.ReadOnly = true;
            this.ice_url.Size = new System.Drawing.Size(145, 23);
            this.ice_url.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(90, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Username";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(72, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 15);
            this.label5.TabIndex = 17;
            this.label5.Text = "Resulting URL";
            // 
            // ice_ip
            // 
            this.ice_ip.Location = new System.Drawing.Point(158, 98);
            this.ice_ip.MaxLength = 16;
            this.ice_ip.Name = "ice_ip";
            this.ice_ip.Size = new System.Drawing.Size(109, 23);
            this.ice_ip.TabIndex = 4;
            this.ice_ip.TextChanged += new System.EventHandler(this.ice_ip_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(91, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 15);
            this.label2.TabIndex = 16;
            this.label2.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(87, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 15);
            this.label3.TabIndex = 11;
            this.label3.Text = "IP Address";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.iceimport);
            this.tabControl1.Controls.Add(this.tagetik);
            this.tabControl1.Controls.Add(this.fraudmanager);
            this.tabControl1.Controls.Add(this.dailyuw);
            this.tabControl1.Controls.Add(this.writeoff);
            this.tabControl1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(5, 4);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(490, 386);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControl1.TabIndex = 1;
            // 
            // ice_http
            // 
            this.ice_http.Location = new System.Drawing.Point(158, 130);
            this.ice_http.Name = "ice_http";
            this.ice_http.Size = new System.Drawing.Size(41, 23);
            this.ice_http.TabIndex = 19;
            // 
            // setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(500, 426);
            this.Controls.Add(this.btnSaveSetting);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "setting";
            this.ShowIcon = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Settings";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.setting_FormClosing);
            this.Load += new System.EventHandler(this.setting_Load);
            this.writeoff.ResumeLayout(false);
            this.db_writeoff.ResumeLayout(false);
            this.db_writeoff.PerformLayout();
            this.dailyuw.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.fraudmanager.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.db_fraud.ResumeLayout(false);
            this.db_fraud.PerformLayout();
            this.tagetik.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupOracle.ResumeLayout(false);
            this.groupOracle.PerformLayout();
            this.db_tagetik.ResumeLayout(false);
            this.db_tagetik.PerformLayout();
            this.iceimport.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox ice_pwd;
        private TextBox daily_pwd;
        private TextBox ice_url2;
        private TextBox ice_http;
    }
}