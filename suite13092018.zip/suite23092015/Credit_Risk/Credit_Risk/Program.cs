﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Credit_Risk
{
    static class Program
    {
        /// <summary>
        /// Punto di ingresso principale dell'applicazione.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Start start = new Start();
            start.ShowDialog();
            Application.Run(new Credit_Risk());
        }
    }
}
