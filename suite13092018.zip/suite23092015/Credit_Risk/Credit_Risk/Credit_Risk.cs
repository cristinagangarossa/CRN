﻿using Credit_risk_lib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Web;
using System.Windows.Forms;

namespace Credit_Risk
{
    public partial class Credit_Risk : Form
    {
        private string MsgError = "Parameters connection is not set";
        public Credit_Risk()
        {
            InitializeComponent();
            toolStripStatusLabel2.Text = "Suite Credit && Risk v" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
        }

        #region FraudManager

        private void averageFraudAmountVisaMCToolStripMenuItem_Click(object sender, EventArgs e)
        {

            new FraudManager.frmChart("AVERAGE_AMOUNT") { MdiParent = this }.Show();

        }

        private void averageTransactionsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            new FraudManager.frmChart("AVERAGE_TRANSACTIONS") { MdiParent = this }.Show();

        }

        private void binFixOndemandToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FraudManager.frmBinFix win = (Application.OpenForms["frmBinFix"] != null) ? ((FraudManager.frmBinFix)Application.OpenForms["frmBinFix"]) : null;
            if (win == null)
                new FraudManager.frmBinFix { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void browseDeleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FraudManager.frmBrowse win = (Application.OpenForms["frmBrowse"] != null) ? ((FraudManager.frmBrowse)Application.OpenForms["frmBrowse"]) : null;
            if (win == null)
                new FraudManager.frmBrowse { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void fraudTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            new FraudManager.FraudManager("FRAUD_TYPE") { MdiParent = this }.Show();

        }

        private void fromExcelMastercardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FraudManager.frmImportFromExcel win = (Application.OpenForms["frmImportFromExcel"] != null) ? ((FraudManager.frmImportFromExcel)Application.OpenForms["frmImportFromExcel"]) : null;
            if (win == null)
                new FraudManager.frmImportFromExcel { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void fromTextVisaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FraudManager.frmImportFromTxt win = (Application.OpenForms["frmImportFromTxt"] != null) ? ((FraudManager.frmImportFromTxt)Application.OpenForms["frmImportFromTxt"]) : null;
            if (win == null)
                new FraudManager.frmImportFromTxt { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void grossFraudAmountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FraudManager.frmChart("GROSS_FRAUD") { MdiParent = this }.Show();
        }

        private void grossFraudAmountVisMCToolStripMenuItem_Click(object sender, EventArgs e)
        {

            new FraudManager.frmChart("GROSS_FRAUD_VISA_MC") { MdiParent = this }.Show();

        }

        private void grossFraudToolStripMenuItem_Click(object sender, EventArgs e)
        {

            new FraudManager.FraudManager("GROSS_FRAUD") { MdiParent = this }.Show();

        }

        private void insertFraudToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FraudManager.frmEdit win = (Application.OpenForms["frmEdit"] != null) ? ((FraudManager.frmEdit)Application.OpenForms["frmEdit"]) : null;
            if (win == null)
                new FraudManager.frmEdit("NEW", "", "", null) { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void issuerStateToolStripMenuItem_Click(object sender, EventArgs e)
        {

            new FraudManager.FraudManager("ISSUER_STATE") { MdiParent = this }.Show();

        }

        private void mCCToolStripMenuItem_Click(object sender, EventArgs e)
        {

            new FraudManager.FraudManager("MCC") { MdiParent = this }.Show();

        }

        #endregion

        #region FraudIncident

        private void menu_fraud_incident_Click(object sender, EventArgs e)
        {
            if (!(sender as ToolStripMenuItem).Enabled)
            {
                MyMessage.showMessage(this.MsgError, MessageBoxIcon.Hand);
            }
        }

        private void syncToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FraudIncident.frmSync win = (Application.OpenForms["frmSync"] != null) ? ((FraudIncident.frmSync)Application.OpenForms["frmSync"]) : null;
            if (win == null)
                new FraudIncident.frmSync { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void browseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FraudIncident.frmBrowse win = (Application.OpenForms["frmBrowse"] != null) ? ((FraudIncident.frmBrowse)Application.OpenForms["frmBrowse"]) : null;
            if (win == null)
                new FraudIncident.frmBrowse { MdiParent = this }.Show();
            else
                win.Focus();
        }

        #endregion

        //Ice Import
        private void clickTempToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IceImport.IceStart win = (Application.OpenForms["IceStart"] != null) ? ((IceImport.IceStart)Application.OpenForms["IceStart"]) : null;
            if (win == null)
                new IceImport.IceStart { MdiParent = this }.Show();
            else
                win.Focus();
        }

        //Console
        private void consoleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*viewConsole win = (Application.OpenForms["viewConsole"] != null) ? ((viewConsole)Application.OpenForms["viewConsole"]) : null;
            if (win == null)
                new viewConsole().Show();
            else
                win.Focus();*/
            MyConsole.mostraCONSOLE.Show();
        }

        //Load
        private void Credit_Risk_Load(object sender, EventArgs e)
        {
            this.ManagerStateMenu();
        }

        //Close
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Close();
        }



        //Controlli iniziali
        private void ManagerStateMenu()
        {
            if (MyConnection.con_dailyuw == null)
            {
                this.menu_daily_uw.Enabled = false;
            }
            else
            {
                this.menu_daily_uw.Enabled = true;
            }
            if (MyConnection.con_ice_import == null)
            {
                this.menu_ice_import.Enabled = false;
                this.menu_downloadCSR.Enabled = false;
            }
            else
            {
                this.menu_ice_import.Enabled = true;
                this.menu_downloadCSR.Enabled = true;
            }
            if (string.IsNullOrWhiteSpace(MyConnection.con_string_db_writeoff))
            {
                this.menu_writeoff.Enabled = false;
                this.menu_dr.Enabled = false;
            }
            else
            {
                this.menu_writeoff.Enabled = true;
                this.menu_dr.Enabled = true;
            }
            if (string.IsNullOrWhiteSpace(MyConnection.con_string_db_fraud))
            {
                this.menu_fraud_incident.Enabled = false;
                this.menu_fraud_manager.Enabled = false;
            }
            else
            {
                this.menu_fraud_incident.Enabled = true;
                this.menu_fraud_manager.Enabled = true;
            }
            if (MyConnection.ftp_tagetik == null)
            {
                this.menu_ftp_client.Enabled = false;
            }
            else
            {
                this.menu_ftp_client.Enabled = true;
            }
            if (string.IsNullOrWhiteSpace(MyConnection.con_string_dbMS_tagetik))
            {//false default
                this.menu_Import_corporate.Enabled = true;
                this.menu_tagetik_import.Enabled = true;
            }
            else
            {
                this.menu_Import_corporate.Enabled = true;
                this.menu_tagetik_import.Enabled = true;
            }

            /*if (string.IsNullOrWhiteSpace(MyConnection.con_string_dbORA_tagetik))
            {
                this.menu_tagetik_import.Enabled = false;
            }
            else
            {
                this.menu_tagetik_import.Enabled = true;
            }*/
        }

        #region WriteOff

        private void cSRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WriteOff.csrReport win = (Application.OpenForms["csrReport"] != null) ? ((WriteOff.csrReport)Application.OpenForms["csrReport"]) : null;
            if (win == null)
                new WriteOff.csrReport { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void creacsr_packed(object sender, EventArgs e)
        {
            WriteOff.WriteOff win = (Application.OpenForms["WriteOff"] != null) ? ((WriteOff.WriteOff)Application.OpenForms["WriteOff"]) : null;
            if (win == null)
                new WriteOff.WriteOff((sender as ToolStripMenuItem).Tag.ToString(), "PACKED") { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void creacsr_unpacked(object sender, EventArgs e)
        {
            WriteOff.WriteOff win = (Application.OpenForms["WriteOff"] != null) ? ((WriteOff.WriteOff)Application.OpenForms["WriteOff"]) : null;
            if (win == null)
                new WriteOff.WriteOff((sender as ToolStripMenuItem).Tag.ToString(), "UNPACKED") { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void cSR3112ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WriteOff.csr3112 win = (Application.OpenForms["csr3112"] != null) ? ((WriteOff.csr3112)Application.OpenForms["csr3112"]) : null;
            if (win == null)
                new WriteOff.csr3112 { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void cSRMonthlyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WriteOff.csr win = (Application.OpenForms["csr"] != null) ? ((WriteOff.csr)Application.OpenForms["csr"]) : null;
            if (win == null)
                new WriteOff.csr { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void debtReconstructionToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            WriteOff.reconstruction win = (Application.OpenForms["reconstruction"] != null) ? ((WriteOff.reconstruction)Application.OpenForms["reconstruction"]) : null;
            if (win == null)
                new WriteOff.reconstruction { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void exploreMonthlyDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WriteOff.viewdata win = (Application.OpenForms["viewdata"] != null) ? ((WriteOff.viewdata)Application.OpenForms["viewdata"]) : null;
            if (win == null)
                new WriteOff.viewdata { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void exploreReportDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WriteOff.viewreport win = (Application.OpenForms["viewreport"] != null) ? ((WriteOff.viewreport)Application.OpenForms["viewreport"]) : null;
            if (win == null)
                new WriteOff.viewreport { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void writeOffListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WriteOff.writeoffList win = (Application.OpenForms["writeoffList"] != null) ? ((WriteOff.writeoffList)Application.OpenForms["writeoffList"]) : null;
            if (win == null)
                new WriteOff.writeoffList { MdiParent = this }.Show();
            else
                win.Focus();
        }


        #endregion

        //DailyUW
        private void dailyUWToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DailyUW.DailyUW win = (Application.OpenForms["DailyUW"] != null) ? ((DailyUW.DailyUW)Application.OpenForms["DailyUW"]) : null;
            if (win == null)
                new DailyUW.DailyUW { MdiParent = this }.Show();
            else
                win.Focus();
        }

        #region Tagetik
        private void downloadCSRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tagetik.downloadCSR win = (Application.OpenForms["downloadCSR"] != null) ? ((Tagetik.downloadCSR)Application.OpenForms["downloadCSR"]) : null;
            

            if (win == null)
                new Tagetik.downloadCSR { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void fixCSRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tagetik.fixCSR win = (Application.OpenForms["fixCSR"] != null) ? ((Tagetik.fixCSR)Application.OpenForms["fixCSR"]) : null;
            if (win == null)
                new Tagetik.fixCSR { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void fTPClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tagetik.frmFtp win = (Application.OpenForms["frmFtp"] != null) ? ((Tagetik.frmFtp)Application.OpenForms["frmFtp"]) : null;
            if (win == null)
                new Tagetik.frmFtp { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void importCorporateDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tagetik.frmCorporate win = (Application.OpenForms["frmCorporate"] != null) ? ((Tagetik.frmCorporate)Application.OpenForms["frmCorporate"]) : null;
            if (win == null)
                new Tagetik.frmCorporate { MdiParent = this }.Show();
            else
                win.Focus();
        }

        private void tagetikImportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Tagetik.TagetikImport win = (Application.OpenForms["TagetikImport"] != null) ? ((Tagetik.TagetikImport)Application.OpenForms["TagetikImport"]) : null;
            if (win == null)
                new Tagetik.TagetikImport { MdiParent = this }.Show();
            else
                win.Focus();
        }

        #endregion

        private void clickToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*for (int i = 0; i < 100; i++)
                MyConsole.enqueue("Label: " + i);*/

            //MessageBox.Show(MyConnection.con_string_db_fraud + " \n " + MyConnection.con_string_db_writeoff + " \n " + MyConnection.con_string_dbMS_tagetik + " \n " + MyConnection.con_string_dbORA_tagetik );

        }

        private void exportSettingToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void configureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            setting setting = new setting();
            setting.ShowDialog();
            this.ManagerStateMenu();
        }

        private void importToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            if (MyMessage.askMessage("Settings will be overwritten.\nConfirm?"))
            {
                OpenFileDialog win = new OpenFileDialog();
                if (win.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    try
                    {
                        Cursor.Current = Cursors.WaitCursor;
                        File.Copy(win.FileName, Application.StartupPath + "\\basic_settings.xml", true);
                        MyConnection.InizializeParameter_ice();
                        MyConnection.InizializeConnection_db_Fraud();
                        MyConnection.InizializeConnection_db_Writeoff();
                        MyConnection.InizializeParameter_dailyuw();
                        MyConnection.InizializeConnection_db_Tagetik_MS();
                        MyConnection.InizializeConnection_db_Tagetik_Oracle();
                        MyConnection.InizializeConnection_db_Tagetik_Ftp();
                        this.ManagerStateMenu();
                        Cursor.Current = Cursors.Default;
                        MyLogger.WriteLog("Import Settings");
                        MyMessage.showMessage("Import complete", MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MyMessage.showMessage("Error: " + ex.Message);
                    }
                }
            }
        }

        private void exportToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog win = new FolderBrowserDialog();
            if (win.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    File.Copy("basic_settings.xml", win.SelectedPath + "\\basic_settings.xml", true);
                    MyLogger.WriteLog("Export Settings");
                    MyMessage.showMessage("Export complete", MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Error: " + ex.Message);
                }
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MyMessage.showMessage("Credit & Risk\rrelease 1.3.0.1\rApr 2015\r\rDeveloped by NEPERIA GROUP\rfor BNL POSITIVITY Gruppo BNP Paribas\r\rinfo: antonio.schinina@neperiagroup.com", MessageBoxIcon.Information);
        }
    }
}
