﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace Credit_Risk
{
    partial class Credit_Risk
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem settingToolStripMenuItem;
        private ToolStripMenuItem menu_writeoff;
        private ToolStripMenuItem importToolStripMenuItem;
        private ToolStripMenuItem cSRMonthlyToolStripMenuItem;
        private ToolStripMenuItem writeOffListToolStripMenuItem;
        private ToolStripMenuItem viewToolStripMenuItem;
        private ToolStripMenuItem exploreMonthlyDataToolStripMenuItem;
        private ToolStripMenuItem exportToolStripMenuItem;
        private ToolStripMenuItem packedToolStripMenuItem;
        private ToolStripMenuItem unpackedToolStripMenuItem;
        private ToolStripMenuItem fRAUDToolStripMenuItem;
        private ToolStripMenuItem a10ToolStripMenuItem;
        private ToolStripMenuItem a10ToolStripMenuItem1;
        private ToolStripMenuItem eRRORToolStripMenuItem;
        private ToolStripMenuItem eXPORTALLToolStripMenuItem;
        private ToolStripMenuItem fRAUDToolStripMenuItem1;
        private ToolStripMenuItem a10ToolStripMenuItem2;
        private ToolStripMenuItem a10ToolStripMenuItem3;
        private ToolStripMenuItem eRRORToolStripMenuItem1;
        private ToolStripMenuItem eXPORTALLToolStripMenuItem1;
        private ToolStripMenuItem viewToolStripMenuItem1;
        private ToolStripMenuItem consoleToolStripMenuItem;
        private ToolStripMenuItem menu_ice_import;
        private ToolStripMenuItem menu_daily_uw;
        private ToolStripMenuItem strumentiToolStripMenuItem;
        private ToolStripMenuItem menu_tagetik_import;
        private ToolStripMenuItem menu_downloadCSR;
        private ToolStripMenuItem menu_Import_corporate;
        private ToolStripMenuItem menu_ftp_client;
        private ToolStripMenuItem fixCSRToolStripMenuItem;
        private ToolStripMenuItem menu_fraud_incident;
        private ToolStripMenuItem syncToolStripMenuItem;
        private ToolStripMenuItem browseToolStripMenuItem;
        private ToolStripMenuItem menu_fraud_manager;
        private ToolStripMenuItem importToolStripMenuItem1;
        private ToolStripMenuItem fromExcelMastercardToolStripMenuItem;
        private ToolStripMenuItem fromTextVisaToolStripMenuItem;
        private ToolStripMenuItem databaseToolStripMenuItem;
        private ToolStripMenuItem insertFraudToolStripMenuItem;
        private ToolStripMenuItem browseDeleteToolStripMenuItem;
        private ToolStripMenuItem binFixOndemandToolStripMenuItem;
        private ToolStripMenuItem reportToolStripMenuItem;
        private ToolStripMenuItem fraudTypeToolStripMenuItem;
        private ToolStripMenuItem mCCToolStripMenuItem;
        private ToolStripMenuItem issuerStateToolStripMenuItem;
        private ToolStripMenuItem grossFraudToolStripMenuItem;
        private ToolStripMenuItem chartsToolStripMenuItem;
        private ToolStripMenuItem grossFraudAmountToolStripMenuItem;
        private ToolStripMenuItem grossFraudAmountVisMCToolStripMenuItem;
        private ToolStripMenuItem averageFraudAmountVisaMCToolStripMenuItem;
        private ToolStripMenuItem averageTransactionsToolStripMenuItem;
        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Credit_Risk));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.configureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_ice_import = new System.Windows.Forms.ToolStripMenuItem();
            this.strumentiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_tagetik_import = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_downloadCSR = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_Import_corporate = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_ftp_client = new System.Windows.Forms.ToolStripMenuItem();
            this.fixCSRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_fraud_manager = new System.Windows.Forms.ToolStripMenuItem();
            this.importToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fromExcelMastercardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fromTextVisaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertFraudToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.browseDeleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.binFixOndemandToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fraudTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mCCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.issuerStateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grossFraudToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chartsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grossFraudAmountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grossFraudAmountVisMCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.averageFraudAmountVisaMCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.averageTransactionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_daily_uw = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_fraud_incident = new System.Windows.Forms.ToolStripMenuItem();
            this.syncToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.browseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_writeoff = new System.Windows.Forms.ToolStripMenuItem();
            this.importToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cSRMonthlyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writeOffListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exploreMonthlyDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.packedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fRAUDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.a10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.a10ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.eRRORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXPORTALLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unpackedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fRAUDToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.a10ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.a10ToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.eRRORToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.eXPORTALLToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.consoleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menu_dr = new System.Windows.Forms.ToolStripMenuItem();
            this.importToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.cSR3112ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cSRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exploreReportDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.debtReconstructionToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.menu_ice_import,
            this.strumentiToolStripMenuItem,
            this.menu_fraud_manager,
            this.menu_daily_uw,
            this.menu_fraud_incident,
            this.menu_writeoff,
            this.menu_dr,
            this.viewToolStripMenuItem1,
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(844, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importToolStripMenuItem2,
            this.exportToolStripMenuItem1,
            this.configureToolStripMenuItem});
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.settingToolStripMenuItem.Text = "&Settings";
            // 
            // importToolStripMenuItem2
            // 
            this.importToolStripMenuItem2.Name = "importToolStripMenuItem2";
            this.importToolStripMenuItem2.Size = new System.Drawing.Size(127, 22);
            this.importToolStripMenuItem2.Text = "Import";
            this.importToolStripMenuItem2.Click += new System.EventHandler(this.importToolStripMenuItem2_Click);
            // 
            // exportToolStripMenuItem1
            // 
            this.exportToolStripMenuItem1.Name = "exportToolStripMenuItem1";
            this.exportToolStripMenuItem1.Size = new System.Drawing.Size(127, 22);
            this.exportToolStripMenuItem1.Text = "Export";
            this.exportToolStripMenuItem1.Click += new System.EventHandler(this.exportToolStripMenuItem1_Click);
            // 
            // configureToolStripMenuItem
            // 
            this.configureToolStripMenuItem.Name = "configureToolStripMenuItem";
            this.configureToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.configureToolStripMenuItem.Text = "Configure";
            this.configureToolStripMenuItem.Click += new System.EventHandler(this.configureToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // menu_ice_import
            // 
            this.menu_ice_import.Name = "menu_ice_import";
            this.menu_ice_import.Size = new System.Drawing.Size(73, 20);
            this.menu_ice_import.Text = "&Ice Import";
            this.menu_ice_import.Click += new System.EventHandler(this.clickTempToolStripMenuItem_Click);
            // 
            // strumentiToolStripMenuItem
            // 
            this.strumentiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_tagetik_import,
            this.menu_downloadCSR,
            this.menu_Import_corporate,
            this.menu_ftp_client,
            this.fixCSRToolStripMenuItem});
            this.strumentiToolStripMenuItem.Name = "strumentiToolStripMenuItem";
            this.strumentiToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.strumentiToolStripMenuItem.Text = "&Tagetik";
            // 
            // menu_tagetik_import
            // 
            this.menu_tagetik_import.Name = "menu_tagetik_import";
            this.menu_tagetik_import.Size = new System.Drawing.Size(192, 22);
            this.menu_tagetik_import.Text = "&Tagetik Import";
            this.menu_tagetik_import.Click += new System.EventHandler(this.tagetikImportToolStripMenuItem_Click);
            // 
            // menu_downloadCSR
            // 
            this.menu_downloadCSR.Name = "menu_downloadCSR";
            this.menu_downloadCSR.Size = new System.Drawing.Size(192, 22);
            this.menu_downloadCSR.Text = "&CSR download";
            this.menu_downloadCSR.Click += new System.EventHandler(this.downloadCSRToolStripMenuItem_Click);
            // 
            // menu_Import_corporate
            // 
            this.menu_Import_corporate.Name = "menu_Import_corporate";
            this.menu_Import_corporate.Size = new System.Drawing.Size(192, 22);
            this.menu_Import_corporate.Text = "&Import Corporate data";
            this.menu_Import_corporate.Click += new System.EventHandler(this.importCorporateDataToolStripMenuItem_Click);
            // 
            // menu_ftp_client
            // 
            this.menu_ftp_client.Name = "menu_ftp_client";
            this.menu_ftp_client.Size = new System.Drawing.Size(192, 22);
            this.menu_ftp_client.Text = "&FTP Client";
            this.menu_ftp_client.Click += new System.EventHandler(this.fTPClientToolStripMenuItem_Click);
            // 
            // fixCSRToolStripMenuItem
            // 
            this.fixCSRToolStripMenuItem.Name = "fixCSRToolStripMenuItem";
            this.fixCSRToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.fixCSRToolStripMenuItem.Text = "&Fix CSR";
            this.fixCSRToolStripMenuItem.Click += new System.EventHandler(this.fixCSRToolStripMenuItem_Click);
            // 
            // menu_fraud_manager
            // 
            this.menu_fraud_manager.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importToolStripMenuItem1,
            this.databaseToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.chartsToolStripMenuItem});
            this.menu_fraud_manager.Name = "menu_fraud_manager";
            this.menu_fraud_manager.Size = new System.Drawing.Size(99, 20);
            this.menu_fraud_manager.Text = "&Fraud Manager";
            // 
            // importToolStripMenuItem1
            // 
            this.importToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fromExcelMastercardToolStripMenuItem,
            this.fromTextVisaToolStripMenuItem});
            this.importToolStripMenuItem1.Name = "importToolStripMenuItem1";
            this.importToolStripMenuItem1.Size = new System.Drawing.Size(122, 22);
            this.importToolStripMenuItem1.Text = "&Import";
            // 
            // fromExcelMastercardToolStripMenuItem
            // 
            this.fromExcelMastercardToolStripMenuItem.Name = "fromExcelMastercardToolStripMenuItem";
            this.fromExcelMastercardToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.fromExcelMastercardToolStripMenuItem.Text = "From &Excel (Mastercard)";
            this.fromExcelMastercardToolStripMenuItem.Click += new System.EventHandler(this.fromExcelMastercardToolStripMenuItem_Click);
            // 
            // fromTextVisaToolStripMenuItem
            // 
            this.fromTextVisaToolStripMenuItem.Name = "fromTextVisaToolStripMenuItem";
            this.fromTextVisaToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.fromTextVisaToolStripMenuItem.Text = "From &Text (Visa)";
            this.fromTextVisaToolStripMenuItem.Click += new System.EventHandler(this.fromTextVisaToolStripMenuItem_Click);
            // 
            // databaseToolStripMenuItem
            // 
            this.databaseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.insertFraudToolStripMenuItem,
            this.browseDeleteToolStripMenuItem,
            this.binFixOndemandToolStripMenuItem});
            this.databaseToolStripMenuItem.Name = "databaseToolStripMenuItem";
            this.databaseToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.databaseToolStripMenuItem.Text = "&Database";
            // 
            // insertFraudToolStripMenuItem
            // 
            this.insertFraudToolStripMenuItem.Name = "insertFraudToolStripMenuItem";
            this.insertFraudToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.insertFraudToolStripMenuItem.Text = "&Insert fraud";
            this.insertFraudToolStripMenuItem.Click += new System.EventHandler(this.insertFraudToolStripMenuItem_Click);
            // 
            // browseDeleteToolStripMenuItem
            // 
            this.browseDeleteToolStripMenuItem.Name = "browseDeleteToolStripMenuItem";
            this.browseDeleteToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.browseDeleteToolStripMenuItem.Text = "&Browse\\Delete";
            this.browseDeleteToolStripMenuItem.Click += new System.EventHandler(this.browseDeleteToolStripMenuItem_Click);
            // 
            // binFixOndemandToolStripMenuItem
            // 
            this.binFixOndemandToolStripMenuItem.Name = "binFixOndemandToolStripMenuItem";
            this.binFixOndemandToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.binFixOndemandToolStripMenuItem.Text = "Bin-&Fix on-demand";
            this.binFixOndemandToolStripMenuItem.Click += new System.EventHandler(this.binFixOndemandToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fraudTypeToolStripMenuItem,
            this.mCCToolStripMenuItem,
            this.issuerStateToolStripMenuItem,
            this.grossFraudToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.reportToolStripMenuItem.Text = "&Report";
            // 
            // fraudTypeToolStripMenuItem
            // 
            this.fraudTypeToolStripMenuItem.Name = "fraudTypeToolStripMenuItem";
            this.fraudTypeToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.fraudTypeToolStripMenuItem.Text = "&Fraud type";
            this.fraudTypeToolStripMenuItem.Click += new System.EventHandler(this.fraudTypeToolStripMenuItem_Click);
            // 
            // mCCToolStripMenuItem
            // 
            this.mCCToolStripMenuItem.Name = "mCCToolStripMenuItem";
            this.mCCToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.mCCToolStripMenuItem.Text = "&MCC";
            this.mCCToolStripMenuItem.Click += new System.EventHandler(this.mCCToolStripMenuItem_Click);
            // 
            // issuerStateToolStripMenuItem
            // 
            this.issuerStateToolStripMenuItem.Name = "issuerStateToolStripMenuItem";
            this.issuerStateToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.issuerStateToolStripMenuItem.Text = "&Issuer State";
            this.issuerStateToolStripMenuItem.Click += new System.EventHandler(this.issuerStateToolStripMenuItem_Click);
            // 
            // grossFraudToolStripMenuItem
            // 
            this.grossFraudToolStripMenuItem.Name = "grossFraudToolStripMenuItem";
            this.grossFraudToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.grossFraudToolStripMenuItem.Text = "&Gross fraud";
            this.grossFraudToolStripMenuItem.Click += new System.EventHandler(this.grossFraudToolStripMenuItem_Click);
            // 
            // chartsToolStripMenuItem
            // 
            this.chartsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.grossFraudAmountToolStripMenuItem,
            this.grossFraudAmountVisMCToolStripMenuItem,
            this.averageFraudAmountVisaMCToolStripMenuItem,
            this.averageTransactionsToolStripMenuItem});
            this.chartsToolStripMenuItem.Name = "chartsToolStripMenuItem";
            this.chartsToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.chartsToolStripMenuItem.Text = "&Charts";
            // 
            // grossFraudAmountToolStripMenuItem
            // 
            this.grossFraudAmountToolStripMenuItem.Name = "grossFraudAmountToolStripMenuItem";
            this.grossFraudAmountToolStripMenuItem.Size = new System.Drawing.Size(241, 22);
            this.grossFraudAmountToolStripMenuItem.Text = "Gross fraud &amount";
            this.grossFraudAmountToolStripMenuItem.Click += new System.EventHandler(this.grossFraudAmountToolStripMenuItem_Click);
            // 
            // grossFraudAmountVisMCToolStripMenuItem
            // 
            this.grossFraudAmountVisMCToolStripMenuItem.Name = "grossFraudAmountVisMCToolStripMenuItem";
            this.grossFraudAmountVisMCToolStripMenuItem.Size = new System.Drawing.Size(241, 22);
            this.grossFraudAmountVisMCToolStripMenuItem.Text = "Gross fraud amount &Visa/MC";
            this.grossFraudAmountVisMCToolStripMenuItem.Click += new System.EventHandler(this.grossFraudAmountVisMCToolStripMenuItem_Click);
            // 
            // averageFraudAmountVisaMCToolStripMenuItem
            // 
            this.averageFraudAmountVisaMCToolStripMenuItem.Name = "averageFraudAmountVisaMCToolStripMenuItem";
            this.averageFraudAmountVisaMCToolStripMenuItem.Size = new System.Drawing.Size(241, 22);
            this.averageFraudAmountVisaMCToolStripMenuItem.Text = "Average &fraud amount Visa/MC";
            this.averageFraudAmountVisaMCToolStripMenuItem.Click += new System.EventHandler(this.averageFraudAmountVisaMCToolStripMenuItem_Click);
            // 
            // averageTransactionsToolStripMenuItem
            // 
            this.averageTransactionsToolStripMenuItem.Name = "averageTransactionsToolStripMenuItem";
            this.averageTransactionsToolStripMenuItem.Size = new System.Drawing.Size(241, 22);
            this.averageTransactionsToolStripMenuItem.Text = "Average &transactions";
            this.averageTransactionsToolStripMenuItem.Click += new System.EventHandler(this.averageTransactionsToolStripMenuItem_Click);
            // 
            // menu_daily_uw
            // 
            this.menu_daily_uw.Name = "menu_daily_uw";
            this.menu_daily_uw.Size = new System.Drawing.Size(67, 20);
            this.menu_daily_uw.Text = "&Daily UW";
            this.menu_daily_uw.Click += new System.EventHandler(this.dailyUWToolStripMenuItem_Click);
            // 
            // menu_fraud_incident
            // 
            this.menu_fraud_incident.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.syncToolStripMenuItem,
            this.browseToolStripMenuItem});
            this.menu_fraud_incident.Name = "menu_fraud_incident";
            this.menu_fraud_incident.Size = new System.Drawing.Size(95, 20);
            this.menu_fraud_incident.Text = "&Fraud Incident";
            this.menu_fraud_incident.Click += new System.EventHandler(this.menu_fraud_incident_Click);
            // 
            // syncToolStripMenuItem
            // 
            this.syncToolStripMenuItem.Name = "syncToolStripMenuItem";
            this.syncToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.syncToolStripMenuItem.Text = "&Sync";
            this.syncToolStripMenuItem.Click += new System.EventHandler(this.syncToolStripMenuItem_Click);
            // 
            // browseToolStripMenuItem
            // 
            this.browseToolStripMenuItem.Name = "browseToolStripMenuItem";
            this.browseToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.browseToolStripMenuItem.Text = "&Browse";
            this.browseToolStripMenuItem.Click += new System.EventHandler(this.browseToolStripMenuItem_Click);
            // 
            // menu_writeoff
            // 
            this.menu_writeoff.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.exportToolStripMenuItem});
            this.menu_writeoff.Name = "menu_writeoff";
            this.menu_writeoff.Size = new System.Drawing.Size(64, 20);
            this.menu_writeoff.Text = "&WriteOff";
            // 
            // importToolStripMenuItem
            // 
            this.importToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cSRMonthlyToolStripMenuItem,
            this.writeOffListToolStripMenuItem});
            this.importToolStripMenuItem.Name = "importToolStripMenuItem";
            this.importToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.importToolStripMenuItem.Text = "&Import";
            // 
            // cSRMonthlyToolStripMenuItem
            // 
            this.cSRMonthlyToolStripMenuItem.Name = "cSRMonthlyToolStripMenuItem";
            this.cSRMonthlyToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cSRMonthlyToolStripMenuItem.Text = "CSR &Monthly";
            this.cSRMonthlyToolStripMenuItem.Click += new System.EventHandler(this.cSRMonthlyToolStripMenuItem_Click);
            // 
            // writeOffListToolStripMenuItem
            // 
            this.writeOffListToolStripMenuItem.Name = "writeOffListToolStripMenuItem";
            this.writeOffListToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.writeOffListToolStripMenuItem.Text = "&WriteOff List";
            this.writeOffListToolStripMenuItem.Click += new System.EventHandler(this.writeOffListToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exploreMonthlyDataToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.viewToolStripMenuItem.Text = "&View";
            // 
            // exploreMonthlyDataToolStripMenuItem
            // 
            this.exploreMonthlyDataToolStripMenuItem.Name = "exploreMonthlyDataToolStripMenuItem";
            this.exploreMonthlyDataToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.exploreMonthlyDataToolStripMenuItem.Text = "Explore &monthly data";
            this.exploreMonthlyDataToolStripMenuItem.Click += new System.EventHandler(this.exploreMonthlyDataToolStripMenuItem_Click);
            // 
            // exportToolStripMenuItem
            // 
            this.exportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.packedToolStripMenuItem,
            this.unpackedToolStripMenuItem});
            this.exportToolStripMenuItem.Name = "exportToolStripMenuItem";
            this.exportToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exportToolStripMenuItem.Text = "&Export";
            // 
            // packedToolStripMenuItem
            // 
            this.packedToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fRAUDToolStripMenuItem,
            this.a10ToolStripMenuItem,
            this.a10ToolStripMenuItem1,
            this.eRRORToolStripMenuItem,
            this.eXPORTALLToolStripMenuItem});
            this.packedToolStripMenuItem.Name = "packedToolStripMenuItem";
            this.packedToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.packedToolStripMenuItem.Text = "&Packed";
            // 
            // fRAUDToolStripMenuItem
            // 
            this.fRAUDToolStripMenuItem.Name = "fRAUDToolStripMenuItem";
            this.fRAUDToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.fRAUDToolStripMenuItem.Tag = "54002";
            this.fRAUDToolStripMenuItem.Text = "54002 (&FRAUD)";
            this.fRAUDToolStripMenuItem.Click += new System.EventHandler(this.creacsr_packed);
            // 
            // a10ToolStripMenuItem
            // 
            this.a10ToolStripMenuItem.Name = "a10ToolStripMenuItem";
            this.a10ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.a10ToolStripMenuItem.Tag = "54008";
            this.a10ToolStripMenuItem.Text = "5400&8 (A. < 10)";
            this.a10ToolStripMenuItem.Click += new System.EventHandler(this.creacsr_packed);
            // 
            // a10ToolStripMenuItem1
            // 
            this.a10ToolStripMenuItem1.Name = "a10ToolStripMenuItem1";
            this.a10ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.a10ToolStripMenuItem1.Tag = "53202";
            this.a10ToolStripMenuItem1.Text = "5320&2 (A. > 10)";
            this.a10ToolStripMenuItem1.Click += new System.EventHandler(this.creacsr_packed);
            // 
            // eRRORToolStripMenuItem
            // 
            this.eRRORToolStripMenuItem.Name = "eRRORToolStripMenuItem";
            this.eRRORToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.eRRORToolStripMenuItem.Tag = "51101";
            this.eRRORToolStripMenuItem.Text = "51101 (&ERROR)";
            this.eRRORToolStripMenuItem.Click += new System.EventHandler(this.creacsr_packed);
            // 
            // eXPORTALLToolStripMenuItem
            // 
            this.eXPORTALLToolStripMenuItem.Name = "eXPORTALLToolStripMenuItem";
            this.eXPORTALLToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.eXPORTALLToolStripMenuItem.Tag = "All";
            this.eXPORTALLToolStripMenuItem.Text = "EXPORT &ALL";
            this.eXPORTALLToolStripMenuItem.Click += new System.EventHandler(this.creacsr_packed);
            // 
            // unpackedToolStripMenuItem
            // 
            this.unpackedToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fRAUDToolStripMenuItem1,
            this.a10ToolStripMenuItem2,
            this.a10ToolStripMenuItem3,
            this.eRRORToolStripMenuItem1,
            this.eXPORTALLToolStripMenuItem1});
            this.unpackedToolStripMenuItem.Name = "unpackedToolStripMenuItem";
            this.unpackedToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.unpackedToolStripMenuItem.Text = "&Unpacked";
            // 
            // fRAUDToolStripMenuItem1
            // 
            this.fRAUDToolStripMenuItem1.Name = "fRAUDToolStripMenuItem1";
            this.fRAUDToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.fRAUDToolStripMenuItem1.Tag = "54002";
            this.fRAUDToolStripMenuItem1.Text = "54002 (&FRAUD)";
            this.fRAUDToolStripMenuItem1.Click += new System.EventHandler(this.creacsr_unpacked);
            // 
            // a10ToolStripMenuItem2
            // 
            this.a10ToolStripMenuItem2.Name = "a10ToolStripMenuItem2";
            this.a10ToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.a10ToolStripMenuItem2.Tag = "54008";
            this.a10ToolStripMenuItem2.Text = "5400&8 (A. < 10)";
            this.a10ToolStripMenuItem2.Click += new System.EventHandler(this.creacsr_unpacked);
            // 
            // a10ToolStripMenuItem3
            // 
            this.a10ToolStripMenuItem3.Name = "a10ToolStripMenuItem3";
            this.a10ToolStripMenuItem3.Size = new System.Drawing.Size(152, 22);
            this.a10ToolStripMenuItem3.Tag = "53202";
            this.a10ToolStripMenuItem3.Text = "5320&2 (A. > 10)";
            this.a10ToolStripMenuItem3.Click += new System.EventHandler(this.creacsr_unpacked);
            // 
            // eRRORToolStripMenuItem1
            // 
            this.eRRORToolStripMenuItem1.Name = "eRRORToolStripMenuItem1";
            this.eRRORToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.eRRORToolStripMenuItem1.Tag = "51101";
            this.eRRORToolStripMenuItem1.Text = "51101 (&ERROR)";
            this.eRRORToolStripMenuItem1.Click += new System.EventHandler(this.creacsr_unpacked);
            // 
            // eXPORTALLToolStripMenuItem1
            // 
            this.eXPORTALLToolStripMenuItem1.Name = "eXPORTALLToolStripMenuItem1";
            this.eXPORTALLToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.eXPORTALLToolStripMenuItem1.Tag = "All";
            this.eXPORTALLToolStripMenuItem1.Text = "EXPORT &ALL";
            this.eXPORTALLToolStripMenuItem1.Click += new System.EventHandler(this.creacsr_unpacked);
            // 
            // viewToolStripMenuItem1
            // 
            this.viewToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consoleToolStripMenuItem});
            this.viewToolStripMenuItem1.Name = "viewToolStripMenuItem1";
            this.viewToolStripMenuItem1.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem1.Text = "&View";
            // 
            // consoleToolStripMenuItem
            // 
            this.consoleToolStripMenuItem.Name = "consoleToolStripMenuItem";
            this.consoleToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.consoleToolStripMenuItem.Text = "&Console";
            this.consoleToolStripMenuItem.Click += new System.EventHandler(this.consoleToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 445);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.statusStrip1.Size = new System.Drawing.Size(844, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(145, 17);
            this.toolStripStatusLabel2.Text = "Suite Credit and Risk v. 1.3";
            this.toolStripStatusLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // menu_dr
            // 
            this.menu_dr.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importToolStripMenuItem3,
            this.viewToolStripMenuItem2,
            this.exportToolStripMenuItem2,
            this.debtReconstructionToolStripMenuItem1});
            this.menu_dr.Name = "menu_dr";
            this.menu_dr.Size = new System.Drawing.Size(127, 20);
            this.menu_dr.Text = "Debt &Reconstruction";
            // 
            // importToolStripMenuItem3
            // 
            this.importToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cSR3112ToolStripMenuItem,
            this.cSRToolStripMenuItem});
            this.importToolStripMenuItem3.Name = "importToolStripMenuItem3";
            this.importToolStripMenuItem3.Size = new System.Drawing.Size(160, 22);
            this.importToolStripMenuItem3.Text = "&Import";
            // 
            // cSR3112ToolStripMenuItem
            // 
            this.cSR3112ToolStripMenuItem.Name = "cSR3112ToolStripMenuItem";
            this.cSR3112ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cSR3112ToolStripMenuItem.Text = "CSR &31/12";
            this.cSR3112ToolStripMenuItem.Click += new System.EventHandler(this.cSR3112ToolStripMenuItem_Click);
            // 
            // cSRToolStripMenuItem
            // 
            this.cSRToolStripMenuItem.Name = "cSRToolStripMenuItem";
            this.cSRToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cSRToolStripMenuItem.Text = "CSR &Report";
            this.cSRToolStripMenuItem.Click += new System.EventHandler(this.cSRToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem2
            // 
            this.viewToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exploreReportDataToolStripMenuItem});
            this.viewToolStripMenuItem2.Name = "viewToolStripMenuItem2";
            this.viewToolStripMenuItem2.Size = new System.Drawing.Size(160, 22);
            this.viewToolStripMenuItem2.Text = "&View";
            // 
            // exploreReportDataToolStripMenuItem
            // 
            this.exploreReportDataToolStripMenuItem.Name = "exploreReportDataToolStripMenuItem";
            this.exploreReportDataToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.exploreReportDataToolStripMenuItem.Text = "Explore &report data";
            this.exploreReportDataToolStripMenuItem.Click += new System.EventHandler(this.exploreReportDataToolStripMenuItem_Click);
            // 
            // exportToolStripMenuItem2
            // 
            this.exportToolStripMenuItem2.Name = "exportToolStripMenuItem2";
            this.exportToolStripMenuItem2.Size = new System.Drawing.Size(157, 6);
            // 
            // debtReconstructionToolStripMenuItem1
            // 
            this.debtReconstructionToolStripMenuItem1.Name = "debtReconstructionToolStripMenuItem1";
            this.debtReconstructionToolStripMenuItem1.Size = new System.Drawing.Size(160, 22);
            this.debtReconstructionToolStripMenuItem1.Text = "&Export DR report";
            this.debtReconstructionToolStripMenuItem1.Click += new System.EventHandler(this.debtReconstructionToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(24, 20);
            this.toolStripMenuItem1.Text = "&?";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // Credit_Risk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(844, 467);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MinimumSize = new System.Drawing.Size(558, 456);
            this.Name = "Credit_Risk";
            this.Text = "Credit & Risk";
            this.Load += new System.EventHandler(this.Credit_Risk_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel2;
        private ToolStripMenuItem importToolStripMenuItem2;
        private ToolStripMenuItem exportToolStripMenuItem1;
        private ToolStripMenuItem configureToolStripMenuItem;
        private ToolStripMenuItem menu_dr;
        private ToolStripMenuItem importToolStripMenuItem3;
        private ToolStripMenuItem cSR3112ToolStripMenuItem;
        private ToolStripMenuItem cSRToolStripMenuItem;
        private ToolStripMenuItem viewToolStripMenuItem2;
        private ToolStripMenuItem exploreReportDataToolStripMenuItem;
        private ToolStripSeparator exportToolStripMenuItem2;
        private ToolStripMenuItem debtReconstructionToolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem1;
    }
}

