﻿using Credit_risk_lib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace Credit_Risk
{
    public partial class setting : Form
    {
        public setting()
        {
            InitializeComponent();
        }

        private void btnSaveSetting_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                XDocument xDocument = XDocument.Parse(MyConnection.decrypt(File.ReadAllText("basic_settings.xml")));
               //XDocument xDocument = XDocument.Parse(File.ReadAllText("basic_settings.xml"));
                xDocument.Root.Element("connectionString_fraud").Attribute("source").Value = this.db_f_txtserver.Text.Trim();
                xDocument.Root.Element("connectionString_fraud").Attribute("username").Value = this.db_f_txtname.Text.Trim();
                xDocument.Root.Element("connectionString_fraud").Attribute("pwd").Value = this.db_f_txtpwd.Text.Trim();
                xDocument.Root.Element("connectionString_writeoff").Attribute("source").Value = this.db_w_txtserver.Text.Trim();
                xDocument.Root.Element("connectionString_writeoff").Attribute("username").Value = this.db_w_txtname.Text.Trim();
                xDocument.Root.Element("connectionString_writeoff").Attribute("pwd").Value = this.db_w_txtpwd.Text.Trim();
                xDocument.Root.Element("connectionICE").Attribute("username").Value = this.ice_username.Text;
                xDocument.Root.Element("connectionICE").Attribute("pwd").Value = this.ice_pwd.Text;
                xDocument.Root.Element("connectionICE").Attribute("ip").Value = this.ice_ip.Text;
                //CRI 16092015 s
                xDocument.Root.Element("connectionICE").Attribute("http").Value = this.ice_http.Text;
                xDocument.Root.Element("connectionICE").Attribute("url2").Value = this.ice_url2.Text;
                //CRI 16092015 e
                xDocument.Root.Element("connectionDailyUW").Attribute("username").Value = this.daily_username.Text;
                xDocument.Root.Element("connectionDailyUW").Attribute("pwd").Value = this.daily_pwd.Text;
                xDocument.Root.Element("connectionDailyUW").Attribute("ip").Value = this.daily_ip.Text;
                xDocument.Root.Element("connectionString_tagetikMS").Attribute("source").Value = this.db_tMS_txtserver.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikMS").Attribute("username").Value = this.db_tMS_txtname.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikMS").Attribute("pwd").Value = this.db_tMS_txtpwd.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikOracle").Attribute("host").Value = this.db_tORA_txthost.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikOracle").Attribute("port").Value = this.db_tORA_txtport.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikOracle").Attribute("username").Value = this.db_tORA_txtname.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikOracle").Attribute("pwd").Value = this.db_tORA_txtpwd.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikOracle").Attribute("sid").Value = this.db_tORA_txtsid.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikFTP").Attribute("host").Value = this.db_tFTP_txthost.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikFTP").Attribute("port").Value = this.db_tFTP_txtport.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikFTP").Attribute("username").Value = this.db_tFTP_txtname.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikFTP").Attribute("pwd").Value = this.db_tFTP_txtpwd.Text.Trim();
                xDocument.Root.Element("connectionString_tagetikFTP").Attribute("path").Value = this.db_tFTP_txtpath.Text.Trim();
                xDocument.Root.Element("RAMcredential").Attribute("username").Value = this.ram_username.Text.Trim();
                xDocument.Root.Element("RAMcredential").Attribute("pwd").Value = this.ram_password.Text.Trim();

                using (XmlReader xmlReader = xDocument.CreateReader())
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.Load(xmlReader);
                    if (xDocument.Declaration != null)
                    {
                        XmlDeclaration dec = xmlDoc.CreateXmlDeclaration(xDocument.Declaration.Version, xDocument.Declaration.Encoding, xDocument.Declaration.Standalone);
                        xmlDoc.InsertBefore(dec, xmlDoc.FirstChild);
                    }
                    
                    File.WriteAllText("basic_settings.xml", MyConnection.crypta(xmlDoc.OuterXml));
                    //File.WriteAllText("basic_settings.xml",xmlDoc.OuterXml);
                }               
                
               
                Cursor.Current = Cursors.Default;
                base.Close();
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
                MyConsole.enqueue("Error: " + ex.Message);
                MyLogger.WriteLog(this.Text + " Error: " + ex.Message);
            }
        }
        private void setting_Load(object sender, EventArgs e)
        {
            XDocument xDocument = XDocument.Parse(MyConnection.decrypt(File.ReadAllText("basic_settings.xml")));
           // XDocument xDocument = XDocument.Parse(File.ReadAllText("basic_settings.xml"));
            this.db_f_txtserver.Text = xDocument.Root.Element("connectionString_fraud").Attribute("source").Value;
            this.db_f_txtname.Text = xDocument.Root.Element("connectionString_fraud").Attribute("username").Value;
            this.db_f_txtpwd.Text = xDocument.Root.Element("connectionString_fraud").Attribute("pwd").Value;
            this.db_w_txtserver.Text = xDocument.Root.Element("connectionString_writeoff").Attribute("source").Value;
            this.db_w_txtname.Text = xDocument.Root.Element("connectionString_writeoff").Attribute("username").Value;
            this.db_w_txtpwd.Text = xDocument.Root.Element("connectionString_writeoff").Attribute("pwd").Value;
            this.ice_username.Text = xDocument.Root.Element("connectionICE").Attribute("username").Value;
            this.ice_pwd.Text = xDocument.Root.Element("connectionICE").Attribute("pwd").Value;
            this.ice_ip.Text = xDocument.Root.Element("connectionICE").Attribute("ip").Value;
            //CRI 16092015 s
            this.ice_http.Text = xDocument.Root.Element("connectionICE").Attribute("http").Value;
            this.ice_url2.Text = xDocument.Root.Element("connectionICE").Attribute("url2").Value;
            //CRI 16092015 e
            this.daily_username.Text = xDocument.Root.Element("connectionDailyUW").Attribute("username").Value;
            this.daily_pwd.Text = xDocument.Root.Element("connectionDailyUW").Attribute("pwd").Value;
            this.daily_ip.Text = xDocument.Root.Element("connectionDailyUW").Attribute("ip").Value;
            this.db_tMS_txtserver.Text = xDocument.Root.Element("connectionString_tagetikMS").Attribute("source").Value;
            this.db_tMS_txtname.Text = xDocument.Root.Element("connectionString_tagetikMS").Attribute("username").Value;
            this.db_tMS_txtpwd.Text = xDocument.Root.Element("connectionString_tagetikMS").Attribute("pwd").Value;
            this.db_tORA_txthost.Text = xDocument.Root.Element("connectionString_tagetikOracle").Attribute("host").Value;
            this.db_tORA_txtport.Text = xDocument.Root.Element("connectionString_tagetikOracle").Attribute("port").Value;
            this.db_tORA_txtname.Text = xDocument.Root.Element("connectionString_tagetikOracle").Attribute("username").Value;
            this.db_tORA_txtpwd.Text = xDocument.Root.Element("connectionString_tagetikOracle").Attribute("pwd").Value;
            this.db_tORA_txtsid.Text = xDocument.Root.Element("connectionString_tagetikOracle").Attribute("sid").Value;
            this.db_tFTP_txthost.Text = xDocument.Root.Element("connectionString_tagetikFTP").Attribute("host").Value;
            this.db_tFTP_txtport.Text = xDocument.Root.Element("connectionString_tagetikFTP").Attribute("port").Value;
            this.db_tFTP_txtname.Text = xDocument.Root.Element("connectionString_tagetikFTP").Attribute("username").Value;
            this.db_tFTP_txtpwd.Text = xDocument.Root.Element("connectionString_tagetikFTP").Attribute("pwd").Value;
            this.db_tFTP_txtpath.Text = xDocument.Root.Element("connectionString_tagetikFTP").Attribute("path").Value;
            this.ram_username.Text = xDocument.Root.Element("RAMcredential").Attribute("username").Value;
            this.ram_password.Text = xDocument.Root.Element("RAMcredential").Attribute("pwd").Value;
        }
        private void db_t_btntest_Click_1(object sender, EventArgs e)
        {
            if (MyControl.checkControl(this.db_tagetik))
            {
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    SqlConnection sqlConnection = new SqlConnection(string.Concat(new string[]
					{
						"data source=",
						this.db_tMS_txtserver.Text.Trim(),
						";initial catalog=DB_TAGETIK_MNGT;user id=",
						this.db_tMS_txtname.Text.Trim(),
						";password=",
						this.db_tMS_txtpwd.Text.Trim()
					}));
                    sqlConnection.Open();
                    sqlConnection.Close();
                    Cursor.Current = Cursors.Arrow;
                    MyMessage.showMessage("Connection success", MessageBoxIcon.Asterisk);
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Connection failed:\n" + ex.Message, MessageBoxIcon.Hand);
                }
            }
        }
        private void db_f_btntest_Click_1(object sender, EventArgs e)
        {
            if (MyControl.checkControl(this.db_fraud))
            {
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    SqlConnection sqlConnection = new SqlConnection(string.Concat(new string[]
					{
						"data source=",
						this.db_f_txtserver.Text.Trim(),
						";initial catalog=DB_FRAUD;user id=",
						this.db_f_txtname.Text.Trim(),
						";password=",
						this.db_f_txtpwd.Text.Trim()
					}));
                    sqlConnection.Open();
                    sqlConnection.Close();
                    Cursor.Current = Cursors.Arrow;
                    MyMessage.showMessage("Connection success", MessageBoxIcon.Asterisk);
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Connection failed:\n" + ex.Message, MessageBoxIcon.Hand);
                }
            }
        }
        private void db_w_btntest_Click_1(object sender, EventArgs e)
        {
            if (MyControl.checkControl(this.db_writeoff))
            {
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    SqlConnection sqlConnection = new SqlConnection(string.Concat(new string[]
					{
						"data source=",
						this.db_w_txtserver.Text.Trim(),
						";initial catalog=DB_WRITEOFF;user id=",
						this.db_w_txtname.Text.Trim(),
						";password=",
						this.db_w_txtpwd.Text.Trim()
					}));
                    sqlConnection.Open();
                    sqlConnection.Close();
                    Cursor.Current = Cursors.Arrow;
                    MyMessage.showMessage("Connection success", MessageBoxIcon.Asterisk);
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Connection failed:\n" + ex.Message, MessageBoxIcon.Hand);
                }
            }
        }
        private void ice_ip_TextChanged(object sender, EventArgs e)
        {
            //this.ice_url.Text = "http://" + this.ice_ip.Text + " / "; //+ this.ice_url2.Text;  //+"/ICE/Default.aspx";
            this.ice_url.Text = "://"+ this.ice_ip.Text + "/"; //+ this.ice_url2.Text;  //+"/ICE/Default.aspx";
        }
        private void daily_ip_TextChanged(object sender, EventArgs e)
        {
            this.daily_url.Text = "https://" + this.daily_ip.Text + "/GlobalUnderwriter/";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MyControl.checkControl(groupOracle))
            {
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    OracleConnection Oracle_Connection = new OracleConnection(string.Concat(new string[]
					{
						"Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=",
					db_tORA_txthost.Text,
					")(PORT=",
					db_tORA_txtport.Text,
					")))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=",
					db_tORA_txtsid.Text,
					")));User Id=",
					db_tORA_txtname.Text,
					";Password=",
					db_tORA_txtpwd.Text,
					";"
					}));
                    Oracle_Connection.Open();
                    Oracle_Connection.Close();
                    Cursor.Current = Cursors.Arrow;
                    MyMessage.showMessage("Connection success", MessageBoxIcon.Asterisk);
                }
                catch (Exception ex)
                {
                    MyMessage.showMessage("Connection failed:\n" + ex.Message, MessageBoxIcon.Hand);
                }
            }
        }

        private void check_digit_number(object sender, KeyPressEventArgs e)
        {
            const char Delete = (char)8;
            e.Handled =  !Char.IsDigit(e.KeyChar) && e.KeyChar != Delete;         
        }

        private void setting_FormClosing(object sender, FormClosingEventArgs e)
        {
            MyConnection.InizializeParameter_ice();
            MyConnection.InizializeConnection_db_Fraud();
            MyConnection.InizializeConnection_db_Writeoff();
            MyConnection.InizializeParameter_dailyuw();
            MyConnection.InizializeConnection_db_Tagetik_MS();
            MyConnection.InizializeConnection_db_Tagetik_Oracle();
            MyConnection.InizializeConnection_db_Tagetik_Ftp();
        }
    }
}
