﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Credit_risk_lib
{
    public class ice_parameters
    {
        public string ip
        {
            get;
            set;
        }
        public string username
        {
            get;
            set;
        }
        public string pwd
        {
            get;
            set;
        }
        public string http
        {
            get;
            set;
        }
        public string url2
        {
            get;
            set;
        }
        public string url
        {
            get
            {   
                MyMessage.showMessage(this.http +"://"+ this.ip + "/" + this.url2);
               //return "http://" + this.ip + "/" + this.url2; //"/ICE/Default.aspx";
                return this.http +"://" + this.ip + "/" + this.url2; //"/ICE/Default.aspx";
            }
        }
        public ice_parameters(string _ip, string _username, string _pwd,string _url2,string _http)
        {
            this.ip = _ip;
            this.username = _username;
            this.pwd = _pwd;
            this.url2 = _url2;
            this.http = _http;
        }
        public override string ToString()
        {
            return string.Concat(new string[]
			{
				"Username: ",
				this.username,
				" - Pwd: ",
				this.pwd,
				" - IP: ",
				this.ip
			});
        }
    }
}
