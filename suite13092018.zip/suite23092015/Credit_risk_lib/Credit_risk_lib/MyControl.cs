﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Credit_risk_lib
{
    public class MyControl
    {
        public static bool checkControl(Control c)
        {
            string text = string.Empty;
            IEnumerable<TextBox> enumerable =
                from controls in c.Controls.OfType<TextBox>()
                where controls.Tag.ToString() != string.Empty
                select controls;
            foreach (TextBox current in enumerable)
            {
                if (string.IsNullOrWhiteSpace(current.Text))
                {
                     if (current.Tag.ToString() == "File Excel")
                         text += "PLEASE SELECT SOURCE FILE\n";
                     else
                         text += "INSERT " + current.Tag + "\n";
                }
            }

            bool result;
            if (string.IsNullOrWhiteSpace(text))
            {
                result = true;
            }
            else
            {
                MyMessage.showMessage(text, MessageBoxIcon.Hand);
                result = false;
            }
            return result;
        }
    }
}
