﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Credit_risk_lib
{
    public class MyConsole
    {
        private static List<string> console = new List<string>();

        public static viewConsole mostraCONSOLE = new viewConsole();

        public static void enqueue(string message)
        {
            /*if (console.Count >= 10)
                console.RemoveAt(0);
            */    
            console.Add(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " > " + message);
        }
        public static List<string> Get_Console()
        {
            return console;
        }
    }
}
