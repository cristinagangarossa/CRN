﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Credit_risk_lib
{
    public partial class viewConsole : Form
    {
        delegate void UpdateTxt(string msg);
        private UpdateTxt eseguiUpd;
        Thread t;

        public viewConsole()
        {
            InitializeComponent();
        }

        private void action_update(string msg)
        {
            txtConsole.Items.Add(msg);
            txtConsole.SelectedIndex = txtConsole.Items.Count - 1;
        }

        private void action_execute()
        {
            int contatore = 0;
            int maxattuale = MyConsole.Get_Console().Count;
            
                for (int i = 0; i < maxattuale; i++)
                {
                    Invoke(eseguiUpd, MyConsole.Get_Console()[i]);
                    contatore++;
                }
                    

            while (true)
            {
                while (contatore < MyConsole.Get_Console().Count)
                {
                    Invoke(eseguiUpd,MyConsole.Get_Console()[contatore]);
                    contatore++;
                }
                Thread.Sleep(500);
            }
        }

        private void viewConsole_FormClosing(object sender, FormClosingEventArgs e)
        {
            /*t.Abort();
            t = null;*/
            e.Cancel = true;
            this.Hide();
        }

        private void viewConsole_Load(object sender, EventArgs e)
        {
            eseguiUpd = new UpdateTxt(action_update);
            t = new Thread(action_execute);
            t.IsBackground = true;
            t.Start();
        }
    }
}
