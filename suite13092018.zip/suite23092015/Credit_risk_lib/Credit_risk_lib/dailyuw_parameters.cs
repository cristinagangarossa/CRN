﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Credit_risk_lib
{
    public class dailyuw_parameters
    {
        public string ip
        {
            get;
            set;
        }
        public string username
        {
            get;
            set;
        }
        public string pwd
        {
            get;
            set;
        }
        
        public string url
        {
            get
            {
                return "https://" + this.ip + "/GlobalUnderwriter/";
            }
        }
        public dailyuw_parameters(string _ip, string _username, string _pwd)
        {
            this.ip = _ip;
            this.username = _username;
            this.pwd = _pwd;
        }
        public override string ToString()
        {
            return string.Concat(new string[]
			{
				"Username: ",
				this.username,
				" - Pwd: ",
				this.pwd,
				" - IP: ",
				this.ip
			});
        }
    }
}
