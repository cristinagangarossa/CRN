﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Credit_risk_lib
{
    public class MyMessage
    {
        public static void showMessage(string message, MessageBoxIcon IconChoose = MessageBoxIcon.Hand)
        {
            MessageBox.Show(message, "Credit & Risk", MessageBoxButtons.OK, IconChoose);
        }
        public static bool askMessage(string message)
        {
            return MessageBox.Show(message, "Credit & Risk", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
        }
    }
}
