﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace Credit_risk_lib
{
    public class MyExcel
    {
        public static void FilledCombobox(ref ComboBox combobox, string path_file)
        {
            Microsoft.Office.Interop.Excel.Application application = (Microsoft.Office.Interop.Excel.Application)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("00024500-0000-0000-C000-000000000046")));
            application.DisplayAlerts = false;
            combobox.Items.Clear();
            try
            {
                Workbook workbook = application.Workbooks.Open(path_file, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
                foreach (Worksheet worksheet in workbook.Worksheets)
                {
                    combobox.Items.Add(worksheet.Name);
                }
                workbook.Close(true, Missing.Value, Missing.Value);
                application.Quit();
                if (combobox.Items.Count > 0)
                {
                    combobox.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                application.Quit();
                MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
            }
        }
        public static void FilledString(ref string combobox, string path_file)
        {
            Microsoft.Office.Interop.Excel.Application application = (Microsoft.Office.Interop.Excel.Application)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("00024500-0000-0000-C000-000000000046")));
            try
            {
                Workbook workbook = application.Workbooks.Open(path_file, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
                foreach (Worksheet worksheet in workbook.Worksheets)
                {
                    combobox = combobox + worksheet.Name + ";";
                }
                workbook.Close(true, Missing.Value, Missing.Value);
                application.Quit();
            }
            catch (Exception ex)
            {
                application.Quit();
                MyMessage.showMessage("Error:\n" + ex.Message, MessageBoxIcon.Hand);
            }
        }
    }
}
