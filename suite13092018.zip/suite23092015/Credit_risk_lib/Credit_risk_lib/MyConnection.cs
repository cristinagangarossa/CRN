﻿using System;
using System.Collections.Generic;
using System.Data.OracleClient;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Linq;

namespace Credit_risk_lib
{
    public class MyConnection
    {
        public static string con_string_db_fraud = string.Empty;
        public static string con_string_db_writeoff = string.Empty;
        public static string con_string_dbMS_tagetik = string.Empty;
        public static string con_string_dbORA_tagetik = string.Empty;
        public static ice_parameters con_ice_import;
        public static dailyuw_parameters con_dailyuw;
        public static FTPtagetik_parameters ftp_tagetik;
        public static ram_parameter ram_parameter;
        public static bool InizializeConnection_db_Fraud()
        {
            bool result;
            //if (string.IsNullOrWhiteSpace(MyConnection.con_string_db_fraud))
            //{

            try
            {
                XDocument xDocument = XDocument.Parse(decrypt(File.ReadAllText("basic_settings.xml")));
                bool flag = MyConnection.set_db_fraud(xDocument.Root.Element("connectionString_fraud"));
                flag = MyConnection.set_ram_parameter(xDocument.Root.Element("RAMcredential"));
               // result = flag;
                //return result;
            }
            catch (Exception)
            {
                //MyConnection.con_string_db_fraud = string.Empty;
                //result = false;
                //return result;
            }
            //}

            try
            {
                SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud);
                sqlConnection.Open();
                sqlConnection.Close();
                result = true;
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }
        public static bool InizializeConnection_db_Tagetik_Oracle()
        {
            bool result;
           // if (string.IsNullOrWhiteSpace(MyConnection.con_string_dbORA_tagetik))
            //{
                try
                {
                    XDocument xDocument = XDocument.Parse(decrypt(File.ReadAllText("basic_settings.xml")));
                    bool flag = MyConnection.set_dbORA_tagetik(xDocument.Root.Element("connectionString_tagetikOracle"));
                   // result = flag;
                   // return result;
                }
                catch (Exception)
                {
                   // result = false;
                   // return result;
                }
           // }
            try
            {
                OracleConnection oracleConnection = new OracleConnection(MyConnection.con_string_dbORA_tagetik);
                oracleConnection.Open();
                oracleConnection.Close();
                result = true;
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }
        public static bool InizializeConnection_db_Tagetik_MS()
        {
            bool result;
           /* if (string.IsNullOrWhiteSpace(MyConnection.con_string_dbMS_tagetik))
            {*/
                try
                {
                    XDocument xDocument = XDocument.Parse(decrypt(File.ReadAllText("basic_settings.xml")));
                    bool flag = MyConnection.set_dbMS_tagetik(xDocument.Root.Element("connectionString_tagetikMS"));
                   // result = flag;
                   // return result;
                }
                catch (Exception)
                {
                    //result = false;
                    //return result;
                }
            //}
            try
            {
                SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_dbMS_tagetik);
                sqlConnection.Open();
                sqlConnection.Close();
                result = true;
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }
        public static bool InizializeConnection_db_Tagetik_Ftp()
        {
            bool result;
           // if (MyConnection.ftp_tagetik == null)
            //{
                try
                {
                    XDocument xDocument = XDocument.Parse(decrypt(File.ReadAllText("basic_settings.xml")));
                    bool flag = MyConnection.set_ftp_tagetik(xDocument.Root.Element("connectionString_tagetikFTP"));
                    result = flag;
                    return result;
                }
                catch (Exception)
                {
                    result = false;
                    return result;
                }
            //}
            //result = true;
            //return result;
        }
        public static bool InizializeConnection_db_Writeoff()
        {
            bool result;
           // if (string.IsNullOrWhiteSpace(MyConnection.con_string_db_writeoff))
            //{
                try
                {
                    XDocument xDocument = XDocument.Parse(decrypt(File.ReadAllText("basic_settings.xml")));
                    bool flag = MyConnection.set_db_writeoff(xDocument.Root.Element("connectionString_writeoff"));
                    /*result = flag;
                    return result;*/
                }
                catch (Exception)
                {
                    /*result = false;
                    return result;*/
                }
            //}
            try
            {
                SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_writeoff);
                sqlConnection.Open();
                sqlConnection.Close();
                result = true;
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }
        public static bool InizializeParameter_ice()
        {
            bool result;
            //if (MyConnection.con_ice_import == null)
            //{
                try
                {
                    XDocument xDocument = XDocument.Parse(decrypt(File.ReadAllText("basic_settings.xml")));
                    bool flag = MyConnection.set_con_ice(xDocument.Root.Element("connectionICE"));
                    result = flag;
                    return result;
                }
                catch (Exception)
                {
                    result = false;
                    return result;
                }
            //}
            //result = (!string.IsNullOrWhiteSpace(MyConnection.con_ice_import.ip) && !string.IsNullOrWhiteSpace(MyConnection.con_ice_import.username) && !string.IsNullOrWhiteSpace(MyConnection.con_ice_import.pwd));
            //return result;
        }
        public static bool InizializeParameter_dailyuw()
        {
            bool result;
            //if (MyConnection.con_dailyuw == null)
            //{
                try
                {
                    XDocument xDocument = XDocument.Parse(decrypt(File.ReadAllText("basic_settings.xml")));
                    bool flag = MyConnection.set_con_dailyuw(xDocument.Root.Element("connectionDailyUW"));
                    result = flag;
                    return result;
                }
                catch (Exception)
                {
                    result = false;
                    return result;
                }
            //}
            //result = (!string.IsNullOrWhiteSpace(MyConnection.con_dailyuw.ip) && !string.IsNullOrWhiteSpace(MyConnection.con_dailyuw.username) && !string.IsNullOrWhiteSpace(MyConnection.con_dailyuw.pwd));
            //return result;
        }
        private static bool set_db_fraud(XElement element)
        {
            bool result;
            if (string.IsNullOrWhiteSpace(element.Attribute("source").Value) || string.IsNullOrWhiteSpace(element.Attribute("pwd").Value) || string.IsNullOrWhiteSpace(element.Attribute("username").Value))
            {
                result = false;
            }
            else
            {
                MyConnection.con_string_db_fraud = string.Concat(new string[]
				{
					"data source=",
					element.Attribute("source").Value,
					";initial catalog=DB_FRAUD;user id=",
					element.Attribute("username").Value,
					";password=",
					element.Attribute("pwd").Value
				});
                try
                {
                    SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_fraud);
                    sqlConnection.Open();
                    sqlConnection.Close();
                    result = true;
                }
                catch (Exception)
                {
                    MyConnection.con_string_db_fraud = string.Empty;
                    result = false;
                }
            }
            return result;
        }
        private static bool set_db_writeoff(XElement element)
        {
            bool result;
            if (string.IsNullOrWhiteSpace(element.Attribute("source").Value) || string.IsNullOrWhiteSpace(element.Attribute("pwd").Value) || string.IsNullOrWhiteSpace(element.Attribute("username").Value))
            {
                result = false;
            }
            else
            {
                MyConnection.con_string_db_writeoff = string.Concat(new string[]
				{
					"data source=",
					element.Attribute("source").Value,
					";initial catalog=DB_WRITEOFF;user id=",
					element.Attribute("username").Value,
					";password=",
					element.Attribute("pwd").Value
				});
                try
                {
                    SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_db_writeoff);
                    sqlConnection.Open();
                    sqlConnection.Close();
                    result = true;
                }
                catch (Exception)
                {
                    MyConnection.con_string_db_writeoff = string.Empty;
                    result = false;
                }
            }
            return result;
        }
        private static bool set_dbMS_tagetik(XElement element)
        {
            bool result;
            if (string.IsNullOrWhiteSpace(element.Attribute("source").Value) || string.IsNullOrWhiteSpace(element.Attribute("pwd").Value) || string.IsNullOrWhiteSpace(element.Attribute("username").Value))
            {
                result = false;
            }
            else
            {
                MyConnection.con_string_dbMS_tagetik = string.Concat(new string[]
				{
					"data source=",
					element.Attribute("source").Value,
					";initial catalog=DB_TAGETIK_MNGT;user id=",
					element.Attribute("username").Value,
					";password=",
					element.Attribute("pwd").Value
				});
                try
                {
                    SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_dbMS_tagetik);
                    sqlConnection.Open();
                    sqlConnection.Close();
                    result = true;
                }
                catch (Exception)
                {
                    MyConnection.con_string_dbMS_tagetik = string.Empty;
                    result = false;
                }
            }
            return result;
        }
        private static bool set_dbORA_tagetik(XElement element)
        {
            bool result;
            if (string.IsNullOrWhiteSpace(element.Attribute("host").Value) || string.IsNullOrWhiteSpace(element.Attribute("port").Value) || string.IsNullOrWhiteSpace(element.Attribute("sid").Value) || string.IsNullOrWhiteSpace(element.Attribute("pwd").Value) || string.IsNullOrWhiteSpace(element.Attribute("username").Value))
            {
                result = false;
            }
            else
            {
                MyConnection.con_string_dbORA_tagetik = string.Concat(new string[]
				{
					"Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=",
					element.Attribute("host").Value,
					")(PORT=",
					element.Attribute("port").Value,
					")))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=",
					element.Attribute("sid").Value,
					")));User Id=",
					element.Attribute("username").Value,
					";Password=",
					element.Attribute("pwd").Value,
					";"
				});
                try
                {
                    OracleConnection oracleConnection = new OracleConnection(MyConnection.con_string_dbORA_tagetik);
                    oracleConnection.Open();
                    oracleConnection.Close();
                    result = true;
                }
                catch (Exception)
                {
                    MyConnection.con_string_dbORA_tagetik = string.Empty;
                    result = false;
                }
            }
            return result;
        }
        private static bool set_con_ice(XElement element)
        {
            bool result;
            if (string.IsNullOrWhiteSpace(element.Attribute("username").Value) || string.IsNullOrWhiteSpace(element.Attribute("pwd").Value) || string.IsNullOrWhiteSpace(element.Attribute("ip").Value) || string.IsNullOrWhiteSpace(element.Attribute("url2").Value) || string.IsNullOrWhiteSpace(element.Attribute("http").Value))
            {
                result = false;
            }
            else
            {
                MyConnection.con_ice_import = new ice_parameters(element.Attribute("ip").Value, element.Attribute("username").Value, element.Attribute("pwd").Value, element.Attribute("url2").Value, element.Attribute("http").Value);
                result = true;
            }
            return result;
        }
        private static bool set_ftp_tagetik(XElement element)
        {
            bool result;
            if (string.IsNullOrWhiteSpace(element.Attribute("username").Value) || string.IsNullOrWhiteSpace(element.Attribute("pwd").Value) || string.IsNullOrWhiteSpace(element.Attribute("host").Value) || string.IsNullOrWhiteSpace(element.Attribute("port").Value))
            {
                result = false;
            }
            else
            {
                MyConnection.ftp_tagetik = new FTPtagetik_parameters(element.Attribute("host").Value, element.Attribute("port").Value, element.Attribute("username").Value, element.Attribute("pwd").Value, element.Attribute("path").Value);
                result = true;
            }
            return result;
        }
        private static bool set_con_dailyuw(XElement element)
        {
            bool result;
            if (string.IsNullOrWhiteSpace(element.Attribute("username").Value) || string.IsNullOrWhiteSpace(element.Attribute("pwd").Value) || string.IsNullOrWhiteSpace(element.Attribute("ip").Value))
            {
                result = false;
            }
            else
            {
                MyConnection.con_dailyuw = new dailyuw_parameters(element.Attribute("ip").Value, element.Attribute("username").Value, element.Attribute("pwd").Value);
                result = true;
            }
            return result;
        }
        private static bool set_ram_parameter(XElement element)
        {
            bool result;
            if (string.IsNullOrWhiteSpace(element.Attribute("username").Value) || string.IsNullOrWhiteSpace(element.Attribute("pwd").Value))
            {
                result = false;
            }
            else
            {
                MyConnection.ram_parameter = new ram_parameter(element.Attribute("username").Value, element.Attribute("pwd").Value);
                result = true;
            }
            return result;
        }
        public static string crypta(string mystring)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(mystring);
            MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider();
            byte[] key = mD5CryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes("2014AntonioVincenzo_In_Neperia"));
            mD5CryptoServiceProvider.Clear();
            TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider
            {
                Key = key,
                Mode = CipherMode.ECB,
                Padding = PaddingMode.PKCS7
            };
            ICryptoTransform cryptoTransform = tripleDESCryptoServiceProvider.CreateEncryptor();
            byte[] array = cryptoTransform.TransformFinalBlock(bytes, 0, bytes.Length);
            tripleDESCryptoServiceProvider.Clear();
            return Convert.ToBase64String(array, 0, array.Length);
            
        }
        public static string decrypt(string cipherString)
        {
            byte[] array = Convert.FromBase64String(cipherString);
            MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider();
            byte[] key = mD5CryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes("2014AntonioVincenzo_In_Neperia"));
            mD5CryptoServiceProvider.Clear();
            TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider();
            tripleDESCryptoServiceProvider.Key = key;
            tripleDESCryptoServiceProvider.Mode = CipherMode.ECB;
            tripleDESCryptoServiceProvider.Padding = PaddingMode.PKCS7;
            ICryptoTransform cryptoTransform = tripleDESCryptoServiceProvider.CreateDecryptor();
            byte[] bytes = cryptoTransform.TransformFinalBlock(array, 0, array.Length);
            tripleDESCryptoServiceProvider.Clear();
            return Encoding.UTF8.GetString(bytes);
        }
    }
}
