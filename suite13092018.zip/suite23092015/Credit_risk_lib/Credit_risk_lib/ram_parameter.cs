﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Credit_risk_lib
{
    public class ram_parameter
    {
        public string username
        {
            get;
            set;
        }
        public string pwd
        {
            get;
            set;
        }
        public ram_parameter(string _username, string _password)
        {
            this.username = _username;
            this.pwd = _password;
        }
    }
}
