﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Credit_risk_lib
{
    public class FTPtagetik_parameters
    {
        public string host
        {
            get;
            set;
        }
        public string port
        {
            get;
            set;
        }
        public string username
        {
            get;
            set;
        }
        public string pwd
        {
            get;
            set;
        }
        public string path
        {
            get;
            set;
        }
        public FTPtagetik_parameters(string _host, string _port, string _username, string _pwd, string _path)
        {
            this.host = _host;
            this.port = _port;
            this.username = _username;
            this.pwd = _pwd;
            this.path = _path;
        }
    }
}
