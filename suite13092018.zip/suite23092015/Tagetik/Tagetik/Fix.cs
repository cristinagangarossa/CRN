﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Credit_risk_lib;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.Windows.Forms;
using System.Web;
using Microsoft.Office.Interop.Excel;

namespace Tagetik
{
    public static class Fix
    {
         public static Stream CopyAndClose(Stream inputStream)
        {
            byte[] numArray = new byte[256];
            MemoryStream memoryStream = new MemoryStream();
            for (int i = inputStream.Read(numArray, 0, 256); i > 0; i = inputStream.Read(numArray, 0, 256))
            {
                memoryStream.Write(numArray, 0, i);
            }
            memoryStream.Position = (long)0;
            inputStream.Close();
            return memoryStream;
        }

        public static void CSR(string filename)
        {
            Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            try
            {
                Microsoft.Office.Interop.Excel.Workbook wb = xlApp.Workbooks.Add(@filename);
                Microsoft.Office.Interop.Excel.Worksheet ws = (Microsoft.Office.Interop.Excel.Worksheet)wb.Worksheets["Sheet1"];
                Microsoft.Office.Interop.Excel.Range range;
                Microsoft.Office.Interop.Excel.Range entireRow;

                range = ws.Cells.SpecialCells(XlCellType.xlCellTypeLastCell);
                entireRow = range.EntireRow;
                entireRow.Delete(XlDirection.xlUp);

                MyConsole.enqueue("Format CSR: step 1/4 --> remove Total row");

                range = ws.get_Range("A1", "A9");
                entireRow = range.EntireRow;
                entireRow.Delete(XlDirection.xlUp);

                MyConsole.enqueue("Format CSR: step 2/4 --> remove header");

                range = ws.UsedRange;
                range.Sort(range.Columns[2], XlSortOrder.xlDescending, Type.Missing, Type.Missing, XlSortOrder.xlAscending, Type.Missing, XlSortOrder.xlAscending, XlYesNoGuess.xlNo, Type.Missing, Type.Missing, XlSortOrientation.xlSortColumns);

                MyConsole.enqueue("Format CSR: step 3/4 --> sort by Tot Bal [Please wait...]");

                int row_count = range.Rows.Count;

                range = ws.get_Range("B:B");
                //string decimalSeparator = xlApp.DecimalSeparator;
                range = range.Find("0,00", Type.Missing, XlFindLookIn.xlValues, XlLookAt.xlWhole, XlSearchOrder.xlByRows, XlSearchDirection.xlNext,false,false,false);
                if (range != null)
                {
                    int i = range.Row;
                    range = ws.get_Range("A" + i + ":A" + row_count);
                    entireRow = range.EntireRow;
                    entireRow.Delete(XlDirection.xlUp);
                }

                range = ws.get_Range("B:B");
                range = range.Find("0.00", Type.Missing, XlFindLookIn.xlValues, XlLookAt.xlWhole, XlSearchOrder.xlByRows, XlSearchDirection.xlNext, false, false, false);
                if (range != null)
                {
                    int i = range.Row;
                    range = ws.get_Range("A" + i + ":A" + row_count);
                    entireRow = range.EntireRow;
                    entireRow.Delete(XlDirection.xlUp);
                }

                MyConsole.enqueue("Format CSR: step 4/5 --> remove Tot Bal = 0 [Please wait...]");

                range = ws.get_Range("A2:A" + row_count);
                range.NumberFormat = "0";
                
                foreach (Microsoft.Office.Interop.Excel.Range cell in range)
                {
                    if (cell.Value2 == null)
                    {
                        break;
                    }
                    cell.Value2 = cell.Value2;
                }

                MyConsole.enqueue("Format CSR: step 5/5 --> Set Merchant Num format (number)");

                xlApp.DisplayAlerts = false;

                wb.Saved = true;
                wb.SaveCopyAs(@filename);
                
                xlApp.Quit();
                MyConsole.enqueue("Format CSR: format complete");
            }
            catch (Exception ee)
            {
                MessageBox.Show("UNABLE TO FORMAT CSR\r\n" + ee.Message, "Credit & Risk", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                MyConsole.enqueue("UNABLE TO FORMAT CSR: " + ee.Message);
                xlApp.Quit();
            }
        }

        public static ArrayList getViewStateAndEventVal(StreamReader srHtml)
        {
            MyLogger.WriteLog("entro nel metodo getViewStateAndEventVal ");
            int num;
            int num1;
            ArrayList arrayLists = new ArrayList(2);
            while (true)
            {
                string str = srHtml.ReadLine();
                MyLogger.WriteLog("str  " + str );
                string str1 = str;
                if (str == null)
                {
                    break;
                }
                if (str1.IndexOf("\"__VIEWSTATE\"") != -1)
                {
                    num = str1.IndexOf("value=") + 7;
                    num1 = str1.IndexOf("\"", num) - num;
                    arrayLists.Insert(0, str1.Substring(num, num1));
                }
                if (str1.IndexOf("\"__EVENTVALIDATION\"") != -1)
                {
                    num = str1.IndexOf("value=") + 7;
                    num1 = str1.IndexOf("\"", num) - num;
                    arrayLists.Insert(1, str1.Substring(num, num1));
                }
            }
            return arrayLists;
        }

        public static string UpperCaseUrlEncode(string s)
        {
            char[] charArray = HttpUtility.UrlEncode(s).ToCharArray();
            for (int i = 0; i < (int)charArray.Length - 2; i++)
            {
                if (charArray[i] == '%')
                {
                    charArray[i + 1] = char.ToUpper(charArray[i + 1]);
                    charArray[i + 2] = char.ToUpper(charArray[i + 2]);
                }
            }
            return new string(charArray);
        }
    }
}
