﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.SqlClient;
using System.Data.OracleClient;
using System.Data.OleDb;
using System.Reflection;
using System.Globalization;

namespace Tagetik
{
    public partial class TagetikImport : Form
    {
        private string newFilePath = "";
        //viewConsole win;
        bool closeConsole = false;

        public TagetikImport()
        {
            InitializeComponent();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.myprogressbar.Value = 0;

          
            if ((rbAgency.Checked && MyControl.checkControl(this.gbCSR) && MyControl.checkControl(this.source_file)) || (rbLetters.Checked && MyControl.checkControl(this.source_file)))
            {
                base.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                MyLogger.WriteLog(this.Text + ": start import");
                this.myworker.RunWorkerAsync(new object[]
		                                                {
			                                                this.tbXslPath.Text,
			                                                this.tbSheet.Text,
			                                                this.tbCSRPath.Text,
			                                                this.tbCSRSheet.Text,
			                                                this.rbLetters.Checked ? "rbLetters" : "rbAgency"
		                                                });

                /*  win = (Application.OpenForms["viewConsole"] != null) ? ((viewConsole)Application.OpenForms["viewConsole"]) : null;
               
                  if (win == null)
                  {
                      win = new viewConsole();
                          win.Show();
                      closeConsole = true;
                  }*/

                if (!MyConsole.mostraCONSOLE.Visible)
                {
                    MyConsole.mostraCONSOLE.Show();
                    closeConsole = true;
                }


            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "File Excel (*.xls, *.xlsx)|*.xls; *.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tbCSRPath.Text = openFileDialog.FileName;
                MyExcel.FilledCombobox(ref this.tbCSRSheet, this.tbCSRPath.Text);
                Cursor.Current = Cursors.Arrow;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "File Excel (*.xls, *.xlsx)|*.xls; *.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tbXslPath.Text = openFileDialog.FileName;
                MyExcel.FilledCombobox(ref this.tbSheet, this.tbXslPath.Text);
                Cursor.Current = Cursors.Arrow;
            }
        }

        private int isCorporateMid(string mid)
        {
            int result;
            try
            {
                SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_dbMS_tagetik);
                SqlCommand sqlCommand = new SqlCommand("SELECT COUNT(*) FROM T_CORPORATE WHERE MID=@mid", sqlConnection);
                sqlCommand.Parameters.AddWithValue("@mid", mid);
                sqlConnection.Open();
                int num = (int)sqlCommand.ExecuteScalar();
                sqlConnection.Close();
                if (num > 0)
                {
                    result = 1;
                }
                else
                {
                    result = 0;
                }
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("ERROR CONNECTING TO CORPORATE TABLE\r\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog(this.Text + " ERROR CONNECTING TO CORPORATE TABLE\r\n" + ex.Message);
                result = -1;
            }
            return result;
        }

        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {
            OracleCommand oracleCommand;
            OracleDataReader oracleDataReader;
            string str;
            int i;
            object[] item;
            bool flag;
            object[] argument = e.Argument as object[];
            Excel.Application variable = new Excel.Application();

            OracleConnection oracleConnection = new OracleConnection(MyConnection.con_string_dbORA_tagetik);
            OleDbConnection oleDbConnection1 = new OleDbConnection(string.Concat("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=", argument[2].ToString(), ";Extended Properties='Excel 12.0;HDR=Yes;'"));

            try
            {

                oracleConnection.Open();
                string directoryName = Path.GetDirectoryName(argument[0].ToString());
                string extension = Path.GetExtension(argument[0].ToString());
                string str1 = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                string[] fileNameWithoutExtension = new string[] { directoryName, "\\", Path.GetFileNameWithoutExtension(argument[0].ToString()), "_", str1, extension };
                this.newFilePath = string.Concat(fileNameWithoutExtension);
                fileNameWithoutExtension = new string[] { directoryName, "\\", Path.GetFileNameWithoutExtension(argument[0].ToString()), "_", str1, ".csv" };
                string.Concat(fileNameWithoutExtension);
                if (File.Exists(this.newFilePath))
                {
                    File.Delete(this.newFilePath);
                    File.Copy(argument[0].ToString(), this.newFilePath);
                }
                else
                {
                    File.Copy(argument[0].ToString(), this.newFilePath);
                }
                string str2 = string.Concat("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=", argument[0].ToString(), ";Extended Properties='Excel 12.0;HDR=Yes;'");
                OleDbConnection oleDbConnection = new OleDbConnection(str2);
                try
                {
                    oleDbConnection.Open();
                    OleDbCommand oleDbCommand = new OleDbCommand(string.Concat("select * from [", argument[1].ToString(), "$] "), oleDbConnection);
                    int num = int.Parse((new OleDbCommand(string.Concat("select COUNT(*) from [", argument[1], "$]"), oleDbConnection)).ExecuteScalar().ToString());
                    int num1 = 1;
                    OleDbDataReader oleDbDataReader = oleDbCommand.ExecuteReader();
                    try
                    {
                        int item1 = 2;
                        string str3 = oleDbDataReader.GetName(0).ToString();
                        if (!(argument[4].ToString() == "rbLetters") || str3.Contains("tipologia lettera"))
                        {
                            flag = (argument[4].ToString() != "rbAgency" ? true : str3.Contains("MID"));
                        }
                        else
                        {
                            flag = false;
                        }
                        if (!flag)
                        {
                            MyMessage.showMessage("Invalid file format", MessageBoxIcon.Hand);
                            File.Delete(this.newFilePath);
                            base.Enabled = true;
                            return;
                        }
                        else if (variable != null)
                        {
                            variable.Visible = false;
                            variable.DisplayAlerts = false;
                            Excel.Workbook variable1 = variable.Workbooks.Add(this.newFilePath);
                            Excel.Worksheet worksheets = (Excel.Worksheet)((dynamic)variable1.Worksheets[argument[1].ToString()]);
                            if (argument[4].ToString() == "rbLetters")
                            {
                                while (oleDbDataReader.Read())
                                {
                                    if (oleDbDataReader["MID"].ToString() != "")
                                    {
                                        str = string.Concat("0", oleDbDataReader["MID"].ToString().Substring(2));
                                        oracleCommand = new OracleCommand(string.Concat("SELECT RAG_SOC, VIA_1, VIA_2, CIVICO_1, CIVICO_2, POST_CODES_1, POST_CODES_2, CITTA_1, CITTA_2, PROV_1, PROV_2 FROM TD_MERCHANT WHERE MERCHANT_ID ='", str, "'"), oracleConnection);
                                        oracleDataReader = oracleCommand.ExecuteReader();
                                        if (oracleDataReader.Read())
                                        {
                                            worksheets.Cells[item1, 2] = oracleDataReader["RAG_SOC"].ToString();
                                            item = new object[] { "Insert data ", oleDbDataReader["MID"], ": ", oracleDataReader["RAG_SOC"] };
                                            MyConsole.enqueue(string.Concat(item));
                                            switch (this.isCorporateMid(str))
                                            {
                                                case 0:
                                                    {
                                                        worksheets.Cells[item1, 3] = string.Concat(oracleDataReader["VIA_1"].ToString(), " ", oracleDataReader["CIVICO_1"].ToString());
                                                        worksheets.Cells[item1, 4] = string.Concat("'", oracleDataReader["POST_CODES_1"].ToString());
                                                        worksheets.Cells[item1, 5] = string.Concat(oracleDataReader["CITTA_1"].ToString(), " ", oracleDataReader["PROV_1"]);
                                                        break;
                                                    }
                                                case 1:
                                                    {
                                                        worksheets.Cells[item1, 3] = string.Concat(oracleDataReader["VIA_2"].ToString(), " ", oracleDataReader["CIVICO_2"].ToString());
                                                        worksheets.Cells[item1, 4] = string.Concat("'", oracleDataReader["POST_CODES_2"].ToString());
                                                        worksheets.Cells[item1, 5] = string.Concat(oracleDataReader["CITTA_2"].ToString(), " ", oracleDataReader["PROV_2"]);
                                                        MyConsole.enqueue("[CORPORATE]");
                                                        break;
                                                    }
                                                default:
                                                    {
                                                        return;
                                                    }
                                            }
                                            worksheets.Cells[item1, 7] = string.Concat("'", oleDbDataReader["IMPORTO"].ToString().Replace(".", ","));
                                        }
                                        item1++;
                                        oracleDataReader.Close();
                                        this.myworker.ReportProgress(num1 * 100 / num);
                                        num1++;
                                    }
                                }
                            }
                            else if (this.rbAgency.Checked)
                            {
                                Excel.Worksheet worksheets1 = (Excel.Worksheet)variable1.Worksheets.Add(Type.Missing, (dynamic)variable1.Worksheets[argument[1].ToString()]);
                                worksheets1.Name = "Dettagli";
                                worksheets1.Cells[1, 1] = "MERCHANT NUM";
                                worksheets1.Cells[1, 2] = "OPEN BALANCE";
                                worksheets1.Cells[1, 3] = "BDA NAME";
                                int year = DateTime.Now.Year;
                                int month = DateTime.Now.Month;
                                for (i = 4; i <= 16; i++)
                                {
                                    worksheets1.Cells[1, i] = string.Concat(month, "-", year);
                                    month--;
                                    if (month == 0)
                                    {
                                        month = 12;
                                        year--;
                                    }
                                }
                                worksheets1.Cells[1, 17] = "TOTAL OPEN BALANCE";
                                worksheets1.Cells[1, 18] = "CITY";
                                worksheets1.Cells[1, 19] = "STATE";

                                oleDbConnection1.Open();
                                while (oleDbDataReader.Read())
                                {
                                    if (oleDbDataReader["MID"].ToString() != "")
                                    {
                                        str = string.Concat("0", oleDbDataReader["MID"].ToString().Substring(2));
                                       // MessageBox.Show("MID: "+str);
                                        oracleCommand = new OracleCommand(string.Concat("SELECT RAG_SOC, VIA_1, CIVICO_1, POST_CODES_1, CITTA_1,PROV_1,P_IVA,TEL_1 FROM TD_MERCHANT WHERE MERCHANT_ID ='", str, "'"), oracleConnection);
                                        oracleDataReader = oracleCommand.ExecuteReader();
                                        if (oracleDataReader.Read())
                                        {
                                            worksheets.Cells[item1, 3] = oracleDataReader["RAG_SOC"].ToString();
                                            worksheets.Cells[item1, 4] = string.Concat(oracleDataReader["VIA_1"].ToString(), " ", oracleDataReader["CIVICO_1"].ToString());
                                            worksheets.Cells[item1, 5] = string.Concat("'", oracleDataReader["POST_CODES_1"].ToString());
                                            worksheets.Cells[item1, 6] = string.Concat(oracleDataReader["CITTA_1"].ToString(), " ", oracleDataReader["PROV_1"]);
                                            worksheets.Cells[item1, 7] = string.Concat("'", oracleDataReader["P_IVA"].ToString());
                                            worksheets.Cells[item1, 8] = string.Concat("'", oracleDataReader["TEL_1"].ToString());
                                            item = new object[] { "Insert data ", oleDbDataReader["MID"], ": ",oracleDataReader["RAG_SOC"] };
                                            MyConsole.enqueue(string.Concat(item));
                                            OleDbCommand oleDbCommand1 = new OleDbCommand(string.Concat("select * from [", argument[3].ToString(), "$] where [Merchant Num]=", oleDbDataReader["MID"].ToString()), oleDbConnection1);
                                            
                                        OleDbDataReader oleDbDataReader1 = oleDbCommand1.ExecuteReader();
                                            oleDbDataReader1.Read();
                                            worksheets1.Cells[item1, 1] = string.Concat("'", oleDbDataReader["MID"]);
                                            worksheets1.Cells[item1, 3] = oracleDataReader["RAG_SOC"].ToString();
                                            if (oleDbDataReader1.HasRows)
                                            {
                                                //MessageBox.Show("oledb has rows");
                                                for (i = 4; i <= 19; i++)
                                                {
                                                    worksheets1.Cells[item1, i] = oleDbDataReader1[i + 27];
                                                }
                                                worksheets1.Cells[item1, 2] = oleDbDataReader[1];
                                            }
                                        }
                                        item1++;
                                        oracleDataReader.Close();
                                        this.myworker.ReportProgress(num1 * 100 / num);
                                        num1++;
                                    }
                                }
                                oleDbConnection1.Close();
                            }
                            variable1.SaveAs(this.newFilePath, Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, true, false, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
                            variable1.Close(true, Missing.Value, Missing.Value);
                            variable.Quit();
                        }
                        else
                        {
                            MyMessage.showMessage("EXCEL could not be started\r\nCheck Office installation and project references", MessageBoxIcon.Hand);
                            MyLogger.WriteLog(string.Concat(this.Text, " EXCEL could not be started. Check Office installation and project references"));
                            File.Delete(this.newFilePath);
                            base.Enabled = true;
                            return;
                        }
                    }
                    catch
                    {
                        if (oleDbConnection1.State == ConnectionState.Open)
                            oleDbConnection1.Close();
                    }
                    oleDbConnection.Close();
                }
                catch
                {
                    if (oleDbConnection.State == ConnectionState.Open)
                        oleDbConnection.Close();
                }
                base.Enabled = true;
                oracleConnection.Close();
                MyConsole.enqueue(string.Concat("END OF PROGRAM: File ", this.newFilePath, " created"));
                MyMessage.showMessage(string.Concat("END OF PROGRAM: File ", this.newFilePath, " created"), MessageBoxIcon.Information);


            }
            catch (Exception exception)
            {

                MyConsole.enqueue(string.Concat("ERROR ", exception.Message));
                MyMessage.showMessage(string.Concat("ERROR\r\n", exception.Message), MessageBoxIcon.Hand);
                MyLogger.WriteLog(string.Concat(this.Text, " ERROR ", exception.Message));
                if (this.newFilePath != "")
                {
                    File.Delete(this.newFilePath);
                }
                base.Enabled = true;
                variable.Quit();
                if (oracleConnection.State == ConnectionState.Open)
                    oracleConnection.Close();
            }
        }

        private void myworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.myprogressbar.Value = e.ProgressPercentage;
        }

        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            Cursor.Current = Cursors.Arrow;

            if (closeConsole)
            {
                // win.Close();
                // win = null;
                MyConsole.mostraCONSOLE.Hide();
            }
            /*if (this.myprogressbar.Value != 100)
            {
                MyMessage.showMessage("Import has been stopped", MessageBoxIcon.Hand);
            }
            else
            {
                MyMessage.showMessage(string.Concat(this.tbXslPath.Text, " IMPORTED"), MessageBoxIcon.Asterisk);
            }*/
        }

        private void rbLetters_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rbLetters.Checked)
            {
                this.gbCSR.Visible = false;
            }
            else
            {
                this.gbCSR.Visible = true;
            }
        }
    }
}
