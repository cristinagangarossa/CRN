﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace Tagetik
{
    partial class frmCorporate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private GroupBox sourcefile;
        private Label label8;
        private TextBox tbXslPath;
        private Button button1;
        private Button btnStart;
        private ComboBox tbSheet;
        private Button button2;
        private StatusStrip statusStrip1;
        private ToolStripProgressBar myprogressbar;
        private BackgroundWorker myworker;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sourcefile = new System.Windows.Forms.GroupBox();
            this.tbSheet = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbXslPath = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.myprogressbar = new System.Windows.Forms.ToolStripProgressBar();
            this.myworker = new System.ComponentModel.BackgroundWorker();
            this.sourcefile.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // sourcefile
            // 
            this.sourcefile.Controls.Add(this.tbSheet);
            this.sourcefile.Controls.Add(this.label8);
            this.sourcefile.Controls.Add(this.tbXslPath);
            this.sourcefile.Controls.Add(this.button1);
            this.sourcefile.Location = new System.Drawing.Point(8, 14);
            this.sourcefile.Name = "sourcefile";
            this.sourcefile.Size = new System.Drawing.Size(339, 100);
            this.sourcefile.TabIndex = 34;
            this.sourcefile.TabStop = false;
            this.sourcefile.Text = "Source file";
            // 
            // tbSheet
            // 
            this.tbSheet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tbSheet.FormattingEnabled = true;
            this.tbSheet.Location = new System.Drawing.Point(92, 60);
            this.tbSheet.Name = "tbSheet";
            this.tbSheet.Size = new System.Drawing.Size(174, 23);
            this.tbSheet.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 15);
            this.label8.TabIndex = 17;
            this.label8.Text = "Sheet name";
            // 
            // tbXslPath
            // 
            this.tbXslPath.Location = new System.Drawing.Point(92, 26);
            this.tbXslPath.Name = "tbXslPath";
            this.tbXslPath.ReadOnly = true;
            this.tbXslPath.Size = new System.Drawing.Size(230, 23);
            this.tbXslPath.TabIndex = 5;
            this.tbXslPath.Tag = "Excel file";
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button1.Location = new System.Drawing.Point(17, 24);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.button1.Size = new System.Drawing.Size(69, 25);
            this.button1.TabIndex = 1;
            this.button1.Text = "Browse..";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnStart
            // 
            this.btnStart.AutoSize = true;
            this.btnStart.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnStart.Location = new System.Drawing.Point(94, 126);
            this.btnStart.Name = "btnStart";
            this.btnStart.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.btnStart.Size = new System.Drawing.Size(89, 25);
            this.btnStart.TabIndex = 3;
            this.btnStart.Text = "Start import";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // button2
            // 
            this.button2.AutoSize = true;
            this.button2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button2.Location = new System.Drawing.Point(200, 126);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.button2.Size = new System.Drawing.Size(60, 25);
            this.button2.TabIndex = 4;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.myprogressbar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 163);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(354, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 36;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // myprogressbar
            // 
            this.myprogressbar.Name = "myprogressbar";
            this.myprogressbar.Size = new System.Drawing.Size(350, 16);
            // 
            // myworker
            // 
            this.myworker.WorkerReportsProgress = true;
            this.myworker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.myworker_DoWork);
            this.myworker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.myworker_ProgressChanged);
            this.myworker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.myworker_RunWorkerCompleted);
            // 
            // frmCorporate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 185);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.sourcefile);
            this.Controls.Add(this.btnStart);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCorporate";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Tagetik - Import corporate data";
            this.sourcefile.ResumeLayout(false);
            this.sourcefile.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}