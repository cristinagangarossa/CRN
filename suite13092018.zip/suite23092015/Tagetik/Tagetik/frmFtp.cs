﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Net;
using System.IO;
using System.Data.OleDb;

namespace Tagetik
{
    public partial class frmFtp : Form
    {
        //viewConsole win;
        bool closeConsole = false;

        public frmFtp()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "File Excel (*.xls, *.xlsx)|*.xls; *.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tbXslPath.Text = openFileDialog.FileName;
                MyExcel.FilledCombobox(ref this.tbSheet, this.tbXslPath.Text);
                Cursor.Current = Cursors.Arrow;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.myprogressbar.Value = 0;
            if (MyControl.checkControl(this) && MyControl.checkControl(this.source_file))
            {
                base.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                MyLogger.WriteLog(this.Text + ": start upload");
                this.myworker.RunWorkerAsync(new object[] {this.tbXslPath.Text,this.tbSheet.Text });
               /* win = (Application.OpenForms["viewConsole"] != null) ? ((viewConsole)Application.OpenForms["viewConsole"]) : null;
                if (win == null)
                {
                    win = new viewConsole();
                    win.Show();
                    closeConsole = true;
                }*/

                if (!MyConsole.mostraCONSOLE.Visible)
                {
                    MyConsole.mostraCONSOLE.Show();
                    closeConsole = true;
                }

            }
        }

        private static void convertExcelToCSV(string sourceFile, string worksheetName, string targetFile)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + sourceFile + ";Extended Properties='Excel 12.0;HDR=Yes;'";
            OleDbConnection oleDbConnection = null;
            StreamWriter streamWriter = null;
            OleDbCommand oleDbCommand = null;
            OleDbDataAdapter oleDbDataAdapter = null;
            try
            {
                oleDbConnection = new OleDbConnection(connectionString);
                oleDbConnection.Open();
                oleDbCommand = new OleDbCommand("SELECT * FROM [" + worksheetName + "$]", oleDbConnection);
                oleDbCommand.CommandType = CommandType.Text;
                streamWriter = new StreamWriter(targetFile);
                oleDbDataAdapter = new OleDbDataAdapter(oleDbCommand);
                DataTable dataTable = new DataTable();
                oleDbDataAdapter.Fill(dataTable);
                int num;
                if (dataTable.Columns[0].ColumnName == "MID")
                {
                    num = 8;
                }
                else
                {
                    num = 9;
                }
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    string text = "";
                    for (int j = 0; j < num; j++)
                    {
                        text = text + dataTable.Rows[i][j].ToString() + ";";
                    }
                    streamWriter.WriteLine(text);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                Console.ReadLine();
            }
            finally
            {
                if (oleDbConnection.State == ConnectionState.Open)
                {
                    oleDbConnection.Close();
                }
                oleDbConnection.Dispose();
                oleDbCommand.Dispose();
                oleDbDataAdapter.Dispose();
                streamWriter.Close();
                streamWriter.Dispose();
            }
        }

        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {
          

            object[] array = e.Argument as object[];
            try
            {
                string text = array[0].ToString();
                string text2 = Path.GetFileNameWithoutExtension(text) + ".csv";
                frmFtp.convertExcelToCSV(text, array[1].ToString(), text2);
                MyConsole.enqueue("Converting " + Path.GetFileName(text) + " to--> CSV");
             
                   if (UploadFtpFile(MyConnection.ftp_tagetik.path, text2))
                   // if (UploadFtpFile(MyConnection.ftp_tagetik.url, text2))
                    MyConsole.enqueue("Sending " + Path.GetFileName(text) + " to--> FTP Server");
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("FTP ERROR\r\n" + ex.Message, MessageBoxIcon.Hand);
                MyLogger.WriteLog("FTP ERROR\r\n" + ex.Message);
                MyConsole.enqueue("FTP ERROR: " + ex.Message);
            }

           
        }

        private void myworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.myprogressbar.Value = e.ProgressPercentage;
        }

        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            Cursor.Current = Cursors.Arrow;

            if (closeConsole)
            {
                //win.Close();
                //win = null;
                MyConsole.mostraCONSOLE.Hide();
            }
        }

        public bool UploadFtpFile(string folderName, string fileName)
        {
            try
            {
                string fileName2 = Path.GetFileName(fileName);
                FtpWebRequest ftpWebRequest = WebRequest.Create(new Uri(string.Format("ftp://{0}//{1}/{2}", MyConnection.ftp_tagetik.host, folderName, fileName2))) as FtpWebRequest;
                ftpWebRequest.Method = "STOR";
                ftpWebRequest.UseBinary = true;
                ftpWebRequest.UsePassive = true;
                ftpWebRequest.KeepAlive = false;
                ftpWebRequest.Proxy = null;
                ftpWebRequest.Credentials = new NetworkCredential(MyConnection.ftp_tagetik.username, MyConnection.ftp_tagetik.pwd);
                ftpWebRequest.ConnectionGroupName = "group";
                using (FileStream fileStream = File.OpenRead(fileName))
                {
                    byte[] array = new byte[fileStream.Length];
                    Stream requestStream = ftpWebRequest.GetRequestStream();
                    int num = 0;
                    int num2;
                    while ((num2 = fileStream.Read(array, 0, array.Length)) > 0)
                    {
                        requestStream.Write(array, 0, num2);
                        num += num2;
                        double num3 = (double)num * 100.0 / (double)fileStream.Length;
                        this.myworker.ReportProgress((int)num3);
                    }
                    requestStream.Flush();
                    requestStream.Close();
                    fileStream.Close();
                }
                MyMessage.showMessage(this.tbXslPath.Text + " UPLOADED", MessageBoxIcon.Information);
                return true;
            }
            catch (Exception ex)
            {
                MyMessage.showMessage("Error:\n" + ex.Message);
                MyLogger.WriteLog(this.Text + " Error: " + ex.Message);
                MyConsole.enqueue(this.Text + " Error: " + ex.Message);
                return false;
            }
        }
    }
}