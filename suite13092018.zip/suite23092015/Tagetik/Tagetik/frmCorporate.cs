﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace Tagetik
{
    public partial class frmCorporate : Form
    {
        //viewConsole win;
        bool closeConsole = false;

        public frmCorporate()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            this.myprogressbar.Value = 0;
            if (MyControl.checkControl(this.sourcefile))
            {
                base.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                MyLogger.WriteLog(this.Text + ": start import");
                this.myworker.RunWorkerAsync(new object[] { this.tbXslPath.Text, this.tbSheet.Text });

               /* win = (Application.OpenForms["viewConsole"] != null) ? ((viewConsole)Application.OpenForms["viewConsole"]) : null;
                if (win == null)
                {
                    win = new viewConsole();
                    win.Show();
                    closeConsole = true;
                }*/

                if (!MyConsole.mostraCONSOLE.Visible)
                {
                    MyConsole.mostraCONSOLE.Show();
                    closeConsole = true;
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "File Excel (*.xls, *.xlsx)|*.xls; *.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tbXslPath.Text = openFileDialog.FileName;
                MyExcel.FilledCombobox(ref this.tbSheet, this.tbXslPath.Text);
                Cursor.Current = Cursors.Arrow;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {
            object[] array = e.Argument as object[];
            OleDbConnection oleDbConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + array[0].ToString() + ";Extended Properties='Excel 12.0;HDR=Yes;'");

            using (SqlConnection sqlConnection = new SqlConnection(MyConnection.con_string_dbMS_tagetik))
            {
                try
                {
                    sqlConnection.Open();
                    oleDbConnection.Open();
                    OleDbCommand oleDbCommand = new OleDbCommand("select [MerchantID] from [" + array[1].ToString() + "$] WHERE ([MerchantID] IS NOT NULL)", oleDbConnection);
                    using (OleDbDataReader oleDbDataReader = oleDbCommand.ExecuteReader())
                    {
                        string cmdText = "INSERT INTO T_CORPORATE VALUES (@merchant_id)";
                        SqlCommand sqlCommand = new SqlCommand(cmdText, sqlConnection);
                        sqlCommand.Parameters.Add("@merchant_id", SqlDbType.VarChar);
                        int num = int.Parse(new OleDbCommand("select COUNT(*) from [" + array[1].ToString() + "$]", oleDbConnection).ExecuteScalar().ToString());
                        int num2 = 1;
                        while (oleDbDataReader.Read())
                        {
                            string text = "0" + oleDbDataReader[0].ToString().Substring(2);
                            sqlCommand.Parameters["@merchant_id"].Value = text;
                            try
                            {
                                if (sqlCommand.ExecuteNonQuery() > 0)
                                {
                                    MyConsole.enqueue(string.Concat(new object[]
								{
									"INSERT MID ",
									text,
									": ",
									oleDbDataReader["MerchantID"]
								}));
                                }
                                else
                                {
                                    MyConsole.enqueue(string.Concat(new object[]
								{
									"MID ",
									text,
									": ",
									oleDbDataReader["MerchantID"],
									" ALREADY EXISTS"
								}));
                                }
                            }
                            catch
                            {
                            }
                            this.myworker.ReportProgress(num2 * 100 / num);
                            num2++;
                        }
                    }
                    oleDbConnection.Close();
                }
                catch (Exception ex)
                {
                    MyConsole.enqueue("ERROR: " + ex.Message);
                    MyMessage.showMessage("ERROR\r\n" + ex.Message, MessageBoxIcon.Stop);
                    MyLogger.WriteLog(this.Text + " ERROR: " + ex.Message);

                    if (sqlConnection.State == ConnectionState.Open)
                        sqlConnection.Close();

                    if (oleDbConnection.State == ConnectionState.Open)
                        oleDbConnection.Close();
                }
            }
            MyConsole.enqueue("END OF IMPORT: Corporate data file " + this.tbXslPath.Text + " imported");
            MyMessage.showMessage("END OF IMPORT: Corporate data file " + this.tbXslPath.Text + " imported", MessageBoxIcon.Information);
        }

        private void myworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.myprogressbar.Value = e.ProgressPercentage;
        }

        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            Cursor.Current = Cursors.Arrow;
            /*if (this.myprogressbar.Value == 100)
            {
                MyMessage.showMessage(this.tbXslPath.Text + " IMPORTED", MessageBoxIcon.Asterisk);
            }
            else
            {
                MyMessage.showMessage("Import has been stopped", MessageBoxIcon.Hand);
            }
            */
            if (closeConsole)
            {
                //win.Close();
                //win = null;
                MyConsole.mostraCONSOLE.Hide();
            }
        }
    }
}
