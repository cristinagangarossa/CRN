﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;

namespace Tagetik
{
    public partial class fixCSR : Form
    {
        bool closeConsole = false;
        //viewConsole win;

        public fixCSR()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "File Excel (*.xls, *.xlsx)|*.xls; *.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.tbXslPath.Text = openFileDialog.FileName;
                MyExcel.FilledCombobox(ref this.tbSheet, this.tbXslPath.Text);
                Cursor.Current = Cursors.Arrow;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.myprogressbar.Value = 0;
            if (MyControl.checkControl(this.source_file))
            {
                base.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                MyLogger.WriteLog(this.Text + ": start fix");
                this.myprogressbar.Style = ProgressBarStyle.Marquee;
                this.myworker.RunWorkerAsync(new object[] { this.tbXslPath.Text });

                if (!MyConsole.mostraCONSOLE.Visible)
                {
                    MyConsole.mostraCONSOLE.Show();
                    closeConsole = true;
                }
                
                /*win = (Application.OpenForms["viewConsole"] != null) ? ((viewConsole)Application.OpenForms["viewConsole"]) : null;
                if (win == null)
                {
                    win = new viewConsole();
                    win.Show();
                    closeConsole = true;
                }*/
            }
        }

        private void myworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.myprogressbar.Value = e.ProgressPercentage;
        }

        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            Cursor.Current = Cursors.Arrow;
            this.myprogressbar.Style = ProgressBarStyle.Continuous;
           // MyMessage.showMessage(tbXslPath.Text + " has been fixed", MessageBoxIcon.Asterisk);

            if (closeConsole)
            {
                //win.Close();
                //win = null;
                MyConsole.mostraCONSOLE.Hide();
            }
        }

        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {
            object[] array = e.Argument as object[];
            MyLogger.WriteLog(this.Text + ": start fix CSR");
            MyConsole.enqueue("start fix CSR");
            Fix.CSR(array[0].ToString());
        }


    }
}
