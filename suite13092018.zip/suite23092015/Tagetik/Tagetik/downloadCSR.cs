﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Credit_risk_lib;
using System.Net;
using System.IO;
using System.Collections;
using System.Web;
using System.Globalization;
using System.Threading;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

namespace Tagetik
{
    public partial class downloadCSR : Form
    {
        bool checkresult = true;
        //viewConsole win;
        bool closeConsole = false;

        public downloadCSR()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel File|*.xls";
            saveFileDialog.Title = "Save CSR";
            saveFileDialog.ShowDialog();
            if (saveFileDialog.FileName != "")
            {
                Cursor.Current = Cursors.WaitCursor;
                tbXslPath.Text = saveFileDialog.FileName;
                Cursor.Current = Cursors.Arrow;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MyControl.checkControl(this.source_file))
            {
                base.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                MyLogger.WriteLog(this.Text + ": start download");
                this.myworker.RunWorkerAsync(new object[] { this.tbXslPath.Text });


                if (!MyConsole.mostraCONSOLE.Visible)
                {
                    MyConsole.mostraCONSOLE.Show();
                    closeConsole = true;
                }


                /*win = (Application.OpenForms["viewConsole"] != null) ? ((viewConsole)Application.OpenForms["viewConsole"]) : null;
                if (win == null)
                {
                    win = new viewConsole();
                    win.Show();
                    closeConsole = true;
                }*/
            }
        }

        private void myworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            base.Enabled = true;
            Cursor.Current = Cursors.Arrow;

            if (closeConsole)
            {
                //win.Close();
                //win = null;
                MyConsole.mostraCONSOLE.Hide();
            }
        }

        private bool isReportReady(CookieContainer myCookie)
        {
            try
            {
                
                // string historyPage = "http://" + MyConnection.con_ice_import.ip + "/ICE/Reporthistory.aspx";
                string historyPage = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/ICE/Reporthistory.aspx";
                HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(historyPage);
                myRequest.Proxy = WebProxy.GetDefaultProxy();
                myRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                myRequest.CookieContainer = myCookie;

                HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();
                StreamReader myStreamReader = new StreamReader(myResponse.GetResponseStream());

                string htmlSource = myStreamReader.ReadToEnd();
                
                myStreamReader.Close();
                myResponse.Close();

                int uidPos = htmlSource.IndexOf("<td>Collection Status Report</td>");
                
                if (uidPos >= 0)
                {
                    

                    if (htmlSource.Substring(uidPos, 81).EndsWith("C"))
                    {
                        
                        return true;
                    }
                    else
                    {
                        
                        MyConsole.enqueue("Report status = Not completed. Please wait...");
                        return false;
                    }
                }
                else
                {
                    MyConsole.enqueue("Report status = Unavailable. Please wait...");
                    return false;
                }
            }
            catch (Exception e)
            {
                throw new Exception("isReportReady error: " + e.Message);
            }
        }
        //method to bypass invalid certificate
        static bool MyCertHandler(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors error)
        {
            // Ignore errors
            return true;
        }
        private void myworker_DoWork(object sender, DoWorkEventArgs e)
        {
            object[] datifromthread = e.Argument as object[];
            MyConsole.enqueue("Start download CSR");

            try
            {   //call method to bypass certificate
                ServicePointManager.ServerCertificateValidationCallback = MyCertHandler;
                CookieContainer cookieContainer = new CookieContainer();
                //string text = "http://" + MyConnection.con_ice_import.ip + "/ICE/Default.aspx";
                string text = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/" + MyConnection.con_ice_import.url2;
                MyConsole.enqueue("Connection to " + text);
                WebClient webClient = new WebClient();
                Stream stream = webClient.OpenRead(text);
                // MyConsole.enqueue("stream " + stream.ToString());
                StreamReader streamReader = new StreamReader(stream);
                ArrayList arrayList = new ArrayList(2);
                arrayList = Tagetik.Fix.getViewStateAndEventVal(streamReader);

                streamReader.Close();
                stream.Close();
                string text2 = (string)arrayList[0];
                string text3 = (string)arrayList[1];

                text2 = HttpUtility.UrlEncode(text2);
                text3 = HttpUtility.UrlEncode(text3);
                string s = string.Concat(new string[]
			        {
				        "__LASTFOCUS=&__VIEWSTATE=",
				        text2,
				        "&TextBox1=",
				        HttpUtility.UrlEncode(MyConnection.con_ice_import.username),
				        "&TextBox2=",
				        HttpUtility.UrlEncode(MyConnection.con_ice_import.pwd),
				        "&Button1=Login&__EVENTTARGET=&__EVENTARGUMENT=&__EVENTVALIDATION=",
				        text3
			        });
                byte[] bytes = Encoding.UTF8.GetBytes(s);
                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(text);
                httpWebRequest.Method = "POST";
                httpWebRequest.ContentType = "application/x-www-form-urlencoded";
                httpWebRequest.ContentLength = (long)bytes.Length;
                httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                httpWebRequest.CookieContainer = cookieContainer;
                Stream requestStream = httpWebRequest.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);
                requestStream.Flush();
                requestStream.Close();
                HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                Stream stream2 = Tagetik.Fix.CopyAndClose(httpWebResponse.GetResponseStream());
                //MyConsole.enqueue("stream 2 " + stream2.ToString());
                StreamReader streamReader2 = new StreamReader(stream2);
                string text4;
                while ((text4 = streamReader2.ReadLine()) != null)
                {
                    //MyConsole.enqueue("text 4 " + text4);
                    if (text4.IndexOf("Invalid User ID Or Password") != -1)
                    {
                        MyMessage.showMessage("Invalid User ID Or Password", MessageBoxIcon.Hand);
                        return;
                    }
                }
                MyConsole.enqueue("LOGGED IN USER '" + MyConnection.con_ice_import.username + "'");
                stream2.Position = 0L;
                streamReader2 = new StreamReader(stream2);
                // text = "http://" + MyConnection.con_ice_import.ip + "/ICE/SelectGroup.aspx";
                text = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/ICE/SelectGroup.aspx";
                httpWebRequest = (HttpWebRequest)WebRequest.Create(text);
                httpWebRequest.Method = "POST";
                httpWebRequest.ContentType = "application/x-www-form-urlencoded";
                arrayList = Tagetik.Fix.getViewStateAndEventVal(streamReader2);
                streamReader2.Close();
                stream2.Close();
                text2 = (string)arrayList[0];
                text3 = (string)arrayList[1];
                text2 = HttpUtility.UrlEncode(text2);
                text3 = HttpUtility.UrlEncode(text3);
                s = "__EVENTTARGET=GridView1&__EVENTARGUMENT=Select%240&__VIEWSTATE=" + text2 + "&__EVENTVALIDATION=" + text3;
                bytes = Encoding.UTF8.GetBytes(s);
                httpWebRequest.ContentLength = (long)bytes.Length;
                httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                httpWebRequest.CookieContainer = cookieContainer;
                requestStream = httpWebRequest.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);
                requestStream.Flush();
                requestStream.Close();
                MyConsole.enqueue("SELECT GROUP BNLP");
                //text = "http://" + MyConnection.con_ice_import.ip + "/ICE/ABTRReport.aspx?RPTNO=3";
                text = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/ICE/ABTRReport.aspx?RPTNO=3";
                httpWebRequest = (HttpWebRequest)WebRequest.Create(text);
                httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                httpWebRequest.CookieContainer = cookieContainer;
                httpWebResponse.Close();
                httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                stream2 = Tagetik.Fix.CopyAndClose(httpWebResponse.GetResponseStream());
                streamReader2 = new StreamReader(stream2);
                httpWebRequest = (HttpWebRequest)WebRequest.Create(text);
                httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                httpWebRequest.CookieContainer = cookieContainer;
                httpWebRequest.Method = "POST";
                httpWebRequest.ContentType = "application/x-www-form-urlencoded";
                arrayList = Tagetik.Fix.getViewStateAndEventVal(streamReader2);
                text2 = (string)arrayList[0];
                text3 = (string)arrayList[1];
                text2 = Tagetik.Fix.UpperCaseUrlEncode(text2);
                text3 = Tagetik.Fix.UpperCaseUrlEncode(text3);
                stream2.Close();
                if (MyConnection.con_ice_import.username.CompareTo("ICE0294P") == 0)
                {
                    s = "__EVENTTARGET=GridView1&__EVENTARGUMENT=Select%240&__VIEWSTATE=" + text2 + "&DropDownList13=%3D&DropDownList1=0&DropDownList2=%3D&DropDownList3=0&DropDownList4=%3D&DropDownList5=0&DropDownList6=%3D&DropDownList7=0&DropDownList8=%3D&DropDownList9=0&DropDownList10=%3D&DropDownList11=0&DropDownList15=%3D&DropDownList16=0&TextBox2=&TextBox3=&DropDownList12=978&TextBox1=08%2FAug%2F2014&TextBox4=0.01&DropDownList14=32&__VIEWSTATEENCRYPTED=&__EVENTVALIDATION=" + text3;
                }
                else
                {
                    s = "__EVENTTARGET=GridView1&__EVENTARGUMENT=Select%240&__VIEWSTATE=" + text2 + "&DropDownList13=%3D&DropDownList1=0&DropDownList2=%3D&DropDownList3=0&DropDownList4=%3D&DropDownList5=0&DropDownList6=%3D&DropDownList7=0&DropDownList8=%3D&DropDownList9=0&DropDownList10=%3D&DropDownList11=0&DropDownList15=%3D&DropDownList16=0&TextBox2=&TextBox3=&DropDownList12=978&TextBox1=30%2FMay%2F2016&TextBox4=0.01&DropDownList14=32&__VIEWSTATEENCRYPTED=&__EVENTVALIDATION=" + text3;
               
                }
                    bytes = Encoding.UTF8.GetBytes(s);
                    httpWebRequest.ContentLength = (long)bytes.Length;
                    httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                    httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                    httpWebRequest.CookieContainer = cookieContainer;
                    requestStream = httpWebRequest.GetRequestStream();
                    requestStream.Write(bytes, 0, bytes.Length);
                    requestStream.Flush();
                    requestStream.Close();
                    httpWebResponse.Close();
                    httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                    MyConsole.enqueue("SELECT AUTOEXPORT PARAMETERS SET");
                    stream2 = Tagetik.Fix.CopyAndClose(httpWebResponse.GetResponseStream());
                    streamReader2 = new StreamReader(stream2);
                    httpWebRequest = (HttpWebRequest)WebRequest.Create(text);
                    httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                    httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                    httpWebRequest.CookieContainer = cookieContainer;
                    httpWebRequest.Method = "POST";
                    httpWebRequest.ContentType = "application/x-www-form-urlencoded";
                    arrayList = Tagetik.Fix.getViewStateAndEventVal(streamReader2);
                    text2 = (string)arrayList[0];
                    text3 = (string)arrayList[1];
                    text2 = Tagetik.Fix.UpperCaseUrlEncode(text2);
                    text3 = Tagetik.Fix.UpperCaseUrlEncode(text3);
                    stream2.Close();
                
                string s2 = DateTime.Now.ToString("dd-MMM-yyyy", new CultureInfo("en-US"));
                s = string.Concat(new string[]
			{
				"__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE=",
				text2,
				"&DropDownList13=%3D&DropDownList1=0&DropDownList2=%3D&DropDownList3=0&DropDownList4=%3D&DropDownList5=0&DropDownList6=%3D&DropDownList7=0&DropDownList8=%3D&DropDownList9=0&DropDownList10=%3D&DropDownList11=0&DropDownList15=%3D&DropDownList16=0&TextBox2=&TextBox3=&DropDownList12=978&TextBox1=",
				Tagetik.Fix.UpperCaseUrlEncode(s2),
				"&TextBox4=0.01&DropDownList14=33&Button6=Run+Report&__VIEWSTATEENCRYPTED=&__EVENTVALIDATION=",
                
				text3
			});
                bytes = Encoding.UTF8.GetBytes(s);
                httpWebRequest.ContentLength = (long)bytes.Length;
                httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                httpWebRequest.CookieContainer = cookieContainer;
                requestStream = httpWebRequest.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);
                requestStream.Flush();
                requestStream.Close();
                httpWebResponse.Close();
                httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();

                //ADD TMP CRI
                stream2 = Tagetik.Fix.CopyAndClose(httpWebResponse.GetResponseStream());
                streamReader2 = new StreamReader(stream2);
                httpWebRequest = (HttpWebRequest)WebRequest.Create(text);
                httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                httpWebRequest.CookieContainer = cookieContainer;
                httpWebRequest.Method = "POST";
                httpWebRequest.ContentType = "application/x-www-form-urlencoded";
                arrayList = Tagetik.Fix.getViewStateAndEventVal(streamReader2);
                text2 = (string)arrayList[0];
                text3 = (string)arrayList[1];
                text2 = Tagetik.Fix.UpperCaseUrlEncode(text2);
                text3 = Tagetik.Fix.UpperCaseUrlEncode(text3);
                stream2.Close();
                //END TMP CRI
                MyConsole.enqueue("RUN REPORT. Please wait...");

                while (!isReportReady(cookieContainer)) Thread.Sleep(60000);

                //text = "http://" + MyConnection.con_ice_import.ip + "/ICE/Reporthistory.aspx";
                text = MyConnection.con_ice_import.http + "://" + MyConnection.con_ice_import.ip + "/ICE/Reporthistory.aspx";
                MyConsole.enqueue("START REPORT DOWNLOAD. Please wait...");
                httpWebRequest = (HttpWebRequest)WebRequest.Create(text);
                httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                httpWebRequest.CookieContainer = cookieContainer;
                httpWebResponse.Close();
                httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                stream2 = Tagetik.Fix.CopyAndClose(httpWebResponse.GetResponseStream());
                streamReader2 = new StreamReader(stream2);
                httpWebRequest = (HttpWebRequest)WebRequest.Create(text);
                httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                httpWebRequest.CookieContainer = cookieContainer;
                httpWebRequest.Method = "POST";
                httpWebRequest.ContentType = "application/x-www-form-urlencoded";
                arrayList = Tagetik.Fix.getViewStateAndEventVal(streamReader2);
                text2 = (string)arrayList[0];
                text3 = (string)arrayList[1];
                text2 = Tagetik.Fix.UpperCaseUrlEncode(text2);
                text3 = Tagetik.Fix.UpperCaseUrlEncode(text3);
                stream2.Close();
                s = "__EVENTTARGET=GridView1&__EVENTARGUMENT=Select%240&__LASTFOCUS=&__VIEWSTATE=" + text2 + "&gr1=RadioButton1&gr2=RadioButton3&__VIEWSTATEENCRYPTED=&__EVENTVALIDATION=" + text3;
                bytes = Encoding.UTF8.GetBytes(s);
                httpWebRequest.ContentLength = (long)bytes.Length;
                httpWebRequest.Proxy = WebProxy.GetDefaultProxy();
                httpWebRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                httpWebRequest.CookieContainer = cookieContainer;
                requestStream = httpWebRequest.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);
                requestStream.Flush();
                requestStream.Close();
                httpWebResponse.Close();
                httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                Stream responseStream = httpWebResponse.GetResponseStream();
                string fileName = datifromthread[0].ToString();
                byte[] array = new byte[2048];
                FileStream fileStream = new FileStream(fileName, FileMode.Create);
                int count;
                while ((count = responseStream.Read(bytes, 0, bytes.Length)) != 0)
                {
                    fileStream.Write(bytes, 0, count);
                }
                fileStream.Close();

                MyConsole.enqueue("REPORT SAVED to " + datifromthread[0].ToString());
                //MyMessage.showMessage("REPORT SAVED to " + datifromthread[0].ToString(), MessageBoxIcon.Information);
               


                if (chkFix.Checked)
                    Tagetik.Fix.CSR(fileName);

                MyConsole.enqueue("----------- END OF PROCEDURE -----------");
                MyMessage.showMessage("CSR DOWNLOAD COMPLETED", MessageBoxIcon.Information);

            }
            catch (Exception ex)
            {
                checkresult = false;

                MyMessage.showMessage("UNABLE TO DOWNLOAD CSR\r\n" + ex.Message, MessageBoxIcon.Hand);
                MyConsole.enqueue("UNABLE TO DOWNLOAD CSR: " + ex.Message);
                MyLogger.WriteLog("UNABLE TO DOWNLOAD CSR: " + ex.Message);
            }
        }
    }
}

